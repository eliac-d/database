Yuta Okotsu Bot 🌿

<p align="center">
<img src="./database/ed.gif" width="75%" alt="بوت يوتا أوكوتسو">
</p>«بوت واتساب أنيق، عملي، وقابل للتوسّع، تم تطويره باستخدام Baileys، مع قاعدة بيانات SQLite وبنية برمجية نظيفة تدعم البوتات الرئيسية والبوتات الفرعية والإضافات.»

<p align="center">
<img src="https://img.shields.io/badge/Status-Activo-22c55e?style=flat" alt="الحالة">
<img src="https://img.shields.io/badge/Node.js-v20+-16a34a?style=flat&logo=nodedotjs&logoColor=white" alt="Node.js">
<img src="https://img.shields.io/badge/Database-SQLite-2563eb?style=flat" alt="SQLite">
<img src="https://img.shields.io/badge/Baileys-WhatsApp-0f172a?style=flat" alt="Baileys">
</p><p align="center">
<a href="https://github.com/DuarteXV/Yuta-Okotsu-Bot-MD">
<img src="https://img.shields.io/badge/Repositorio-Yuta%20Okotsu%20Bot-7c3aed?style=for-the-badge&logo=github&logoColor=white" alt="المستودع">
</a>
</p>«[!NOTE]
تم تصميم Yuta Okkotsu Bot MD لتقديم تجربة استخدام نظيفة، منظمة وسهلة على واتساب. المشروع مستمر في التطور لتحسين الميزات والاستقرار والتوافق.»

---

🌱 نبذة عن المشروع

Yuta Okkotsu Bot MD هو بوت واتساب يعتمد على مكتبة "baileys"، وقد صُمّم ببنية معيارية لإدارة الأوامر والبوتات الفرعية والجلسات وقاعدة البيانات ووظائف الوسائط المتعددة بطريقة منظمة.

يركز تصميمه على إبقاء الشيفرة البرمجية نظيفة، وتسهيل توسيع المشروع، والسماح للمستخدمين الآخرين بربط أرقامهم الخاصة واستخدامها كبوتات فرعية.

---

🪴 المتطلبات

قبل تثبيت البوت، تأكد من تثبيت الأدوات التالية:

المتطلب| الوصف
Git| لاستنساخ المستودع
Node.js v20+| لتشغيل المشروع
FFmpeg| لمعالجة الصوت والفيديو والملصقات
Build Essential| لتجميع المكتبات التي تتطلب بناءً أصليًا

<p>
<a href="https://git-scm.com/downloads"><img src="https://img.shields.io/badge/Git-0f172a?style=flat&logo=git&logoColor=22c55e" alt="Git"></a>
<a href="https://nodejs.org/en/download"><img src="https://img.shields.io/badge/Node.js-1e3a8a?style=flat&logo=nodedotjs&logoColor=white" alt="Node.js"></a>
<a href="https://ffmpeg.org/download.html"><img src="https://img.shields.io/badge/FFmpeg-14532d?style=flat&logo=ffmpeg&logoColor=white" alt="FFmpeg"></a>
</p>---

🌵 التثبيت

<details>
<summary><strong>🍃 Linux / Ubuntu</strong></summary>تحديث النظام وترقية الحزم:

apt update && apt upgrade -y

تثبيت الأدوات المطلوبة:

apt install git nodejs ffmpeg build-essential -y

استنساخ المستودع:

git clone https://github.com/DuarteXV/Yuta-Okkotsu-Bot-MD.git Yuta

الدخول إلى مجلد المشروع:

cd Yuta

تثبيت الاعتماديات:

npm i

تشغيل البوت:

npm start

</details><details>
<summary><strong>🌾 Termux</strong></summary>السماح بالوصول إلى مساحة التخزين:

termux-setup-storage

تحديث الحزم:

pkg update && pkg upgrade -y

تثبيت الأدوات المطلوبة:

pkg install -y nodejs-lts git python clang make pkg-config libvips ffmpeg libwebp

استنساخ المستودع والدخول إلى مجلده:

git clone https://github.com/DuarteXV/Yuta-Okkotsu-Bot-MD.git Yuta && cd Yuta

إعداد متغيرات بيئة البناء:

export GYP_DEFINES="android_ndk_path=''"
echo 'export GYP_DEFINES="android_ndk_path="""' >> ~/.bashrc

تثبيت الاعتماديات وإعداد نسخة Sharp الخاصة بـ WebAssembly:

npm i && npm install --cpu=wasm32 sharp && npm install @img/sharp-wasm32

تشغيل البوت:

npm start

«إذا ظهرت رسالة تأكيد مثل (Y/I/N/O/D/Z) [default=N] ?، اكتب الحرف y ثم اضغط ENTER.»

</details><details>
<summary><strong>🍀 إبقاء البوت قيد التشغيل باستخدام PM2</strong></summary>نفّذ الأوامر التالية داخل مجلد البوت.

تثبيت PM2 عالميًا:

npm i -g pm2

تشغيل البوت باستخدام PM2:

pm2 start index.js

حفظ قائمة العمليات:

pm2 save

عرض سجلات التشغيل:

pm2 logs

الأوامر المتاحة

إيقاف البوت:

pm2 stop index

تشغيل البوت مجددًا:

pm2 start index

حذف العملية من PM2:

pm2 delete index

عرض السجلات:

pm2 logs

</details>«🦎 عند بدء تشغيل البوت، ستتمكن من الاختيار بين رمز الاقتران أو رمز QR لربط جهازك.»

---

🐸 الأوامر الرئيسية

الأمر| الوصف
"menu"| عرض القائمة التي تحتوي على جميع الأوامر المتاحة
"code"| ربط رقمك كبوت فرعي
"s"| إنشاء ملصقات من الصور أو مقاطع الفيديو أو ملفات GIF
"setmeta"| تخصيص العلامة المائية للملصقات
"play"| تنزيل مقاطع فيديو من YouTube بصيغة MP3
"scdl"| تنزيل الأغاني من SoundCloud
"bots"| عرض البوتات الفرعية المتصلة

---

🌳 بنية المشروع

Yuta-Okotsu-Bot-MD/
├── core/
├── database/
├── plugins/
├── sessions/
├── config.js/
├── index.js/
└── package.json

---

🐢 نظام البوتات الفرعية

يدعم Yuta Okkotsu نظام البوتات الفرعية (Subbots)، مما يسمح للمستخدمين الآخرين بربط أرقامهم الخاصة واستخدام النظام بشكل مستقل.

---

🍃 واجهات برمجة التطبيقات المستخدمة (APIs)

تعتمد بعض وظائف الوسائط المتعددة والتنزيل في البوت على خدمات خارجية. إذا توقفت إحدى هذه الخدمات عن العمل، فقد تتعطل الأوامر التي تعتمد عليها مؤقتًا.

<table align="center">
<tr>
<td align="center" width="200">
<a href="https://api.alyacore.xyz/">
<img src="https://api.alyacore.xyz/favicon.ico" width="64px" alt="واجهة AlyaCore"><br>
<sub><b>api.alyacore.xyz</b></sub>
</a>
</td>
<td align="center" width="200">
<a href="https://api.lempi.lat/">
<img src="https://api.lempi.lat/logo.png" width="64px" alt="واجهة Lempi"><br>
<sub><b>api.lempi.lat</b></sub>
</a>
</td>
</tr>
</table>«[!TIP]
نتوجه بالشكر إلى مطوري واجهات برمجة التطبيقات هذه على جهودهم في إبقاء خدماتهم متاحة للمجتمع.»

---

🌲 المساهمون

الأشخاص الذين ساهموا في كتابة الشيفرة البرمجية وتقديم الأفكار والدعم لتطوير Yuta Okkotsu Bot MD:

<table align="center">
<tr>
<td align="center">
<a href="https://github.com/naut21">
<img src="https://github.com/naut21.png?size=120" width="110px" alt="naut21"><br>
<sub><b>naut21</b></sub>
</a>
</td>
<td align="center">
<a href="https://github.com/DuarteXV">
<img src="https://github.com/DuarteXV.png?size=120" width="110px" alt="DuarteXV"><br>
<sub><b>DuarteXV</b></sub>
</a>
</td>
<td align="center">
<a href="https://github.com/jonathanggg">
<img src="https://github.com/jonathanggg.png?size=120" width="110px" alt="jonathanggg"><br>
<sub><b>jonathanggg</b></sub>
</a>
</td>
</tr>
</table>«🍀 هل تريد أن يظهر اسمك هنا؟ نرحب بالمساهمات من خلال Issues وPull Requests.»

---

🌴 إخلاء المسؤولية القانونية

«هذا المشروع غير تابع لشركة WhatsApp أو Meta.

إنه بوت مستقل تم تطويره باستخدام مكتبة Baileys.»

🌱 التصميم المرئي مستوحى من أنمي Jujutsu Kaisen وشخصية Yuta Okkotsu.

---

<p align="center">
<a href="https://github.com/DuarteXV">
<img src="https://img.shields.io/badge/Powered%20by-DuarteXV-7c3aed?style=for-the-badge&logo=github&logoColor=white" alt="بدعم من DuarteXV">
</a>
</p><p align="center">
<a href="https://github.com/DuarteXV">
<img src="https://github.com/DuarteXV.png?size=130" width="130px" alt="DuarteXV">
</a>
</p>