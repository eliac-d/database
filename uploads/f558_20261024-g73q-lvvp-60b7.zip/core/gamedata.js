// شخصيات أصلية (عائلة الـ"فاميليا") — لا ترتبط بأي عمل أو شخصية محمية بحقوق نشر.
export const PERSONAJES = {
  soldado: {
    nombre: "سالفاتوري \"الجندي\"",
    generacion: "new_gen",
    precio: 120000,
    imagen: null
  },
  tiradora: {
    nombre: "روزا \"القناصة\"",
    generacion: "new_gen",
    precio: 135000,
    imagen: null
  },
  conductor: {
    nombre: "ماركو \"السائق\"",
    generacion: "new_gen",
    precio: 150000,
    imagen: null
  },
  contador: {
    nombre: "أنطونيو \"المحاسب\"",
    generacion: "old_gen",
    precio: 300000,
    imagen: null
  },
  consigliere: {
    nombre: "دون فينشنزو \"المستشار\"",
    generacion: "old_gen",
    precio: 450000,
    imagen: null
  },
  elpadrino: {
    nombre: "دون سالفاتور \"الأب الروحي\"",
    generacion: "old_gen",
    precio: 700000,
    imagen: null
  }
};

export const ITEMS = {
  pala: { nombre: '🪏 مجرفة', precio: 500, poder: 10, tipo: 'arma' },
  pico: { nombre: '⛏️ فأس', precio: 1200, poder: 25, tipo: 'arma' },
  pistola: { nombre: '🔫 مسدس', precio: 2200, poder: 45, tipo: 'arma' },
  chaleco_antibalas: { nombre: '🦺 صدرية واقية', precio: 2800, poder: 55, tipo: 'armadura' },
  cuchillo_plata: { nombre: '🔪 سكين فضي', precio: 3000, poder: 70, tipo: 'arma' },
  traje_blindado: { nombre: '🕴️ بدلة مدرعة', precio: 4500, poder: 95, tipo: 'armadura' },
  maletin: { nombre: '💼 شنطة فلوس', precio: 8000, poder: 150, tipo: 'armadura' },
  anillo_familia: { nombre: '💍 خاتم العائلة', precio: 12000, poder: 220, tipo: 'armadura' },

  escopeta_soldado: { nombre: '🔫 بندقية الجندي', precio: 25000, poder: 300, tipo: 'arma', restriccion: 'soldado' },
  rifle_francotirador: { nombre: '🎯 بندقية القناصة', precio: 28000, poder: 320, tipo: 'arma', restriccion: 'tiradora' },
  auto_blindado: { nombre: '🚗 سيارة السائق المدرعة', precio: 35000, poder: 400, tipo: 'arma', restriccion: 'conductor' },
  libro_contador: { nombre: '📒 دفتر حسابات المحاسب', precio: 60000, poder: 550, tipo: 'arma', restriccion: 'contador' },
  contrato_consigliere: { nombre: '📜 عقد المستشار', precio: 90000, poder: 700, tipo: 'arma', restriccion: 'consigliere' },
  sello_padrino: { nombre: '🖋️ ختم الأب الروحي', precio: 150000, poder: 1000, tipo: 'armadura', restriccion: 'elpadrino' },
};

export function xpParaNivel(nivel) {
  return nivel * 500;
}

export function calcularPoder(personaje) {
  const nivelPoder = personaje.nivel * 20;
  const armaPoder = personaje.arma ? (ITEMS[personaje.arma]?.poder || 0) : 0;
  const armaduraPoder = personaje.armadura ? (ITEMS[personaje.armadura]?.poder || 0) : 0;
  return nivelPoder + armaPoder + armaduraPoder;
}
