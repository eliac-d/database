import { db } from "../database/db.js";

function applyPlaceholders(template, { mention, numero, grupo, total }) {
  return template
    .replace(/%user%|@user/g, `@${numero}`)
    .replace(/%grupo%/g, grupo)
    .replace(/%total%/g, total);
}

const DEFAULT_WELCOME =
`╮═≼『⏤͟͞ू⃪ 🖤⃝┃عـضـو جـديـد┃⏤͟͞ू⃪ 🖤⃝』≽═╭
> •┊˹👋˼┊الـتـرحـيـب ⇇ 〘انـضـم عـضـو جـديـد لـعـائـلـتـنـا〙

*~⧼❆˹─━═┉⌯⤸◞🖤◜⤹⌯┉═━─˼‏❆⧽~*
*🖤┊⪼• ◈╷『 𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 ボット 』 ⥏🖤⥑╵◈*
*¦ ⌗╎عـدد الأعـضـاء ╎⌗ ¦*
> *~『◈˼%total% عـضـو˹◈』~*

*~˼‏※⸃─┉┈┈⥏🖤⥑┈┈┉─⸂※ ˹~*
*⸂┊˼‏الـعـضـو الـجـديـد ↓⸃*
> *@user*
> *⌝˼‏نـورت الـقـروب: 『 %grupo% 』˹⌞*

> •┊˹💐˼┊أتـمـنـى لـك ⇇ 〘وقـتـاً مـمـتـعـاً بـيـنـنـا 🖤〙

*~⧼❆˹─━═┉⌯⤸◞🖤◜⤹⌯┉═━─˼‏❆⧽~*

╮═══『┃ 📌 مـلاحـظـة لـلـمـشـرف ┃』═══╭
> •┊˹🔕˼┊لإيـقـاف الـتـرحـيـب ⇇ 〘.welcome off〙
> •┊˹🔔˼┊لـتـفـعـيـل الـتـرحـيـب ⇇ 〘.welcome on〙
*⌬──══─┈•⤣🖤⤤•┈─══──⌬*
_تم التطوير بواسطة تائب_`;

const DEFAULT_BYE =
`╮═≼『⏤͟͞ू⃪ 🖤⃝┃عـضـو غـادر┃⏤͟͞ू⃪ 🖤⃝』≽═╭
> •┊˹🚪˼┊الـوداع ⇇ 〘غـادر عـضـو الـقـروب〙

*~⧼❆˹─━═┉⌯⤸◞🖤◜⤹⌯┉═━─˼‏❆⧽~*
*🖤┊⪼• ◈╷『 𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 ボット 』 ⥏🖤⥑╵◈*

*⸂┊˼‏الـعـضـو الـمـغـادر ↓⸃*
> *@user*
> *⌝˼‏ودعـنـاه مـن: 『 %grupo% 』˹⌞*

> •┊˹🤍˼┊نـتـمـنـى لـه ⇇ 〘كـل الـتـوفـيـق〙

*⌬──══─┈•⤣🖤⤤•┈─══──⌬*
_تم التطوير بواسطة ســونــغ_`;

export async function handleGroupParticipantsUpdate(sock, { id: groupJid, participants, action }) {
  try {
    const groupData = db.getGroup(groupJid);
    // معطّلة افتراضيًا حتى يفعّلها المالك بـ .welcome on / .bye on
    const wantsBye = action === "remove" && groupData?.bye === true;

    if (action === "add" && groupData?.welcome === true) {
      let total = "?";
      try {
        const meta = await sock.groupMetadata(groupJid);
        total = meta?.participants?.length ?? "?";
      } catch {}

      for (const jid of participants) {
        const numero = jid.split("@")[0];
        let meta;
        try { meta = await sock.groupMetadata(groupJid); } catch {}
        const grupo = meta?.subject || groupJid;

        const template = groupData.welcomeMsg || DEFAULT_WELCOME;
        const texto = applyPlaceholders(template, { numero, grupo, total });

        await sock.sendMessage(groupJid, { text: texto, mentions: [jid] });
      }
    }

    if (wantsBye) {
      let meta;
      try { meta = await sock.groupMetadata(groupJid); } catch {}
      const grupo = meta?.subject || groupJid;

      for (const jid of participants) {
        const numero = jid.split("@")[0];
        const template = groupData.byeMsg || DEFAULT_BYE;
        const texto = applyPlaceholders(template, { numero, grupo, total: "" });

        await sock.sendMessage(groupJid, { text: texto, mentions: [jid] });
      }
    }
  } catch (e) {
    console.error("[welcome]", e?.message || e);
  }
}
