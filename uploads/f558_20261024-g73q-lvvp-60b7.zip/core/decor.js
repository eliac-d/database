// مولّد الزخرفة الموحدة لردود البوت (نفس ستايل الترحيب/الوداع)

export function decorBox(title, lines = [], { footer = true } = {}) {
  let out = `╮═══『┃ ${title} ┃』═══╭\n`;
  for (const line of lines) {
    out += `${line}\n`;
  }
  out += `⌬──══─┈•⤣🖤⤤•┈─══──⌬`;
  if (footer) out += `\n_تم التطوير بواسطة ســونــغ_`;
  return out;
}

// سطر بنمط «•┊˹إيموجي˼┊تسمية ⇇ 〘قيمة〙»
export function decorLine(emoji, label, value) {
  return `> •┊˹${emoji}˼┊${label} ⇇ 〘${value}〙`;
}
