global.botNames = [
  '𝕬𝖄𝕬𝕹𝕺𝕶𝕺𝕵𝕴 𝕭𝕺𝕿',
  'アヤノコウジ・ボット',
  '𝙰𝚈𝙰𝙽𝙾𝙺𝙾𝙹𝙸 𝙱𝙾𝚃',
  '𝗔𝗬𝗔𝗡𝗢𝗞𝗢𝗝𝗜 𝗕𝗢𝗧',
  '𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓'
];

global.botImages = [];

global.getBotName = () =>
  global.botNames[Math.floor(Math.random() * global.botNames.length)];

global.getBotImage = () =>
  global.botImages.length ? global.botImages[Math.floor(Math.random() * global.botImages.length)] : null;

global.teamCredit = 'فريق 𝑿𝟔';
global.devCredit = 'تم التطوير بواسطة سونغ';

global.my = {
  canal1: '120363411937339682@newsletter',
  canal2: '120363411937339682@newsletter',
  canalUrl: 'https://whatsapp.com/channel/0029Vb90KfqHFxOzuuPGSL2Y',
  canalNombre: 'قناة AYANOKOJI BOT',
  groupUrl: 'https://chat.whatsapp.com/HezlQ4yojeDG6k3fVDr5yz',
};

global.ch = global.my.canal1;
global.chUrl = global.my.canalUrl;
global.groupUrl = global.my.groupUrl;

global.rmr = String.fromCharCode(8206).repeat(850);