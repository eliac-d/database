import { log } from "./logger.js";

const linkRegex = /(?:^|[\s/])(?:chat\.whatsapp\.com\/[0-9A-Za-z]{20,24}|(?:www\.|web\.)?whatsapp\.com\/channel\/[0-9A-Za-z]{10,30})(?:[\s?]|$)/i;

export function hasWhatsappLink(text = "") {
  return linkRegex.test(text);
}

export async function checkAntilink({ sock, msg, from, sender, body, isBotAdmin, botLabel }) {
  if (!hasWhatsappLink(body)) return false;
  if (!isBotAdmin) return false;

  try {
    // 1. حذف الرسالة التي تحتوي على الرابط
    await sock.sendMessage(from, {
      delete: {
        remoteJid: from,
        id: msg.key.id,
        participant: sender,
        fromMe: false
      }
    });

    // 2. طرد العضو الذي أرسل الرابط
    await sock.groupParticipantsUpdate(from, [sender], "remove");

    // 3. إرسال رسالة التنبيه بالعربية
    await sock.sendMessage(from, {
      text: `🚫 تم حذف رابط دعوة وطرد العضو @${sender.split("@")[0]}`,
      mentions: [sender]
    });

    log.cmdExec({ cmdName: "antilink", sender: sender.split("@")[0], success: true, ms: 0, botLabel });
  } catch (e) {
    log.error(`antilink: ${e.message}`);
  }

  return true;
}