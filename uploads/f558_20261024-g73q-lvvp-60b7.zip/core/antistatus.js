import { log } from "./logger.js";

// ملاحظة مهمة: واتساب ما يوفر علامة واضحة تميز "حالة متشاركة" عن أي رسالة
// معاد توجيهها. أفضل كشف متاح هو: الرسالة معاد توجيهها (isForwarded) وبدون
// رد على رسالة (quotedMessage فاضي) — هذا يغطي أغلب حالات مشاركة الحالات،
// لكنه بيحذف أيضًا أي محتوى آخر يوصل معاد توجيهه بنفس الشكل.
function getContextInfo(message) {
  if (!message) return null;
  const type = Object.keys(message)[0];
  return message[type]?.contextInfo || null;
}

export async function checkAntistatus({ sock, msg, from, sender, isBotAdmin, botLabel }) {
  const ctx = getContextInfo(msg.message);
  const esReenviada = ctx?.isForwarded === true && !ctx?.quotedMessage;

  if (!esReenviada) return false;
  if (!isBotAdmin) return false;

  try {
    await sock.sendMessage(from, {
      delete: {
        remoteJid: from,
        id: msg.key.id,
        participant: sender,
        fromMe: false
      }
    });

    await sock.sendMessage(from, {
      text: `🚫 تم حذف محتوى معاد توجيهه (حالة/مشاركة) من @${sender.split("@")[0]} (مضاد الحالات مفعّل).`,
      mentions: [sender]
    });

    log.cmdExec({ cmdName: "antistatus", sender: sender.split("@")[0], success: true, ms: 0, botLabel });
  } catch (e) {
    log.error(`antistatus: ${e.message}`);
  }

  return true;
}
