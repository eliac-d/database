import { log } from "./logger.js";

const CONTACT_TYPES = new Set(["contactMessage", "contactsArrayMessage"]);

export async function checkAnticontact({ sock, msg, from, sender, msgType, isBotAdmin, botLabel }) {
  if (!CONTACT_TYPES.has(msgType)) return false;
  if (!isBotAdmin) return false;

  try {
    await sock.sendMessage(from, {
      delete: {
        remoteJid: from,
        id: msg.key.id,
        participant: sender,
        fromMe: false
      }
    });

    await sock.sendMessage(from, {
      text: `🚫 تم حذف جهة اتصال أرسلها @${sender.split("@")[0]} (مضاد جهات الاتصال مفعّل).`,
      mentions: [sender]
    });

    log.cmdExec({ cmdName: "anticontact", sender: sender.split("@")[0], success: true, ms: 0, botLabel });
  } catch (e) {
    log.error(`anticontact: ${e.message}`);
  }

  return true;
}
