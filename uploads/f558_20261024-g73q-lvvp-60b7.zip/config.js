export default {
  //   🎭 هوية البوت الأساسية
  botName: "𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓",
  botname: "𝗔𝗬𝗔𝗡𝗢𝗞𝗢𝗝𝗜 𝗕𝗢𝗧",
  wm:      "𝙰𝚈𝙰𝙽𝙾𝙺𝙾𝙹𝙸 𝙱𝙾𝚃",
  packname: "𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓",
  textbot: "آيانوكوجي كيوتاكا، شخص هادئ لكن محسوب كل خطوة فيه بدقة.",
  prefix:  ".", // يمكنك إضافة أكثر من بادئة هكذا: [".", "#", "!"]
  //   👑 الحقوق والمطورين
  author:   "© سونغ",
  dev:      "© تم تطوير بواسطة سونغ",
  etiqueta: "سونغ",
  //   🛡️ الصلاحيات (بدون @s.whatsapp.net)
  ownerNumber: ["963969829657"],
  coOwners: ["967735541558", "50942015139"],
  //   ⚙️ إعدادات التشغيل
  sessionDir: "./sessions/main",
  readMessages: true, // تفعيل علامة القراءة (العلامتين الزرقاء)
  autoReconnect: true, // إعادة الاتصال تلقائياً عند الانقطاع
  maxReconnectAttempts: 10,
  reconnectDelay: 5000,
  logLevel: "info",
};