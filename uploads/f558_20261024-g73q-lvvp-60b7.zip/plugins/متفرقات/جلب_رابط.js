import axios from 'axios'
import { fileTypeFromBuffer } from 'file-type'

export default {
  name: ['fetch', 'get', 'descargar', 'جلب'],
  description: 'يحمّل ويرسل محتوى رابط (يدعم صور، فيديو، صوت ونص)',
  category: 'misc, أدوات',
  ownerOnly: false,

  async run({ sock, from, msg, args, react, reply }) {
    try {
      const url = args.join(' ').trim()

      if (!url) {
        return reply({
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊رجاءً ادخل رابطاً صحيحاً.\n` +
            `> •┊˹💡˼┊مثال ⇇ *〘.fetch https://example.com/image.jpg〙*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        return reply({ 
          text: 
            `*『͟͞ू⃪ ❌رابـط غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
            `> •┊˹❌˼┊الرابط يجب أن يبدأ بـ http:// أو https://\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      await react('⏳')
      await reply({ 
        text: 
          `*『͟͞ू⃪ 🌐جـاري الـتـحـمـيـل⏤͟ू⃪🌐』*\n` +
          `> •┊˹⏳˼┊جاري الاتصال بالسيرفر وتحميل البيانات...\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      const response = await axios.get(url, {
        responseType: 'arraybuffer',
        timeout: 60000,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      })

      const buffer = Buffer.from(response.data)

      if (!buffer || buffer.length === 0) {
        throw new Error('السيرفر أرجع ملفاً فارغاً.')
      }

      const detected = await fileTypeFromBuffer(buffer)
      const mime = detected?.mime || response.headers['content-type'] || 'text/plain'

      if (mime.startsWith('image/')) {
        await sock.sendMessage(from, {
          image: buffer,
          caption: `*『͟͞ू⃪ ✅تـم جـلـب الـصـورة⏤͟ू⃪✅』*\n\n*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        }, { quoted: msg })

      } else if (mime.startsWith('video/')) {
        await sock.sendMessage(from, {
          video: buffer,
          caption: `*『͟͞ू⃪ ✅تـم جـلـب الـفـيـديـو⏤͟ू⃪✅』*\n\n*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        }, { quoted: msg })

      } else if (mime.startsWith('audio/')) {
        await sock.sendMessage(from, {
          audio: buffer,
          mimetype: mime,
          ptt: mime.includes('ogg')
        }, { quoted: msg })

      } else if (mime.startsWith('text/') || mime.includes('json') || mime.includes('javascript')) {
        const textContent = buffer.toString('utf-8')

        if (textContent.length > 3000) {
          await sock.sendMessage(from, {
            document: Buffer.from(textContent),
            mimetype: 'text/plain',
            fileName: `fetch_${Date.now()}.txt`,
            caption: 
              `*『͟͞ू⃪ 📄الـمـحـتـوى طـويـل⏤͟ू⃪📄』*\n` +
              `> •┊˹📦˼┊تم إرساله كملف بسبب حجمه.\n` +
              `> •┊˹📊˼┊الحجم ⇇ *〘${(textContent.length / 1024).toFixed(1)} KB〙*\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          }, { quoted: msg })
        } else {
          await reply({
            text: 
              `*『͟͞ू⃪ 📄نـتـيـجـة الـطـلـب⏤͟ू⃪📄』*\n` +
              `> •┊˹📝˼┊المحتوى:\n\`\`\`${textContent}\`\`\`\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

      } else {
        const ext = detected?.ext || 'bin'
        await sock.sendMessage(from, {
          document: buffer,
          mimetype: mime,
          fileName: `fetch_file_${Date.now()}.${ext}`
        }, { quoted: msg })
      }

      await react('✅')

    } catch (e) {
      await react('❌')

      let errMsg = e.message
      if (e.response) {
        errMsg = `السيرفر أرجع رمز ${e.response.status}`
      } else if (e.code === 'ECONNABORTED') {
        errMsg = 'انتهى الوقت أثناء تحميل الملف.'
      }

      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${errMsg}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
      console.error(e)
    }
  }
}