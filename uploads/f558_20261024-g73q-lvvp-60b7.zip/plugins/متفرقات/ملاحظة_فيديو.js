import { downloadMediaMessage } from '@whiskeysockets/baileys'

export default {
  name: ['pvt', 'ملاحظة_فيديو'],
  description: 'يحول فيديو (رد عليه) إلى ملاحظة فيديو',
  category: 'misc, أدوات',
  ownerOnly: false,

  async run({ sock, from, msg, react, reply }) {
    const msgType = Object.keys(msg.message || {})[0]
    const contextInfo = msg.message?.extendedTextMessage?.contextInfo
    const quoted = contextInfo?.quotedMessage
    const quotedType = quoted ? Object.keys(quoted)[0] : null

    const isVideo = msgType === 'videoMessage'
    const isQuotedVideo = quotedType === 'videoMessage'

    if (!isVideo && !isQuotedVideo) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊رد على فيديو حتى أحوله لملاحظة فيديو (pvt).\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    await react('⏳')

    const targetMsg = isVideo
      ? msg
      : {
          key: {
            remoteJid: from,
            id: contextInfo?.stanzaId,
            participant: contextInfo?.participant
          },
          message: quoted
        }

    let videoBuffer
    try {
      videoBuffer = await downloadMediaMessage(targetMsg, 'buffer', {}, { sock })
    } catch (e) {
      await react('❌')
      return reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أحمّل الفيديو.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    await sock.sendMessage(from, {
      video: videoBuffer,
      mimetype: 'video/mp4',
      ptv: true,
      contextInfo: {
        mentionedJid: [msg.key?.participant || from],
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
          newsletterJid: '120363411937339682@newsletter',
          newsletterName: '⏤͟͟͞͞★꙲⃝͟𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 │ CHANNEL ◌Ⳋ𝅄',
          serverMessageId: -1
        }
      }
    }, { quoted: msg })

    await react('✅')
  }
}