import axios from "axios"

export default {
  name: ["chatgpt", "gpt", "ذكاء"],
  description: "دردشة مع ChatGPT",
  category: "ia, ذكاء",
  ownerOnly: false,

  async run({ sock, from, msg, text, reply, react }) {
    if (!text) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ماذا تريد أن تسأل ChatGPT؟\n` +
          `> •┊˹💡˼┊مثال ⇇ *〘.chatgpt هلا كيفك〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    try {
      await react("🤖")

      const { data } = await axios.get("https://api.alyacore.xyz/ai/chatgpt", {
        params: {
          text,
          key: "Duarte-zz12"
        }
      })

      if (!data.status || !data.result) {
        await react("❌")
        return reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊لم أتمكن من الحصول على رد من ChatGPT، جرب مرة أخرى.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      // ── زخرفة الرد ──
      const formattedReply = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🤖رد الـذكـاء الاصـطـنـاعـي⏤͟ू⃪🤖』*\n` +
        `> •┊˹❓˼┊السؤال ⇇ *〘${text.slice(0, 50)}${text.length > 50 ? '...' : ''}〙*\n\n` +
        `> •┊˹💬˼┊الرد:\n${data.result}\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await reply({ text: formattedReply })
      await react("✅")
    } catch (err) {
      console.error(err)
      await react("❌")
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ في الاتصال مع API الخاص بـ ChatGPT.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}