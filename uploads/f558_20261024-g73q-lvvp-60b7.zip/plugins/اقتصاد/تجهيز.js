import { db } from "../../database/db.js";
import { ITEMS } from "../../core/gamedata.js";
import { decorBox, decorLine } from "../../core/decor.js";

function getPersonajes(jid) {
  const user = db.getUser(jid);
  return user.personajes || {};
}

export default {
  name: ["equipar", "equip", "تجهيز"],
  description: "يجهّز سلاح أو درع لعضو بالعائلة",
  category: "economy",

  async run({ sender, args, reply, react }) {
    const itemId = args[0]?.toLowerCase();
    const personajeId = args[1]?.toLowerCase();

    if (!itemId || !personajeId) {
      return await reply({
        text: `⚠️ *الاستخدام:* .equipar <غرض> <عضو>\n\n*مثال:* .equipar pistola elpadrino`
      });
    }

    const item = ITEMS[itemId];
    if (!item) {
      return await reply({ text: "❌ الغرض مو موجود.\n\n> استخدم *.tienda* عشان تشوف الأغراض." });
    }

    const misPersonajes = getPersonajes(sender);
    const personaje = misPersonajes[personajeId];
    if (!personaje) {
      return await reply({ text: "❌ ما عندك هذا العضو.\n\n> استخدم *.buychar* عشان تشتريه." });
    }

    const eco = db.getEco(sender);
    if (!eco.inventario.includes(itemId)) {
      return await reply({ text: "❌ ما عندك هذا الغرض بحقيبتك.\n\n> استخدم *.comprar* عشان تشتريه." });
    }

    if (item.restriccion && item.restriccion !== personajeId) {
      return await reply({
        text: `🔒 *${item.nombre}* خاص بـ *${item.restriccion}* بس، ما تقدر تحطه لهذا العضو.`
      });
    }

    personaje[item.tipo] = itemId;
    misPersonajes[personajeId] = personaje;
    db.setUser(sender, { personajes: misPersonajes });

    await react("✅");
    await reply({
      text: decorBox('✅ تـجـهـيـز نـاجـح', [
        decorLine('🎒', 'الـغـرض', item.nombre),
        decorLine('🏷️', 'الـنـوع', item.tipo),
        decorLine('⚡', 'الـقـوة', `+${item.poder}`)
      ])
    });
  }
};