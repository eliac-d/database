import { checkCooldown, setCooldown, addBolsillo, formatTime } from "../../core/economy.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["monthly", "mensual", "شهرية"],
  description: "يستلم مكافأتك الشهرية",
  category: "economy",

  async run({ sender, reply }) {
    const status = checkCooldown(sender, "monthly");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ مـكـافـأة شـهـريـة', [
          decorLine('⏳', 'الـحـالـة', `استلمتها، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    const amount = Math.floor(Math.random() * 6000) + 4000;
    addBolsillo(sender, amount);
    setCooldown(sender, "monthly");

    await reply({
      text: decorBox('💰 مـكـافـأة شـهـريـة', [
        decorLine('💰', 'اسـتـلـمـت', `+${amount} عملة`)
      ])
    });
  }
};