import { xpProgress } from "../../core/xp.js";
import { db } from "../../database/db.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["nivel", "rank", "xp", "المستوى"],
  description: "يعرض مستواك وخبرتك",
  category: "economy",

  async run({ sender, reply }) {
    const user = db.getUser(sender);
    const { level, xp, missing } = xpProgress(user.xp || 0);

    await reply({
      text: decorBox('⭐ مـسـتـواك', [
        decorLine('📊', 'الـمـسـتـوى', level),
        decorLine('✨', 'الـخـبـرة', xp),
        decorLine('⏳', 'مـتـبـقـي', `${missing} خبرة للمستوى ${level + 1}`)
      ])
    });
  }
};