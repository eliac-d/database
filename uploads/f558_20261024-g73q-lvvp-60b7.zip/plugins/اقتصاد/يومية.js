import { db } from "../../database/db.js";
import { checkCooldown, setCooldown, addBolsillo, formatTime } from "../../core/economy.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["daily", "diario", "يومية"],
  description: "يستلم مكافأتك اليومية",
  category: "economy",

  async run({ sender, reply }) {
    const status = checkCooldown(sender, "daily");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ مـكـافـأة يـومـيـة', [
          decorLine('⏳', 'الـحـالـة', `استلمتها، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    const amount = Math.floor(Math.random() * 300) + 200;
    addBolsillo(sender, amount);
    setCooldown(sender, "daily");

    await reply({
      text: decorBox('💰 مـكـافـأة يـومـيـة', [
        decorLine('💰', 'اسـتـلـمـت', `+${amount} عملة`)
      ])
    });
  }
};