import { db } from "../../database/db.js";
import { checkCooldown, setCooldown, formatTime } from "../../core/economy.js";
import { jidNormalizedUser } from "@whiskeysockets/baileys";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["rob", "robar", "سرقة"],
  description: "تحاول تسرق فلوس من مستخدم ثاني",
  category: "economy",
  groupOnly: true,

  async run({ sender, msg, reply, resolveLid }) {
    const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const quotedParticipant = msg.message?.extendedTextMessage?.contextInfo?.participant;
    let targetRaw = mentioned || quotedParticipant;

    if (!targetRaw) {
      return await reply({ text: "『🔫』منشن مين تبي تسرق. الاستخدام: .robar @user" });
    }

    if (targetRaw.endsWith("@lid")) {
      targetRaw = await resolveLid(targetRaw);
    }

    const target = jidNormalizedUser(targetRaw);

    if (target === sender) {
      return await reply({ text: "『🔫』ما تقدر تسرق نفسك، هه." });
    }

    const status = checkCooldown(sender, "rob");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ سـرقـة', [
          decorLine('⏳', 'الـحـالـة', `مختبي من الشرطة، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    const targetEco = db.getEco(target);
    if ((targetEco.bolsillo || 0) < 100) {
      return await reply({ text: "『🔫』هذا الشخص ما عنده فلوس كافية بجيبه عشان تسرقه." });
    }

    setCooldown(sender, "rob");

    const success = Math.random() < 0.4;
    const targetNum = target.split("@")[0];

    if (success) {
      const amount = Math.floor(targetEco.bolsillo * (Math.random() * 0.3 + 0.1));
      db.setEco(target, { bolsillo: targetEco.bolsillo - amount });
      const senderEco = db.getEco(sender);
      db.setEco(sender, { bolsillo: (senderEco.bolsillo || 0) + amount });

      await reply({
        text: decorBox('💸 سـرقـة نـاجـحـة', [
          decorLine('🎯', 'مـن', `@${targetNum}`),
          decorLine('💰', 'سـرقـت', `${amount} عملة`)
        ]),
        mentions: [target]
      });
    } else {
      const senderEco = db.getEco(sender);
      const fine = Math.floor(Math.random() * 150) + 50;
      db.setEco(sender, { bolsillo: Math.max(0, (senderEco.bolsillo || 0) - fine) });

      await reply({
        text: decorBox('🚔 انـمـسـكـت', [
          decorLine('🎯', 'حـاولـت تـسـرق', `@${targetNum}`),
          decorLine('💸', 'الـغـرامـة', `${fine} عملة`)
        ]),
        mentions: [target]
      });
    }
  }
};