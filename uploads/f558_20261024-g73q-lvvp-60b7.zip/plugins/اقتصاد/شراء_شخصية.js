import { db } from "../../database/db.js";
import { PERSONAJES } from "../../core/gamedata.js";
import { decorBox, decorLine } from "../../core/decor.js";

function getPersonajes(jid) {
  const user = db.getUser(jid);
  return user.personajes || {};
}

export default {
  name: ["شراء_شخصية", "buychar"],
  description: "يشتري عضو جديد لعائلتك",
  category: "economy",

  async run({ sock, from, msg, sender, args, reply, react, usedPrefix }) {
    const personajeId = args[0]?.toLowerCase();

    if (personajeId) {
      const personaje = PERSONAJES[personajeId];
      if (!personaje) {
        return await reply({ text: "❌ ما لقيت هذا العضو." });
      }

      const misPersonajes = getPersonajes(sender);
      if (misPersonajes[personajeId]) {
        return await reply({ text: `❌ عندك *${personaje.nombre}* بالفعل.` });
      }

      const eco = db.getEco(sender);
      if (eco.bolsillo < personaje.precio) {
        const faltante = personaje.precio - eco.bolsillo;
        return await reply({
          text: decorBox('❌ فـراجـمـنـتس غـيـر كـافـيـة', [
            decorLine('💰', 'الـسـعـر', `${personaje.precio.toLocaleString()} فراجمنتس`),
            decorLine('👜', 'جـيـبـك', `${eco.bolsillo.toLocaleString()} فراجمنتس`),
            decorLine('⚠️', 'نـاقـصـك', `${faltante.toLocaleString()} فراجمنتس`)
          ])
        });
      }

      misPersonajes[personajeId] = { nivel: 1, xp: 0, arma: null, armadura: null };
      db.setEco(sender, { bolsillo: eco.bolsillo - personaje.precio });
      db.setUser(sender, { personajes: misPersonajes });

      await react("✅");
      return await reply({
        text: decorBox(`✅ اشـتـريـت ${personaje.nombre}`, [
          decorLine('💰', 'الـسـعـر الـمـدفـوع', `${personaje.precio.toLocaleString()} فراجمنتس`),
          decorLine('👜', 'جـيـبـك الآن', `${(eco.bolsillo - personaje.precio).toLocaleString()} فراجمنتس`)
        ]) + `\n\n> استخدم *.equipar <غرض> ${personajeId}* عشان تجهزه`
      });
    }

    let texto = `🕴️ *أعضاء العائلة المتاحين*\n╰━━━━━━(☆)━━━━━━─╮\n\n`;
    for (const [id, personaje] of Object.entries(PERSONAJES)) {
      texto += `*${personaje.nombre}*\n`;
      texto += `   🏷️ ${personaje.generacion === "new_gen" ? "رتبة صغيرة" : "رتبة كبيرة"}\n`;
      texto += `   💰 ${personaje.precio.toLocaleString()} فراجمنتس\n`;
      texto += `   🆔 \`${id}\`\n\n`;
    }
    texto += `> استخدم *.buychar <id>* عشان تشتري`;

    await reply({ text: texto });
  }
};