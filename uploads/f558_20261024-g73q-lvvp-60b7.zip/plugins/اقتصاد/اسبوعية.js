import { checkCooldown, setCooldown, addBolsillo, formatTime } from "../../core/economy.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["weekly", "semanal", "اسبوعية"],
  description: "يستلم مكافأتك الأسبوعية",
  category: "economy",

  async run({ sender, reply }) {
    const status = checkCooldown(sender, "weekly");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ مـكـافـأة أسـبـوعـيـة', [
          decorLine('⏳', 'الـحـالـة', `استلمتها، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    const amount = Math.floor(Math.random() * 1500) + 1000;
    addBolsillo(sender, amount);
    setCooldown(sender, "weekly");

    await reply({
      text: decorBox('💰 مـكـافـأة أسـبـوعـيـة', [
        decorLine('💰', 'اسـتـلـمـت', `+${amount} عملة`)
      ])
    });
  }
};