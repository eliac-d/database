import { ITEMS } from '../../core/gamedata.js'

export default {
  name: ['tienda', 'shop', 'المتجر'],
  description: 'يعرض الأغراض المتاحة للشراء',
  category: 'economy',
  ownerOnly: false,

  async run({ reply, react }) {
    await react('🛒')

    const genericos = Object.entries(ITEMS).filter(([, i]) => !i.restriccion)
    const exclusivos = Object.entries(ITEMS).filter(([, i]) => i.restriccion)

    let texto = `🛒 *متجر الفراجمنتس*\n╰━━━━━━(☆)━━━━━━─╮\n\n`
    texto += `*── أغراض عامة (لأي عضو) ──*\n\n`

    for (const [id, item] of genericos) {
      texto += `*${item.nombre}*\n`
      texto += `   💰 ${item.precio.toLocaleString()} فراجمنتس | ⚡ القوة: ${item.poder}\n`
      texto += `   🆔 \`${id}\`\n\n`
    }

    texto += `*── أغراض خاصة بعضو معين ──*\n\n`

    for (const [id, item] of exclusivos) {
      texto += `*${item.nombre}*\n`
      texto += `   💰 ${item.precio.toLocaleString()} فراجمنتس | ⚡ القوة: ${item.poder}\n`
      texto += `   🔒 بس لـ: *${item.restriccion}*\n`
      texto += `   🆔 \`${id}\`\n\n`
    }

    texto += `> استخدم *.comprar <ID>* عشان تشتري\n> استخدم *.equipar <ID> <عضو>* عشان تجهّزه`

    await reply({ text: texto })
  }
}