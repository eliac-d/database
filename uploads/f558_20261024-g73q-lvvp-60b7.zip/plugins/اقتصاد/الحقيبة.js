import { db } from '../../database/db.js'

const ITEMS_INFO = {
  pala: { nombre: '🪏 مجرفة', bonus: 50 },
  pico: { nombre: '⛏️ فأس', bonus: 120 },
  pistola: { nombre: '🔫 مسدس', bonus: 300 },
  maletin: { nombre: '💼 شنطة فلوس', bonus: 600 },
}

export default {
  name: ['inventario', 'inv', 'الحقيبة'],
  description: 'يعرض حقيبة أغراضك',
  category: 'economy',
  ownerOnly: false,

  async run({ sender, reply, react }) {
    const eco = db.getEco(sender)

    if (!eco.inventario.length) {
      return await reply({
        text: `🎒 حقيبتك فاضية.\n\n> استخدم *.tienda* عشان تشوف الأغراض المتاحة`
      })
    }

    let bonusTotal = 0
    let texto = `🎒 *حقيبتك*\n` +
      `╰━━━━━━(☆)━━━━━━─╮\n\n`

    for (const itemId of eco.inventario) {
      const info = ITEMS_INFO[itemId]
      if (info) {
        bonusTotal += info.bonus
        texto += `*${info.nombre}*\n`
        texto += `   ⚡ بونص: +${info.bonus} فراجمنتس/شغلة\n\n`
      }
    }

    texto += `*📊 إجمالي البونص بالشغلة:* +${bonusTotal} فراجمنتس`

    await react('🎒')
    await reply({ text: texto })
  }
}