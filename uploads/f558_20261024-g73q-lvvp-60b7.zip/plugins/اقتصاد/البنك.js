import { db } from '../../database/db.js'
import { decorBox, decorLine } from '../../core/decor.js'

export default {
  name: ['depositar', 'retirar', 'ايداع', 'سحب'],
  description: 'ينقل الفراجمنتس بين الجيب والبنك',
  category: 'economy',
  ownerOnly: false,

  async run({ sender, cmdName, args, reply, react }) {
    const eco = db.getEco(sender)
    const disponible = cmdName === 'depositar' ? eco.bolsillo : eco.banco

    let cantidad
    const arg = (args[0] || '').toLowerCase()

    if (arg === 'all' || arg === 'todo') {
      cantidad = disponible
    } else {
      cantidad = parseInt(args[0])
    }

    if (!cantidad || isNaN(cantidad) || cantidad <= 0) {
      return await reply({ text: `⚠️ حدد مبلغ صحيح.\n\n*مثال:* .${cmdName} 500\n*أو:* .${cmdName} all` })
    }

    if (cmdName === 'depositar') {
      if (cantidad > eco.bolsillo) {
        return await reply({ text: `❌ ما عندك فراجمنتس كافية بالجيب.\n\n*الجيب:* ${eco.bolsillo} فراجمنتس` })
      }

      db.setEco(sender, {
        bolsillo: eco.bolsillo - cantidad,
        banco: eco.banco + cantidad
      })

      await react('🏦')
      await reply({
        text: decorBox('🏦 إيـداع نـاجـح', [
          decorLine('💰', 'الـمـودع', `${cantidad} فراجمنتس`),
          decorLine('👜', 'الـجـيـب', `${eco.bolsillo - cantidad} فراجمنتس`),
          decorLine('🏦', 'الـبـنـك', `${eco.banco + cantidad} فراجمنتس`)
        ])
      })

    } else if (cmdName === 'retirar') {
      if (cantidad > eco.banco) {
        return await reply({ text: `❌ ما عندك فراجمنتس كافية بالبنك.\n\n*البنك:* ${eco.banco} فراجمنتس` })
      }

      db.setEco(sender, {
        bolsillo: eco.bolsillo + cantidad,
        banco: eco.banco - cantidad
      })

      await react('👜')
      await reply({
        text: decorBox('👜 سـحـب نـاجـح', [
          decorLine('💰', 'الـمـسـحـوب', `${cantidad} فراجمنتس`),
          decorLine('👜', 'الـجـيـب', `${eco.bolsillo + cantidad} فراجمنتس`),
          decorLine('🏦', 'الـبـنـك', `${eco.banco - cantidad} فراجمنتس`)
        ])
      })
    }
  }
}