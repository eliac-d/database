import { db } from '../../database/db.js'
import { decorBox, decorLine } from '../../core/decor.js'

export default {
  name: ['saldo', 'balance', 'bal', 'الرصيد'],
  description: 'يعرض رصيدك من الفراجمنتس',
  category: 'economy',
  ownerOnly: false,

  async run({ sender, senderNum, reply, react }) {
    const eco = db.getEco(sender)
    const total = eco.bolsillo + eco.banco

    await react('💎')
    await reply({
      text: decorBox('💎 رصيـد الـفـراجـمـنـتس', [
        decorLine('👜', 'الـجـيـب', `${eco.bolsillo} فراجمنتس`),
        decorLine('🏦', 'الـبـنـك', `${eco.banco} فراجمنتس`),
        decorLine('📊', 'الإجـمـالـي', `${total} فراجمنتس`)
      ])
    })
  }
}