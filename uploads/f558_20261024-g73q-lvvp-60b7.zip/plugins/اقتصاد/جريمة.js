import { db } from "../../database/db.js";
import { checkCooldown, setCooldown, formatTime } from "../../core/economy.js";
import { decorBox, decorLine } from "../../core/decor.js";

const CRIMENES_EXITO = [
  "سرقت محل وهربت بدون ما حد يشوفك.",
  "اخترقت حساب بنك وسحبت جزء منه.",
  "بعت بضاعة مقلدة بدون ما حد يكتشفك.",
  "نصبت على سائح غافل."
];

const CRIMENES_FALLO = [
  "حاولت تسرق محل بس دق الإنذار وانمسكت.",
  "الشرطة مسكتك وانت تبيع بضاعة مقلدة.",
  "نصبتك كانت سيئة مرة لين الضحية اتصلت بالشرطة.",
  "كاميرات المراقبة كشفتك."
];

export default {
  name: ["crimen", "crime", "جريمة"],
  description: "اسوي جريمة عشوائية، بمخاطرة غرامة",
  category: "economy",

  async run({ sender, reply }) {
    const status = checkCooldown(sender, "crimen");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ جـريـمـة', [
          decorLine('⏳', 'الـحـالـة', `مختبي من القانون، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    setCooldown(sender, "crimen");

    const success = Math.random() < 0.5;
    const eco = db.getEco(sender);

    if (success) {
      const amount = Math.floor(Math.random() * 400) + 150;
      db.setEco(sender, { bolsillo: (eco.bolsillo || 0) + amount });
      const frase = CRIMENES_EXITO[Math.floor(Math.random() * CRIMENES_EXITO.length)];
      await reply({
        text: decorBox('🔫 جـريـمـة نـاجـحـة', [
          decorLine('📖', 'الـقـصـة', frase),
          decorLine('💰', 'كـسـبـت', `+${amount} عملة`)
        ])
      });
    } else {
      const fine = Math.floor(Math.random() * 250) + 100;
      db.setEco(sender, { bolsillo: Math.max(0, (eco.bolsillo || 0) - fine) });
      const frase = CRIMENES_FALLO[Math.floor(Math.random() * CRIMENES_FALLO.length)];
      await reply({
        text: decorBox('🚔 انـمـسـكـت', [
          decorLine('📖', 'الـقـصـة', frase),
          decorLine('💸', 'الـغـرامـة', `${fine} عملة`)
        ])
      });
    }
  }
};