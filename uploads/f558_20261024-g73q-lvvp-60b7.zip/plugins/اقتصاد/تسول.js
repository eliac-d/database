import { checkCooldown, setCooldown, addBolsillo, formatTime } from "../../core/economy.js";
import { decorBox, decorLine } from "../../core/decor.js";

const FRASES_EXITO = [
  "رجل أعطاك شوي فلوس شفقة عليك.",
  "عجوزة وهبتك فكتها.",
  "حد رمى لك فلوس من سيارته.",
  "لقيت عملة بالأرض وانت تتسول."
];

const FRASES_FALLO = [
  "محد أعطاك شي، تجاهلوك تمامًا.",
  "حارس طردك من المكان.",
  "الناس مرت من جنبك بدون ما تشوفك.",
  "قالوا لك \"روح دور شغل\" واستمروا ماشين."
];

export default {
  name: ["mendigar", "beg", "تسول"],
  description: "تتسول وتشوف لو حد يعطيك شي",
  category: "economy",

  async run({ sender, reply }) {
    const status = checkCooldown(sender, "mendigar");
    if (!status.ready) {
      return await reply({
        text: decorBox('⏳ تـسـول', [
          decorLine('⏳', 'الـحـالـة', `تسولت قريب، ارجع بعد ${formatTime(status.remaining)}`)
        ])
      });
    }

    setCooldown(sender, "mendigar");

    const success = Math.random() < 0.55;

    if (success) {
      const amount = Math.floor(Math.random() * 80) + 10;
      addBolsillo(sender, amount);
      const frase = FRASES_EXITO[Math.floor(Math.random() * FRASES_EXITO.length)];
      await reply({
        text: decorBox('🙏 تـسـول', [
          decorLine('📖', 'الـقـصـة', frase),
          decorLine('💰', 'كـسـبـت', `+${amount} عملة`)
        ])
      });
    } else {
      const frase = FRASES_FALLO[Math.floor(Math.random() * FRASES_FALLO.length)];
      await reply({
        text: decorBox('🙏 تـسـول', [
          decorLine('📖', 'الـقـصـة', frase),
          decorLine('💸', 'الـنـتـيـجـة', 'ما كسبت شي هالمرة')
        ])
      });
    }
  }
};