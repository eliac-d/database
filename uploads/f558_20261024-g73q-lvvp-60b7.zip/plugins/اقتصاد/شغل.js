import { db } from '../../database/db.js'
import { decorBox, decorLine } from '../../core/decor.js'

const COOLDOWN = 60 * 60 * 1000 // 1 hora en ms

const TRABAJOS = [
  { texto: '🕴️ حليت مشكلة لعائلتك بهدوء', base: 150 },
  { texto: '💼 خلصت صفقة مربحة', base: 100 },
  { texto: '📜 سلّمت تقرير للعائلة', base: 80 },
  { texto: '🚬 حميت منطقة نفوذك', base: 200 },
  { texto: '🏛️ راقبت محيط المكان', base: 70 },
  { texto: '🤝 عقدت اتفاق مهم', base: 300 },
  { texto: '🍷 جمعت أرباح من الأعمال', base: 120 },
  { texto: '📦 نقلت بضاعة بأمان', base: 90 },
]

const BONUS_ITEMS = {
  'pala':        50,
  'pico':       120,
  'pistola':    300,
  'maletin':    600,
}

export default {
  name: ['work', 'trabajar', 'شغل'],
  description: 'اشتغل عشان تكسب فراجمنتس',
  category: 'economy',
  ownerOnly: false,

  async run({ sender, reply, react }) {
    const eco = db.getEco(sender)
    const ahora = Date.now()
    const tiempoRestante = COOLDOWN - (ahora - eco.lastWork)

    if (tiempoRestante > 0) {
      const mins = Math.floor(tiempoRestante / 60000)
      const segs = Math.floor((tiempoRestante % 60000) / 1000)
      return await reply({
        text: decorBox('⏳ شـغـل', [
          decorLine('⏳', 'الـحـالـة', `اشتغلت قريب، تقدر تشتغل بعد ${mins}د ${segs}ث`)
        ])
      })
    }

    const trabajo = TRABAJOS[Math.floor(Math.random() * TRABAJOS.length)]

    // Calculamos bonus según items en inventario
    let bonus = 0
    for (const itemId of eco.inventario) {
      bonus += BONUS_ITEMS[itemId] ?? 0
    }

    // Ganancia aleatoria dentro de un rango del trabajo elegido
    const variacion = Math.floor(Math.random() * 50) - 25 // ±25
    const ganado = Math.max(10, trabajo.base + variacion + bonus)

    const nuevoBolsillo = eco.bolsillo + ganado

    db.setEco(sender, {
      bolsillo: nuevoBolsillo,
      lastWork: ahora
    })

    await react('💰')
    await reply({
      text: decorBox('💼 شـغـل نـاجـح', [
        decorLine('📖', 'الـمـهـمـة', trabajo.texto),
        decorLine('💰', 'كـسـبـت', `${ganado} فراجمنتس${bonus > 0 ? ` (+${bonus} بونص)` : ''}`),
        decorLine('👜', 'الـجـيـب الآن', `${nuevoBolsillo} فراجمنتس`)
      ]) + `\n\n> ⏳ شغل ثاني بعد *ساعة*`
    })
  }
}