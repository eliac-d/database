import { db } from '../../database/db.js'
import { ITEMS } from '../../core/gamedata.js'
import { decorBox, decorLine } from '../../core/decor.js'

export default {
  name: ['comprar', 'buy', 'شراء'],
  description: 'يشتري غرض من المتجر',
  category: 'economy',
  ownerOnly: false,

  async run({ sender, args, reply, react }) {
    const itemId = args[0]?.toLowerCase()

    if (!itemId) {
      return await reply({ text: `⚠️ حدد معرف الغرض.\n\n*مثال:* .comprar pala\n\n> استخدم *.tienda* عشان تشوف الأغراض المتاحة` })
    }

    const item = ITEMS[itemId]
    if (!item) {
      return await reply({ text: `❌ الغرض مو موجود.\n\n> استخدم *.tienda* عشان تشوف الأغراض المتاحة` })
    }

    const eco = db.getEco(sender)

    if (eco.inventario.includes(itemId)) {
      return await reply({ text: `❌ عندك *${item.nombre}* بحقيبتك بالفعل.` })
    }

    if (eco.bolsillo < item.precio) {
      const faltante = item.precio - eco.bolsillo
      return await reply({
        text: decorBox('❌ فـراجـمـنـتس غـيـر كـافـيـة', [
          decorLine('💰', 'الـسـعـر', `${item.precio.toLocaleString()} فراجمنتس`),
          decorLine('👜', 'جـيـبـك', `${eco.bolsillo.toLocaleString()} فراجمنتس`),
          decorLine('⚠️', 'نـاقـصـك', `${faltante.toLocaleString()} فراجمنتس`)
        ])
      })
    }

    const nuevoInventario = [...eco.inventario, itemId]
    db.setEco(sender, {
      bolsillo: eco.bolsillo - item.precio,
      inventario: nuevoInventario
    })

    await react('✅')
    await reply({
      text: decorBox('✅ تـم الـشـراء', [
        decorLine('🎒', 'الـغـرض', item.nombre),
        decorLine('💰', 'الـسـعـر الـمـدفـوع', `${item.precio.toLocaleString()} فراجمنتس`),
        decorLine('👜', 'جـيـبـك الآن', `${(eco.bolsillo - item.precio).toLocaleString()} فراجمنتس`)
      ]) + `\n\n> استخدم *.equipar ${itemId} <عضو>* عشان تعطيه لعضو`
    })
  }
}