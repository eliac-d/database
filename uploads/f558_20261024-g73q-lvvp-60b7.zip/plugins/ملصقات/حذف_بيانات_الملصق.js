import { db } from '../../database/db.js'
import config from '../../config.js'

export default {
  name: ['delmeta', 'حذف_العلامة'],
  description: 'يرجّع علامة ملصقاتك لعلامة البوت',
  category: 'stickers, ستيكرات',
  ownerOnly: false,

  async run({ senderNum, react, reply }) {
    await react('🗑️')

    const user = db.getUser(senderNum)

    if (!user.text1 && !user.text2) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ليس لديك أي علامة مخصصة محددة.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    db.setUser(senderNum, {
      text1: null,
      text2: null
    })

    await reply({
      text: 
        `*『͟͞ू⃪ ✅تـم الإرجـاع⏤͟ू⃪✅』*\n` +
        `> •┊˹📌˼┊تم إرجاع العلامة إلى علامة البوت الافتراضية.\n\n` +
        `> •┊˹📦˼┊الحزمة ⇇ *〘${config.botname}〙*\n` +
        `> •┊˹✍️˼┊المؤلف ⇇ *〘${config.author}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })

    await react('✅')
  }
}