import { db } from '../../database/db.js'

export default {
  name: ['setmeta', 'تعيين_العلامة'],
  description: 'يغيّر علامة ملصقاتك',
  category: 'stickers, ستيكرات',
  ownerOnly: false,

  async run({ senderNum, text, react, reply }) {
    await react('⚙️')

    if (!text) {
      return await reply({
        text:
          `*『͟͞ू⃪ ⚙️تـنـبـيـه⏤͟ू⃪⚙️』*\n` +
          `> •┊˹💡˼┊الاستخدام:\n` +
          `> ┊˹📝˼┊*.setmeta المؤلف*\n` +
          `> ┊˹📝˼┊*.setmeta الحزمة | المؤلف*\n\n` +
          `> •┊˹✏️˼┊مثال:\n` +
          `> ┊˹📌˼┊*.setmeta سونغ*\n` +
          `> ┊˹📌˼┊*.setmeta AYANOKOJI BOT | سونغ*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const user = db.getUser(senderNum)

    if (user.text1 || user.text2) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️مـسـبـقـاً⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لديك علامة محددة بالفعل.\n` +
          `> •┊˹💡˼┊استخدم *〘.delmeta〙* لحذفها أولاً.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const texto = text.trim()
    let packName = ''
    let authorName = ''

    if (texto.includes('|')) {
      const [pack, author] = texto.split('|').map(v => v.trim())
      packName = pack || texto
      authorName = author || texto
    } else {
      packName = texto
      authorName = texto
    }

    db.setUser(senderNum, { text1: packName, text2: authorName });

    await reply({
      text:
        `*『͟͞ू⃪ ✅تـم الـتـحـديـث⏤͟ू⃪✅』*\n` +
        `> •┊˹📦˼┊الحزمة ⇇ *〘${packName}〙*\n` +
        `> •┊˹✍️˼┊المؤلف ⇇ *〘${authorName}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })
    await react('✅')
  }
}