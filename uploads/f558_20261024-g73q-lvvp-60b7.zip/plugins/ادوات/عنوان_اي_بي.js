import axios from 'axios';

export default {
  name: ["ip", "عنوان_اي_بي"],
  description: "يبحث عن معلومات عنوان IP",
  category: "utils, أدوات",
  ownerOnly: false,

  async run({ text, reply, usedPrefix, cmdName, react }) {
    if (!text) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊رجاءً ادخل عنوان *IP*.\n` +
          `> •┊˹📝˼┊مثال ⇇ *〘${usedPrefix}${cmdName} 8.8.8.8〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    try {
      await react("🔍")
      
      await reply({ 
        text: 
          `*『͟͞ू⃪ 🌾جـاري الـبـحـث⏤͟ू⃪🌾』*\n` +
          `> •┊˹⏳˼┊_لحظة..._\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });

      const res = await axios.get(
        `http://ip-api.com/json/${text}?fields=status,message,country,countryCode,region,regionName,city,district,zip,lat,lon,timezone,isp,org,as,mobile,hosting,query`
      );
      const data = res.data;

      if (String(data.status) !== 'success') {
        throw new Error(data.message || 'فشل جلب البيانات');
      }

      const ipsearch = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ ☁️مـعـلـومـات الـ IP⏤͟ू⃪☁️』*\n` +
        `> •┊˹🌐˼┊عنوان IP ⇇ *〘${data.query}〙*\n` +
        `> •┊˹🏳️˼┊الدولة ⇇ *〘${data.country} (${data.countryCode})〙*\n` +
        `> •┊˹🗺️˼┊المنطقة ⇇ *〘${data.regionName} (${data.region})〙*\n` +
        `> •┊˹🏙️˼┊المدينة ⇇ *〘${data.city}〙*\n` +
        `> •┊˹🏘️˼┊الحي ⇇ *〘${data.district || 'غير متاح'}〙*\n` +
        `> •┊˹📮˼┊الرمز البريدي ⇇ *〘${data.zip || 'غير متاح'}〙*\n` +
        `> •┊˹⏰˼┊المنطقة الزمنية ⇇ *〘${data.timezone}〙*\n\n` +
        
        `*『͟͞ू⃪ 📡مـعـلـومـات الـمـزود⏤͟ू⃪📡』*\n` +
        `> •┊˹🏢˼┊مزود الخدمة ⇇ *〘${data.isp}〙*\n` +
        `> •┊˹🏛️˼┊المؤسسة ⇇ *〘${data.org}〙*\n` +
        `> •┊˹🔢˼┊AS ⇇ *〘${data.as}〙*\n` +
        `> •┊˹📱˼┊شبكة جوال ⇇ *〘${data.mobile ? 'نعم' : 'لا'}〙*\n` +
        `> •┊˹☁️˼┊استضافة ⇇ *〘${data.hosting ? 'نعم' : 'لا'}〙*\n\n` +
        
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      await reply({ text: ipsearch });
      await react("✅")

    } catch (e) {
      await react("❌")
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};