async function resolverJid(sock, jid) {
    if (!jid) return null
    if (!jid.endsWith('@lid')) {
        return jid.split(':')[0].split('@')[0] + '@s.whatsapp.net'
    }
    try {
        const pn = await sock.signalRepository?.lidMapping?.getPNForLID(jid)
        if (pn) return pn.split(':')[0].split('@')[0] + '@s.whatsapp.net'
    } catch {}
    return jid 
}

export default {
    name: ['inspect', 'inspeccionar', 'فحص'],
    description: 'يفحص رابط قروب، مجتمع أو قناة واتساب',
    category: 'utils, أدوات',

    async run({ sock, from, msg, text, reply }) {
        const sender = msg.key.participant || msg.key.remoteJid

        let fkontak = {
            "key": {
                "participants": "0@s.whatsapp.net",
                "remoteJid": "status@broadcast",
                "fromMe": false,
                "id": "Halo"
            },
            "message": {
                "contactMessage": {
                    "vcard": `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
                }
            },
            "participant": "0@s.whatsapp.net"
        }

        if (!text) return await reply({ text: '```ⓘ ادخل رابط قروب، مجتمع أو قناة.```' })

        const groupUrl = text.match(/(?:https?:\/\/)?(?:chat\.whatsapp\.com\/)([0-9A-Za-z]{22,24})/i)?.[1]
        const channelUrl = text.match(/(?:https?:\/\/)?(?:whatsapp\.com\/channel\/)([0-9A-Za-z@.]+)/i)?.[1]

        let caption = ''
        let mentions = []

        // ─── CANAL (قناة) ───
        if (channelUrl) {
            try {
                const info = await sock.newsletterMetadata("invite", channelUrl).catch(() => null)

                if (!info) {
                    return await reply({ text: `❌ ما لقيت معلومات القناة. تأكد إن الرابط صحيح.` })
                }

                const meta = info.thread_metadata || {}

                const id = info.id || 'غير موجود'
                const nombre = meta.name?.text || 'بدون اسم'
                const descripcion = meta.description?.text || 'بدون وصف'
                const suscriptores = meta.subscribers_count ?? 'غير متاح'
                const verificado = meta.verification === 'VERIFIED' ? '✅ موثّق' : '❌ غير موثّق'

                caption =
`*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*
*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*

*『͟͞ू⃪ 🌺مـعـلـومـات الـقـنـاة⏤͟ू⃪🌺』*
> •┊˹🪪˼┊الاسم ⇇ *〘${nombre}〙*
> •┊˹🆔˼┊المعرف ⇇ *〘${id}〙*
> •┊˹👥˼┊المشتركين ⇇ *〘${suscriptores}〙*
> •┊˹✔️˼┊التوثيق ⇇ *〘${verificado}〙*
> •┊˹📝˼┊الوصف ⇇ *〘${descripcion}〙*

*⌬──══─┈•⤣🌺⤤•┈─══──⌬*

*╮═══『┃ ملاحظـة ◜┃』═══╭*
*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*
*╯✯≼══━━﹂🌺﹁━━══≽✯*
*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

            } catch (e) {
                console.error('خطأ بالقناة:', e)
                return await reply({ text: `❌ خطأ بجلب معلومات القناة.` })
            }

        // ─── GRUPO / COMUNIDAD (قروب / مجتمع) ───
        } else if (groupUrl) {
            try {
                const info = await sock.groupGetInviteInfo(groupUrl).catch(() => null)

                if (!info) {
                    return await reply({ text: `❌ ما لقيت معلومات. تأكد إن الرابط صحيح.` })
                }

                const id = info.id || 'غير موجود'
                const nombre = info.subject || 'بدون اسم'
                const descripcion = info.desc || 'بدون وصف'
                const participantes = info.size ?? info.participants?.length ?? 'غير متاح'
                const esComunidad = !!info.isCommunity

                const creadorJid = await resolverJid(sock, info.ownerPn || info.owner)
                let creador = 'غير متاح / خرج من القروب'
                if (creadorJid) {
                    creador = `@${creadorJid.split('@')[0]}`
                    mentions.push(creadorJid)
                }

                const creacion = info.creation
                    ? new Date(info.creation * 1000).toLocaleDateString('ar')
                    : 'غير متاح'

                caption =
`*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*
*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*

*『͟͞ू⃪ 🌺مـعـلـومـات الـ${esComunidad ? 'مـجـتـمـع' : 'ـقـروب'}⏤͟ू⃪🌺』*
> •┊˹📛˼┊الاسم ⇇ *〘${nombre}〙*
> •┊˹🆔˼┊المعرف ⇇ *〘${id}〙*
> •┊˹👑˼┊المنشئ ⇇ *〘${creador}〙*
> •┊˹👥˼┊الأعضاء ⇇ *〘${participantes}〙*
> •┊˹📅˼┊تاريخ الإنشاء ⇇ *〘${creacion}〙*
> •┊˹📝˼┊الوصف ⇇ *〘${descripcion}〙*

*⌬──══─┈•⤣🌺⤤•┈─══──⌬*

*╮═══『┃ ملاحظـة ◜┃』═══╭*
*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*
*╯✯≼══━━﹂🌺﹁━━══≽✯*
*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

            } catch (e) {
                console.error('خطأ بالقروب/المجتمع:', e)
                return await reply({ text: `❌ خطأ بجلب معلومات القروب أو المجتمع.` })
            }

        } else {
            return await reply({ text: `❌ ما لقيت رابط صحيح لقروب، مجتمع أو قناة واتساب.` })
        }

        await sock.sendMessage(from, {
            text: caption,
            contextInfo: { mentionedJid: mentions }
        }, { quoted: fkontak })
    }
}