import axios from 'axios';

const API_URL = 'https://api.lempi.lat/tools/wabancheck';
const API_KEY = 'Duarte-1311-2026';

function limpiarNumero(input) {
  return input.replace(/\D/g, '');
}

export default {
  name: ["checkban", "banwa", "فحص_الحظر"],
  description: "يتحقق من حظر رقم واتساب",
  category: "utils, أدوات",
  ownerOnly: false,

  async run({ text, reply, usedPrefix, cmdName, react }) {
    if (!text) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊رجاءً ادخل رقم هاتف.\n` +
          `> •┊˹📝˼┊مثال ⇇ *〘${usedPrefix}${cmdName} 967735541558〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const numero = limpiarNumero(text);
    if (numero.length < 8) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌رقـم غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊تأكد من كتابة الرقم مع رمز الدولة.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    try {
      await react("🔍")
      
      await reply({ 
        text: 
          `*『͟͞ू⃪ 🌾جـاري الـفـحـص⏤͟ू⃪🌾』*\n` +
          `> •┊˹⏳˼┊_جاري فحص حالة الرقم، لحظة..._\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });

      const { data } = await axios.get(API_URL, {
        params: {
          lang: 'ar',
          apikey: API_KEY,
          number: numero
        },
        timeout: 15000
      });

      if (!data?.status || !data?.resultado?.status) {
        await react("❌")
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊ما قدرت أفحص الرقم. جرب مرة أخرى لاحقاً.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      const d = data.resultado.data;
      const info = d.violation_info || {};

      let texto = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🔍نـتـيـجـة الـفـحـص⏤͟ू⃪🔍』*\n` +
        `> •┊˹📱˼┊الرقم ⇇ *〘${data.resultado.number}〙*\n` +
        `> •┊˹🚫˼┊محظور ⇇ *〘${d.isBanned ? 'نعم ✅' : 'لا ❌'}〙*\n` +
        `> •┊˹⏳˼┊حظر دائم ⇇ *〘${d.isPermanent ? 'نعم ✅' : 'لا ❌'}〙*\n` +
        `> •┊˹🛡️˼┊يحتاج واتساب رسمي ⇇ *〘${d.isNeedOfficialWa ? 'نعم ✅' : 'لا ❌'}〙*\n\n` +

        `*『͟͞ू⃪ ⚠️تـفـاصـيـل الـمـخـالـفـة⏤͟ू⃪⚠️』*\n` +
        `> •┊˹📌˼┊نوع المخالفة ⇇ *〘${d.violation_type ?? 'غير متاح'}〙*\n` +
        `> •┊˹📝˼┊السبب ⇇ *〘${d.status_message ?? 'غير متاح'}〙*\n` +
        `> •┊˹📋˼┊الوصف ⇇ *〘${info.description ?? 'غير متاح'}〙*\n` +
        `> •┊˹⏱˼┊المدة ⇇ *〘${info.duration ?? 'غير متاح'}〙*\n` +
        `> •┊˹🚨˼┊الخطورة ⇇ *〘${info.risk ?? 'غير متاح'}〙*\n` +
        `> •┊˹⚖️˼┊قابل للاستئناف بالتطبيق ⇇ *〘${d.in_app_ban_appeal ? 'نعم ✅' : 'لا ❌'}〙*\n\n` +

        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      await reply({ text: texto });
      await react("✅")

    } catch (e) {
      await react("❌")
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};