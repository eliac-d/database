export default {
  name: ["ping", "p", "بينج"],
  description: "يقيس زمن استجابة البوت",
  category: "utils, أدوات",
  ownerOnly: false,

  async run({ sock, from, msg, reply, react }) {
    const start = Date.now();

    await react("🏓");

    const sent = await reply({ 
      text: 
        `*『͟͞ू⃪ 🏓جـاري الـقـيـاس⏤͟ू⃪🏓』*\n` +
        `> •┊˹⏳˼┊زمن الاستجابة: جاري القياس...\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });

    const latencia = Date.now() - start;

    await sock.sendMessage(from, {
      text: 
        `*『͟͞ू⃪ 🏓pong!⏤͟ू⃪🏓』*\n` +
        `> •┊˹⚡˼┊زمن الاستجابة ⇇ *〘${latencia}ms〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
      edit: sent.key
    });
  },
};