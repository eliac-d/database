import { broadcastReaccionCanal } from '../../core/subbotManager.js'

export default {
  name: ['reactcanal', 'تفاعل_القناة'],
  description: 'يخلي كل البوتات تتفاعل مع رسالة قناة',
  category: 'utils, أدوات',
  ownerOnly: false,

  async run({ sock, args, reply, react }) {
    const [link, emoji] = args

    if (!link || !emoji) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊الاستخدام ⇇ *〘.reactcanal <رابط الرسالة> <إيموجي>〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const match = link.match(/channel\/([A-Za-z0-9]+)\/(\d+)/)
    if (!match) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌رابـط غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊هذا ليس رابطاً صحيحاً لرسالة قناة.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const [, invite, serverId] = match

    await react('🐢')
    await reply({ 
      text: 
        `*『͟͞ू⃪ 🐢جـاري الـمـعـالـجـة⏤͟ू⃪🐢』*\n` +
        `> •┊˹⏳˼┊جاري التفاعل بـ *〘${emoji}〙* من كل البوتات (~5 ثواني).\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })

    let canalJid
    try {
      const meta = await sock.newsletterMetadata('invite', invite)
      canalJid = meta.id
    } catch (e) {
      console.error('لم أتمكن من جلب القناة:', e)
      await react('❌')
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لم أجد القناة. تأكد من الرابط.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    let res
    try {
      res = await broadcastReaccionCanal({ canalJid, serverId, emoji, ventanaMs: 5000 })
    } catch (e) {
      console.error('خطأ بالبث:', e)
      await react('❌')
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ أثناء التفاعل.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    if (res.ok > 0) {
      await react('✅')
      await reply({
        text: 
          `*『͟͞ू⃪ ✅تـم الـتـفـاعـل⏤͟ू⃪✅』*\n` +
          `> •┊˹🤖˼┊النجاح ⇇ *〘${res.ok}/${res.total}〙*\n` +
          `> •┊˹😊˼┊التفاعل ⇇ *〘${emoji}〙*\n` +
          (res.fail ? `> •┊˹❌˼┊فشل ⇇ *〘${res.fail}〙*\n` : '') +
          `\n*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    } else {
      await react('❌')
      await reply({ 
        text: 
          `*『͟͞ू⃪ ❌فـشـل⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊لم يتمكن أي بوت من التفاعل. تأكد من الرابط.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}