import { getAllSockets } from "../../core/subbotManager.js"

const REPORT_GROUP_ID = "120363411937339682@g.us"

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

async function enviarConCualquierBot(sockOriginal, payload) {
  const candidatos = [sockOriginal, ...getAllSockets()]
  const probados = new Set()

  for (const s of candidatos) {
    if (!s || probados.has(s)) continue
    probados.add(s)
    try {
      await s.sendMessage(REPORT_GROUP_ID, payload)
      return true
    } catch (e) {
      continue
    }
  }
  return false
}

export default {
  name: ["report", "reportar", "ابلاغ"],
  description: "يبعث بلاغ لجروب الدعم",
  category: "utils, أدوات",
  ownerOnly: false,

  async run({ sock, from, msg, text, reply, senderNum, isGroup, groupName, groupMeta }) {
    const quoted = msg.message?.extendedTextMessage?.contextInfo

    if (!text && !quoted?.stanzaId) {
      return await reply({
        text: "꒰✖️꒱  ᰍ اكتب سبب البلاغ أو رد على رسالة.\n\n`✎..مثال:` *.ابلاغ* البوت لا يعمل عندي."
      })
    }

    const participants = groupMeta?.participants || []
    let senderRaw = msg.key.participantAlt || msg.key.participant || `${senderNum}@s.whatsapp.net`
    senderRaw = senderRaw.split(':')[0]
    let senderJid = cleanJid(senderRaw)
    if (senderRaw.endsWith('@lid')) {
      const match = participants.find(p => p.lid === senderRaw)
      if (match) senderJid = cleanJid(match.id)
    }
    const senderNumResolved = senderJid.split('@')[0]

    const origen = isGroup ? `قروب: ${groupName}` : "محادثة خاصة"

    let textoReporte = `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n`
    textoReporte += `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n`
    textoReporte += `*『͟͞ू⃪ 🌺بـلاغ جـديـد⏤͟ू⃪🌺』*\n`
    textoReporte += `> •┊˹👤˼┊من ⇇ *〘@${senderNumResolved}〙*\n`
    textoReporte += `> •┊˹📍˼┊المصدر ⇇ *〘${origen}〙*\n`

    if (text) {
      textoReporte += `> •┊˹📝˼┊السبب ⇇ *〘${text}〙*\n`
    } else {
      textoReporte += `> •┊˹📝˼┊السبب ⇇ *〘(الرسالة المقتبسة بالأعلى)〙*\n`
    }

    textoReporte += `\n*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`
    textoReporte += `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n`
    textoReporte += `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n`
    textoReporte += `*╯✯≼══━━﹂🌺﹁━━══≽✯*\n`
    textoReporte += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

    try {
      if (quoted?.stanzaId) {
        await enviarConCualquierBot(sock, {
          forward: {
            key: {
              remoteJid: from,
              id: quoted.stanzaId,
              participant: quoted.participant,
              fromMe: false
            },
            message: quoted.quotedMessage
          }
        })
      }

      const enviado = await enviarConCualquierBot(sock, {
        text: textoReporte,
        mentions: [senderJid]
      })

      if (!enviado) {
        return await reply({ text: `❌ لم أتمكن من إرسال البلاغ: لا يوجد أي بوت متصل في مجموعة الدعم.` })
      }

      await reply({ text: "✅ تم إرسال بلاغك لفريق الدعم. شكرًا لك!" })
    } catch (e) {
      await reply({ text: `❌ لم أتمكن من إرسال البلاغ: ${e.message}` })
    }
  }
}