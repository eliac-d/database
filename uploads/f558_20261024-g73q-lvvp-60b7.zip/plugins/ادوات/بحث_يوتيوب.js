const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36'

async function buscarYouTube(query, limite = 5) {
  const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(query)}&hl=ar`
  const res = await fetch(url, {
    headers: {
      'User-Agent': UA,
      'Accept-Language': 'ar,en;q=0.9',
      'Cookie': 'CONSENT=YES+1; SOCS=CAI'
    }
  })
  const html = await res.text()

  const m = html.match(/var ytInitialData\s*=\s*(\{.+?\});<\/script>/s)
  if (!m) throw new Error('تعذر قراءة صفحة يوتيوب')

  const data = JSON.parse(m[1])
  const secciones =
    data?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || []

  const resultados = []
  for (const sec of secciones) {
    for (const item of sec?.itemSectionRenderer?.contents || []) {
      const v = item.videoRenderer
      if (!v?.videoId || !v.lengthText) continue // تجاهل البث المباشر، الشورتس، والإعلانات

      resultados.push({
        id: v.videoId,
        titulo: v.title?.runs?.[0]?.text || 'بدون عنوان',
        canal: v.ownerText?.runs?.[0]?.text || 'غير معروف',
        duracion: v.lengthText?.simpleText || '--:--',
        vistas: v.viewCountText?.simpleText || '',
        fecha: v.publishedTimeText?.simpleText || '',
        url: `https://youtu.be/${v.videoId}`,
        thumb: `https://i.ytimg.com/vi/${v.videoId}/hqdefault.jpg`
      })
      if (resultados.length >= limite) return resultados
    }
  }
  return resultados
}

export default {
  name: ['ytsearch', 'yts', 'بحث_يوتيوب', 'يوتيوب'],
  description: 'يبحث عن أغاني أو فيديوهات في يوتيوب',
  category: 'utils, أدوات',

  async run({ sock, from, msg, text, reply, react }) {
    if (!text) {
      return await reply({ text: '🎩 استخدم: *.ytsearch <أغنية أو فنان>*' })
    }

    await react('⏳')

    try {
      const lista = await buscarYouTube(text, 5)

      if (!lista.length) {
        await react('❌')
        return await reply({ text: '📭 لم يتم العثور على نتائج.' })
      }

      let cap = `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n`
      cap += `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n`
      cap += `*『͟͞ू⃪ 🌺نـتـائـج الـبـحـث⏤͟ू⃪🌺』*\n`
      cap += `> •┊˹🔍˼┊البحث ⇇ *〘${text}〙*\n\n`

      lista.forEach((r, i) => {
        cap += `*┇◞ ${i + 1}. ${r.titulo}*\n`
        cap += `> •┊˹📺˼┊القناة ⇇ *〘${r.canal}〙*\n`
        cap += `> •┊˹⏱˼┊المدة ⇇ *〘${r.duracion}${r.vistas ? ' • ' + r.vistas : ''}${r.fecha ? ' • ' + r.fecha : ''}〙*\n`
        cap += `> •┊˹🔗˼┊الرابط ⇇ ${r.url}\n\n`
      })

      cap += `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`
      cap += `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n`
      cap += `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n`
      cap += `*╯✯≼══━━﹂🌺﹁━━══≽✯*\n`
      cap += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sock.sendMessage(from, {
        image: { url: lista[0].thumb },
        caption: cap.trim()
      }, { quoted: msg })

      await react('✅')
    } catch (e) {
      console.error('خطأ ytsearch:', e)
      await react('❌')
      await reply({ text: '⚠︎ تعذر البحث في يوتيوب حالياً.' })
    }
  }
}