export default {
  name: ["spoiler", "حرق_احداث"],
  description: "يبعث رسالة طويلة يقصّها واتساب بـ 'قراءة المزيد' بنفس السطر",
  category: "utils, أدوات",
  ownerOnly: false,

  async run({ reply, text }) {
    if (!text) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊اكتب النص الذي تريد إخفاءه.\n` +
          `> •┊˹📝˼┊مثال ⇇ *〘.spoiler الجواب هو 42〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const partes = text.split("|").map(p => p.trim())
    const visible = partes[0]
    const oculto = partes[1] || partes[0]

    // Zero-width space: لا يأخذ مساحة ظاهرة ولا يُنشئ سطراً جديداً،
    // فتبقى كلمة "قراءة المزيد" ملتصقة بعد النص الظاهر مباشرة.
    const relleno = "\u200b".repeat(3000)

    const mensaje = `${visible}${relleno}${oculto}`

    await reply({ text: mensaje })
  }
}