import { xpProgress } from "../../core/xp.js";
import { db } from "../../database/db.js";

const FALLBACK_PHOTO = "https://cdn.dix.lat/me/0b0v_20260828-c91x-qz9u-550c.jpg";

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

function labelPorGenero(jid) {
  const genero = (db.getGenero(jid) || "").toLowerCase();
  if (genero === "hombre") return "زوج";
  if (genero === "mujer") return "زوجة";
  return "شريك";
}

function labelSoltero(jid) {
  const genero = (db.getGenero(jid) || "").toLowerCase();
  if (genero === "hombre") return "أعزب";
  if (genero === "mujer") return "عزباء";
  return "أعزب";
}

export default {
  name: ["بروفايل", "profile"],
  description: "يعرض بروفايلك: الصورة، العملات والخبرة",
  category: "info, معلومات",

  async run({ sock, sender, from, msg, groupMeta, resolveLid, reply }) {
    const contextInfo = msg?.message?.extendedTextMessage?.contextInfo;

    let targetJid = null;
    if (contextInfo?.mentionedJid?.length > 0) {
      targetJid = contextInfo.mentionedJid[0];
    } else if (contextInfo?.participant) {
      targetJid = contextInfo.participant;
    }

    let target = sender;
    if (targetJid) {
      if (targetJid.endsWith("@lid") || isNaN(targetJid.split("@")[0])) {
        const found = groupMeta?.participants?.find((p) => p.id === targetJid || p.lid === targetJid);
        if (found?.id) targetJid = found.id;
      }
      if (targetJid.endsWith("@lid")) {
        targetJid = await resolveLid(targetJid);
      }
      target = cleanJid(targetJid);
    }

    const user = db.getUser(target);
    const eco = db.getEco(target);
    const partner = db.getMarriage(target);
    const { level, xp, missing } = xpProgress(user.xp || 0);

    let photoUrl = FALLBACK_PHOTO;
    try {
      photoUrl = await sock.profilePictureUrl(target, "image");
    } catch {
      // Sin foto o privacidad restringida: se usa la foto de respaldo
    }

    const total = eco.bolsillo + eco.banco;
    const mention = `@${target.split("@")[0]}`;

    const parejaLine = partner
      ? `> •┊˹💍˼┊${labelPorGenero(partner)} ⇇ @${partner.split("@")[0]}\n`
      : `> •┊˹💔˼┊الحالة ⇇ *〘${labelSoltero(target)}〙*\n`;

    const caption =
      `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
      `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
      `*『͟͞ू⃪ 🍮بـروفـايـل الـعـضـو⏤͟ू⃪🍮』*\n` +
      `> •┊˹👤˼┊العضو ⇇ ${mention}\n\n` +
      `*『͟͞ू⃪ 💰مـعـلـومـات الاقـتـصـاد⏤͟ू⃪💰』*\n` +
      `> •┊˹💰˼┊العملات ⇇ *〘${total}〙*\n` +
      `> •┊˹👝˼┊الجيب ⇇ *〘${eco.bolsillo}〙*\n` +
      `> •┊˹🏦˼┊البنك ⇇ *〘${eco.banco}〙*\n\n` +
      `*『͟͞ू⃪ ⚡مـعـلـومـات الـمـسـتـوى⏤͟ू⃪⚡』*\n` +
      `> •┊˹⚡˼┊المستوى ⇇ *〘${level}〙*\n` +
      `> •┊˹✨˼┊الخبرة ⇇ *〘${xp}〙*\n` +
      `> •┊˹📈˼┊متبقي للمستوى ${level + 1} ⇇ *〘${missing}〙*\n` +
      parejaLine +
      `\n*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
      `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

    const mentions = partner ? [target, partner] : [target];

    try {
      await sock.sendMessage(
        from,
        { image: { url: photoUrl }, caption, mentions },
        { quoted: msg }
      );
    } catch (error) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊خطأ في عرض البروفايل: ${error.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
      console.error("خطأ في البروفايل:", error);
    }
  }
};