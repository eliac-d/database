import { db } from "../../database/db.js";

const VALIDOS = ["hombre", "mujer", "ذكر", "أنثى"];

export default {
  name: ["الجنس", "setgenre"],
  description: "يحدد جنسك (ذكر/أنثى) لبروفايلك",
  category: "info, معلومات",
  ownerOnly: false,

  async run({ sender, text, reply }) {
    const genero = (text || "").trim().toLowerCase();

    if (!VALIDOS.includes(genero)) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊يمكنك اختيار *hombre* (ذكر) أو *mujer* (أنثى) فقط.\n\n` +
          `> •┊˹📝˼┊مثال ⇇ *〘.الجنس hombre〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    // توحيد القيمة لتُخزن دائماً بالإنجليزية ليتعرف عليها البوت
    const generoFinal = (genero === "ذكر" || genero === "hombre") ? "hombre" : "mujer";
    
    db.setGenero(sender, generoFinal);

    return await reply({ 
      text: 
        `*『͟͞ू⃪ ✅تـم الـتـحـديـث⏤͟ू⃪✅』*\n` +
        `> •┊˹👤˼┊تم تعيين جنسك بنجاح.\n` +
        `> •┊˹📌˼┊ستظهر الآن كـ ⇇ *〘${generoFinal === 'hombre' ? 'ذكر' : 'أنثى'}〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};