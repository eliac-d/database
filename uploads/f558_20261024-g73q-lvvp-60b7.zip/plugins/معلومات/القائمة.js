import axios from "axios";
import { prepareWAMessageMedia, generateWAMessageFromContent } from "@whiskeysockets/baileys";
import { getPlugins } from "../../core/pluginLoader.js";
import { db } from "../../database/db.js";
import config from "../../config.js";

let bannerCache = null
let bannerCacheTime = 0
let mediaCache = null
let mediaCacheTime = 0
let lastUsedUrl = null

async function getBuffer(url) {
  try {
    const res = await axios({ method: "get", url, responseType: "arraybuffer" });
    return Buffer.from(res.data);
  } catch (e) {
    throw new Error(`خطأ في تحميل الصورة: ${e.message}`);
  }
}

async function getBannerBuffer(url) {
  if (bannerCache && lastUsedUrl === url && Date.now() - bannerCacheTime < 3600000) return bannerCache
  bannerCache = await getBuffer(url)
  bannerCacheTime = Date.now()
  lastUsedUrl = url
  return bannerCache
}

const catNombres = {
  "info": "معلومات",
  "misc": "متفرقات",
  "dl": "تحميل",
  "grupos": "القروبات",
  "owner": "المالك",
  "utils": "أدوات",
  "stickers": "ستيكرات",
  "sockets": "سوكيتات",
  "ia": "ذكاء اصطناعي",
  "economy": "اقتصاد",
}

const catDescripciones = {
  "info": "أوامر المعلومات·",
  "misc": "أوامر متفرقة·",
  "dl": "أوامر التحميل·",
  "grupos": "أوامر إدارة القروبات·",
  "owner": "أوامر المالك·",
  "utils": "أوامر مفيدة·",
  "stickers": "أوامر الستيكرات·",
  "sockets": "أوامر السب بوت·",
  "ia": "أوامر الذكاء الاصطناعي·",
  "economy": "أوامر الاقتصاد·",
}

export default {
  name: ["menu", "قائمة", "اوامر"],
  description: "يعرض قائمة أوامر البوت.",
  category: "info, معلومات",
  ownerOnly: false,

  async run({ sock, from, sender, senderNum, isGroup, groupName, usedPrefix, msg, text, args }) {
    try {
      const lugar = isGroup ? groupName : "محادثة خاصة";

      const currentBotNum = sock.user?.id ? sock.user.id.split('@')[0].split(':')[0].replace(/\D/g, '') : '';
      const currentBotJid = currentBotNum ? `${currentBotNum}@s.whatsapp.net` : '';

      let botData = db.getBot(currentBotJid) || db.getBot('main');

      const esLabelAutomatico = botData?.label?.startsWith('SUB_') || botData?.label === 'Subbot' || botData?.label === 'MAIN'
      const nombreBot = (esLabelAutomatico || !botData?.label ? config.botName : botData.label).replace(/@\d+/g, '').trim();
      const urlFoto = botData?.banner || "https://cdn.dix.lat/me/f5f104cd-9fb7-4d71-82bf-04bac49f8813.jpg";

      const esVerdaderoMain = botData?.isMain === true || botData?.isMain === 1;
      const tipoBot = esVerdaderoMain ? "بوت رئيسي" : "سب بوت";

      const esOwnerOCoOwner = config.ownerNumber?.includes(senderNum) || config.coOwners?.includes(senderNum);

      const plugins = getPlugins();
      const categories = {};

      const seen = new Set();
      for (const [, plugin] of plugins) {
        if (seen.has(plugin)) continue;
        seen.add(plugin);

        const cat = plugin.category || "misc";
        if (cat === "owner" && !esOwnerOCoOwner) continue;

        if (!categories[cat]) categories[cat] = new Set();
        const names = Array.isArray(plugin.name) ? plugin.name : [plugin.name];

        if (plugin.showAllNames) {
          for (const n of names) categories[cat].add(n);
        } else {
          const arabicName = names.find((n) => /[\u0600-\u06FF]/.test(n));
          categories[cat].add(arabicName || names[0]);
        }
      }

      let textoMenu = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🎭مـرحـبـاً بـك⏤͟ू⃪🎭』*\n` +
        `> •┊˹👤˼┊مرحباً *@${senderNum}* أنا *〘${nombreBot}〙*\n\n`;
      
      textoMenu += `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`;
      
      textoMenu += `*『͟͞ू⃪ 📊مـعـلـومـات الـبـوت⏤͟ू⃪📊』*\n`;
      textoMenu += `> •┊˹🤖˼┊النوع ⇇ *〘${tipoBot}〙*\n`;
      textoMenu += `> •┊˹📱˼┊النظام ⇇ *〘Android〙*\n`;
      textoMenu += `> •┊˹👤˼┊المستخدم ⇇ *〘@${senderNum}〙*\n`;
      textoMenu += `> •┊˹📢˼┊القناة ⇇ *〘${global.my?.canalNombre || "قناة البوت الرسمية"}〙*\n\n`;

      const filterCat = args?.[0]?.toLowerCase();
      const filteredCategories = filterCat 
        ? Object.entries(categories).filter(([cat]) => cat.toLowerCase().includes(filterCat))
        : Object.entries(categories);

      if (filteredCategories.length === 0) {
         textoMenu += `*『͟͞ू⃪ ⚠️لا تـوجـد أوامـر⏤͟ू⃪⚠️』*\n> •┊˹❌˼┊لم يتم العثور على أوامر في هذا القسم.\n\n`;
      } else {
        for (const [cat, cmds] of filteredCategories) {
          const categoriaLimped = cat.toLowerCase().trim();
          const nombreFormateado = catNombres[categoriaLimped] || categoriaLimped.toUpperCase();
          const descripcion = catDescripciones[categoriaLimped] || "ᶜᵒᵐᵃⁿᵈᵒˢ·";

          textoMenu += `*『͟͞ू⃪ 🗂️${nombreFormateado}⏤͟ू⃪🗂️』*\n`;
          textoMenu += `> ✐꒷ ${descripcion}\n`;

          for (const cmd of cmds) {
            textoMenu += `> ⏤͟͟͞͞⊱🌀 *${usedPrefix}${cmd}*\n`;
          }

          textoMenu += `\n`;
        }
      }

      textoMenu += `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`;
      textoMenu += `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n`;
      textoMenu += `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n`;
      textoMenu += `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n`;
      textoMenu += `🪼 _${global.devCredit || "تم التطوير بواسطة سونغ"}_\n`;
      textoMenu += `🪪 ${global.teamCredit || "فريق X6"}\n`;
      textoMenu += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      let imgBanner
      if (mediaCache && lastUsedUrl === urlFoto && Date.now() - mediaCacheTime < 3600000) {
        imgBanner = mediaCache
      } else {
        const bufferBanner = await getBannerBuffer(urlFoto)
        const mediaBanner = await prepareWAMessageMedia(
          { image: bufferBanner },
          { upload: sock.waUploadToServer, mediaTypeOverride: "thumbnail-link" }
        )
        imgBanner = mediaBanner.imageMessage
        mediaCache = imgBanner
        mediaCacheTime = Date.now()
      }

      const getTs = (ts) => typeof ts === "object" ? Number(ts.low || ts) : Number(ts);

      // حذفنا الرابط (linkMatch) لمنع ظهور المعاينة في الأسفل
      const content = {
        extendedTextMessage: {
          endCardTiles: [],
          text: textoMenu,
          previewType: 0,
          jpegThumbnail: imgBanner.jpegThumbnail,
          thumbnailDirectPath: imgBanner.directPath,
          thumbnailSha256: imgBanner.fileSha256,
          thumbnailEncSha256: imgBanner.fileEncSha256,
          mediaKey: imgBanner.mediaKey,
          mediaKeyTimestamp: getTs(imgBanner.mediaKeyTimestamp),
          thumbnailHeight: imgBanner.height || 1080,
          thumbnailWidth: imgBanner.width || 1920,
          contextInfo: {
            mentionedJid: [sender],
            isForwarded: true,
            forwardingScore: 1,
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363411937339682@newsletter",
              newsletterName: "⏤͟͟͞͞★꙲⃝͟𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 │ CHANNEL ◌Ⳋ𝅄",
              serverMessageId: -1
            }
          }
        }
      };

      const waMsg = generateWAMessageFromContent(from, content, { userJid: sock.user?.id, quoted: msg })
      await sock.relayMessage(from, waMsg.message, { messageId: waMsg.key.id })

      if (!filterCat) {
        try {
          const buttonsContent = {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  body: { text: "⚡ اختصارات سريعة للأقسام" },
                  footer: { text: nombreBot },
                  nativeFlowMessage: {
                    buttons: [
                      {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: "📥 التحميل", id: `${usedPrefix}menu dl` })
                      },
                      {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: "👥 القروبات", id: `${usedPrefix}menu grupos` })
                      },
                      {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: "🤖 ذكاء اصطناعي", id: `${usedPrefix}menu ia` })
                      },
                      {
                        name: "quick_reply",
                        buttonParamsJson: JSON.stringify({ display_text: "💰 اقتصاد", id: `${usedPrefix}menu economy` })
                      }
                    ]
                  }
                }
              }
            }
          }

          const btnMsg = generateWAMessageFromContent(from, buttonsContent, { userJid: sock.user?.id })
          await sock.relayMessage(from, btnMsg.message, { messageId: btnMsg.key.id })
        } catch (btnErr) {
          console.error("خطأ بإرسال الأزرار:", btnErr?.message || btnErr)
        }
      }

    } catch (error) {
      console.error("خطأ حرج في أمر القائمة:", error);
    }
  }
};