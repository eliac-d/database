import config from '../../config.js'

export default {
  name: ['owner', 'المطور'],
  description: 'يعرض معلومات مالك البوت',
  category: 'info, معلومات',
  ownerOnly: false,

  async run({ sock, from, msg, reply, react }) {
    const ownerNum = config.ownerNumber?.[0] || '963969829657'

    if (!ownerNum) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لم يتم تكوين رقم المطور في الإعدادات.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    try {
      await react("👑")

      // 1. إرسال بطاقة جهة الاتصال
      await sock.sendMessage(from, {
        contacts: {
          displayName: 'سونغ',
          contacts: [{
            vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:سونغ\nORG:المطور الأساسي\nTEL;type=CELL;type=VOICE;waid=${ownerNum}:+${ownerNum}\nEND:VCARD`
          }]
        }
      }, { quoted: msg })

      // 2. إرسال رسالة معلومات مزخرفة
      await sock.sendMessage(from, {
        text: 
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 👑مـعـلـومـات الـمـطـور⏤͟ू⃪👑』*\n` +
          `> •┊˹👤˼┊الاسم ⇇ *〘سونغ〙*\n` +
          `> •┊˹🏷️˼┊الدور ⇇ *〘المطور الأساسي〙*\n` +
          `> •┊˹📱˼┊الرقم ⇇ *〘+${ownerNum}〙*\n\n` +
          `*⌬──══─┈•⤣🌺⤣•┈─══──⌬*\n\n` +
          `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
          `*┇لأي استفسار أو دعم، تواصل مباشرة ⇠『 .ابلاغ 』*\n` +
          `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [`${ownerNum}@s.whatsapp.net`]
      }, { quoted: msg })

      await react("✅")
    } catch (e) {
      console.error("خطأ في أمر المطور:", e)
      await react("❌")
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}