import { db } from "../../database/db.js";

export default {
  name: ["طلاق", "divorcio"],
  description: "ينهي زواجك الحالي",
  category: "info, معلومات",

  async run(ctx) {
    const { sender, reply } = ctx;

    const partner = db.getMarriage(sender);
    if (!partner) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹💔˼┊أنت غير متزوج من أي شخص.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    db.divorce(sender);

    return reply({
      text: 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 💔تـم الـطـلاق⏤͟ू⃪💔』*\n` +
        `> •┊˹👤˼┊@${sender.split("@")[0]} طلّق @${partner.split("@")[0]}.\n\n` +
        `> •┊˹🕊️˼┊_الطرفان أصبحا حرين للزواج من جديد._\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
      mentions: [sender, partner],
    });
  },
};