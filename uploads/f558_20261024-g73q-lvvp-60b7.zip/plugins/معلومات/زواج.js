import { db } from "../../database/db.js";

const pendingProposals = new Map(); // proposerJid -> { targetJid, at }
const PROPOSAL_TTL_MS = 5 * 60 * 1000;

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

function cleanExpired() {
  const now = Date.now();
  for (const [proposer, data] of pendingProposals) {
    if (now - data.at > PROPOSAL_TTL_MS) pendingProposals.delete(proposer);
  }
}

function labelPorGenero(jid) {
  const genero = (db.getGenero(jid) || "").toLowerCase();
  if (genero === "hombre") return "الزوج";
  if (genero === "mujer") return "الزوجة";
  return "الشريك";
}

export default {
  name: ["زواج", "casar"],
  description: "اقترح أو اقبل الزواج من شخص",
  category: "info, معلومات",

  async run(ctx) {
    const { sock, msg, from, sender, reply, resolveLid, groupMeta } = ctx;
    cleanExpired();

    const contextInfo = msg?.message?.extendedTextMessage?.contextInfo;

    let targetJid = null;
    if (contextInfo?.mentionedJid?.length > 0) {
      targetJid = contextInfo.mentionedJid[0];
    } else if (contextInfo?.participant) {
      targetJid = contextInfo.participant;
    }

    if (!targetJid) {
      return reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لازم تمنشن شخصاً أو ترد على رسالته حتى تقبل أو تقترح الزواج.\n\n` +
          `> •┊˹💡˼┊مثال ⇇ *〘.زواج @user〙* أو رد على رسالته بـ *〘.زواج〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    if (targetJid.endsWith("@lid") || isNaN(targetJid.split("@")[0])) {
      const found = groupMeta?.participants?.find((p) => p.id === targetJid || p.lid === targetJid);
      if (found?.id) targetJid = found.id;
    }

    if (targetJid.endsWith("@lid")) {
      targetJid = await resolveLid(targetJid);
    }

    const target = cleanJid(targetJid);

    if (target === sender) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـسـتـحـيـل⏤͟ू⃪❌』*\n` +
          `> •┊˹💀˼┊لا يمكنك الزواج من نفسك.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const senderPartner = db.getMarriage(sender);
    if (senderPartner) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـتـزوج مـسـبـقـاً⏤͟ू⃪❌』*\n` +
          `> •┊˹💍˼┊أنت متزوج من @${senderPartner.split("@")[0]} بالفعل.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [senderPartner] 
      });
    }

    const targetPartner = db.getMarriage(target);
    if (targetPartner) {
      return reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـرتـبـط مـسـبـقـاً⏤͟ू⃪❌』*\n` +
          `> •┊˹💍˼┊هذا الشخص متزوج من @${targetPartner.split("@")[0]} بالفعل.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [targetPartner] 
      });
    }

    const reverseProposal = pendingProposals.get(target);
    if (reverseProposal && reverseProposal.targetJid === sender) {
      pendingProposals.delete(target);
      db.marry(sender, target);

      const labelTarget = labelPorGenero(target);
      const labelSender = labelPorGenero(sender);

      const texto = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 💍تـم الـزواج⏤͟ू⃪💍』*\n` +
        `> •┊˹🌸˼┊مبارك للجميع!\n\n` +
        `> •┊˹${labelTarget === 'الزوج' ? '🤵' : '👰'}˼┊${labelTarget} ⇇ *〘@${target.split("@")[0]}〙*\n` +
        `> •┊˹${labelSender === 'الزوج' ? '🤵' : '👰'}˼┊${labelSender} ⇇ *〘@${sender.split("@")[0]}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `> 🍯 _استمتعوا بشهر العسل!_ 🍯\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      return reply({ text: texto, mentions: [sender, target] });
    }

    pendingProposals.set(sender, { targetJid: target, at: Date.now() });

    return reply({
      text: 
        `*『͟͞ू⃪ 💌طـلب زواج⏤͟ू⃪💌』*\n` +
        `> •┊˹👤˼┊من ⇇ @${sender.split("@")[0]}\n` +
        `> •┊˹💍˼┊إلى ⇇ @${target.split("@")[0]}\n\n` +
        `> •┊˹💡˼┊@${target.split("@")[0]}، استخدم *〘.زواج @${sender.split("@")[0]}〙* (أو رد على هذه الرسالة بـ *〘.زواج〙*) للموافقة.\n` +
        `> •┊˹⏳˼┊الصلاحية: *〘5 دقائق〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
      mentions: [sender, target],
    });
  },
};