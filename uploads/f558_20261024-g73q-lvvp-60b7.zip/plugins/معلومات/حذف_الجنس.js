import { db } from "../../database/db.js";

export default {
  name: ["حذف_الجنس", "delgenre"],
  description: "يحذف إعداد الجنس من بروفايلك",
  category: "info, معلومات",
  ownerOnly: false,

  async run({ sender, reply }) {
    const generoActual = db.getGenero(sender);

    if (!generoActual) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ليس لديك إعداد جنس محدد مسبقاً.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    db.setGenero(sender, null);

    return await reply({ 
      text: 
        `*『͟͞ू⃪ ✅تـم الـحـذف⏤͟ू⃪✅』*\n` +
        `> •┊˹🗑️˼┊تم حذف إعداد الجنس من بروفايلك بنجاح.\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};