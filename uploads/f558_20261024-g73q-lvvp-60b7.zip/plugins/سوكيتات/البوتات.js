import config from "../../config.js";
import { activeBots } from "../../core/subbotManager.js";
import { jidNormalizedUser, isLidUser } from "@whiskeysockets/baileys";

export default {
  name: ["bots", "listbots", "البوتات"],
  description: "يعرض البوتات المتصلة بهذا القروب",
  category: "sockets, أدوات",
  groupOnly: true,

  async run({ sock, from, msg, react, reply, groupMeta }) {
    try {
      await react("🤖");

      const limpiarNumero = (jid = "") =>
        jid.split("@")[0].split(":")[0].replace(/\D/g, "");

      const metadata = groupMeta || (await sock.groupMetadata(from));

      const findTarget = (numero, lid) => {
        return metadata.participants.find((p) => {
          const clean = jidNormalizedUser(p.id);
          if (!isLidUser(clean)) return clean === `${numero}@s.whatsapp.net`;
          return lid && limpiarNumero(clean) === lid;
        });
      };

      const mainLive = activeBots.get("main");
      const principalLive = mainLive?.status === "online" ? mainLive : null;

      const subbotsConectados = [...activeBots.values()]
        .filter((b) => !b.isMain && b.status === "online" && b.jid);

      const subbotsEnGrupo = subbotsConectados
        .map((bot) => {
          const numero = limpiarNumero(bot.jid);
          const target = findTarget(numero, bot.lid);
          return target ? { ...bot, numero, targetJid: jidNormalizedUser(target.id) } : null;
        })
        .filter(Boolean);

      const principalTarget = principalLive
        ? findTarget(limpiarNumero(principalLive.jid), principalLive.lid)
        : null;

      const participantsMentions = [];

      let report = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🤖قـائـمـة الـبـوتـات الـنـشـطـة⏤͟ू⃪🤖』*\n\n` +
        `> •┊˹👑˼┊الرئيسي ⇇ *〘${config.botName}〙*\n` +
        `> •┊˹🌀˼┊سب-بوتات متصلة ⇇ *〘${subbotsConectados.length}〙*\n` +
        `> •┊˹🌱˼┊في هذا القروب ⇇ *〘${subbotsEnGrupo.length}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`;

      if (principalTarget) {
        const jidPrincipal = jidNormalizedUser(principalTarget.id);
        const digitosVisibles = jidPrincipal.split("@")[0];
        participantsMentions.push(jidPrincipal);
        report += `> •┊˹𖠌˼┊البوت ⇇ *〘@${digitosVisibles}〙*\n`;
        report += `> •┊˹⚝˼┊النوع ⇇ *〘رئيسي 👑〙*\n\n`;
      }

      if (subbotsEnGrupo.length > 0) {
        for (const bot of subbotsEnGrupo) {
          const digitosVisibles = bot.targetJid.split("@")[0];
          participantsMentions.push(bot.targetJid);
          report += `> •┊˹𖠌˼┊البوت ⇇ *〘@${digitosVisibles}〙*\n`;
          report += `> •┊˹⚝˼┊النوع ⇇ *〘سب-بوت 🌀〙*\n\n`;
        }
      } else if (!principalTarget) {
        report += `*『͟͞ू⃪ ⚠️لا يـوجـد بـوت⏤͟ू⃪⚠️』*\n> •┊˹❌˼┊ما فيه أي بوت من هذا النظام بهذا القروب.\n\n`;
      }

      report += 
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      await sock.sendMessage(
        from,
        { text: report, mentions: participantsMentions.filter(Boolean) },
        { quoted: msg }
      );

      await react("✅");
    } catch (e) {
      console.error(e);
      await react("❌");
      if (reply) {
        await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊صار خطأ أثناء جلب البوتات.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }
    }
  }
};