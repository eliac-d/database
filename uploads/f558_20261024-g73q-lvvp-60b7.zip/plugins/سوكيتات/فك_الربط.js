import { removeSubbot, activeBots } from '../../core/subbotManager.js'

export default {
  name: ['delbot', 'فك_الربط'],
  description: 'يفك ربط رقمك كسب-بوت',
  category: 'sockets, أدوات',
  ownerOnly: false,

  async run({ senderNum, react, reply }) {
    await react('🗑️')

    const id = `sub_${senderNum}`

    if (!activeBots.has(id)) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️غـيـر مـربـوط⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما عندك أي سب-بوت مربوط.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    removeSubbot(id)
    
    await reply({ 
      text: 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ ✅تـم فـك الـربـط⏤͟ू⃪✅』*\n` +
        `> •┊˹🗑️˼┊تم فك ربط السب-بوت وحذف الجلسة بنجاح.\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })
  }
}