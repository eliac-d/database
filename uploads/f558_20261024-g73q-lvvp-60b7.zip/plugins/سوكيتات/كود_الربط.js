import { requestSubbotCode, activeBots } from "../../core/subbotManager.js";
import { jidNormalizedUser } from "@whiskeysockets/baileys";

const cooldowns = new Map();

export default {
  name: ["تنصيب", "code"],
  description: "يربط رقمك كسب-بوت",
  category: "sockets, أدوات",
  ownerOnly: false,

  async run({ sock, from, sender, react, reply, msg, resolveLid, args }) {
    await react("🔑");

    let resolved = jidNormalizedUser(sender);

    if (resolved.endsWith("@lid")) {
      resolved = await resolveLid(resolved);
    }

    let phone = resolved.endsWith("@lid") ? "" : resolved.split("@")[0].replace(/\D/g, "");

    if (!phone && args?.[0]) {
      const manual = args[0].replace(/\D/g, "");
      if (manual.length >= 8) phone = manual;
    }

    if (!phone || phone.length < 8) {
      return await reply({
        text:
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أكتشف رقمك تلقائياً (يحدث هذا لو كان لديك اسم مستخدم بواتساب).\n\n` +
          `> •┊˹💡˼┊اكتب رقمك مع كود الدولة هكذا:\n` +
          `> ┊˹📱˼┊*.تنصيب 967735541558*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const id = `sub_${phone}`;

    if (activeBots.has(id) && activeBots.get(id).status === "online") {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️مـربـوط مـسـبـقـاً⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊رقمك مربوط كسب-بوت بالفعل.\n` +
          `> •┊˹💡˼┊استخدم *〘.delbot〙* لفك الربط.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    if (cooldowns.has(phone)) {
      const diff = Date.now() - cooldowns.get(phone);
      const restante = Math.ceil((60000 - diff) / 1000);
      if (diff < 60000) {
        return await reply({
          text: 
            `*『͟͞ू⃪ ⏳انـتـظـر قـلـيـلاً⏤͟ू⃪⏳』*\n` +
            `> •┊˹❌˼┊لقد طلبت كوداً مؤخراً.\n` +
            `> •┊˹⏱˼┊انتظر *〘${restante} ثانية〙* قبل طلب واحد آخر.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }
    }

    cooldowns.set(phone, Date.now());

    await reply({
      text:
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ ⚔️ربـط سـب-بـوت⏤͟ू⃪⚔️』*\n` +
        `> •┊˹📋˼┊التعليمات:\n` +
        `> ┊˹1️⃣˼┊افتح واتساب بجوالك.\n` +
        `> ┊˹2️⃣˼┊اذهب إلى *الأجهزة المرتبطة*.\n` +
        `> ┊˹3️⃣˼┊اضغط *ربط جهاز*.\n` +
        `> ┊˹4️⃣˼┊اضغط *ربط برقم الهاتف*.\n` +
        `> ┊˹5️⃣˼┊أدخل الكود الذي سيصلك الآن.\n` +
        `> ┊˹⏳˼┊لديك *〘60 ثانية〙* قبل انتهاء الوقت.\n\n` +
        `> •┊˹🔄˼┊_جاري توليد الكود..._\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });

    try {
      const code = await requestSubbotCode(id, phone, sock, from);
      
      const codeCaption = 
        `*『͟͞ू⃪ 🔑كـود الـربـط⏤͟ू⃪🔑』*\n` +
        `> •┊˹📱˼┊الرقم ⇇ *〘+${phone}〙*\n` +
        `> •┊˹🔑˼┊الكود ⇇ *〘${code}〙*\n\n` +
        `> •┊˹⏳˼┊_أدخله في تطبيق واتساب الآن!_\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sock.sendMessage(from, { text: codeCaption }, { quoted: msg });
      await react("✅");
    } catch (e) {
      cooldowns.delete(phone);
      await react("❌");
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};