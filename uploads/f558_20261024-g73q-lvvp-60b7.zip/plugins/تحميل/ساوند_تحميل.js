import axios from 'axios'
import { spawn } from 'child_process'

const DEBUG = true // true: يرسل التقرير للتشخيص في الشات، اجعله false عند الاستقرار

const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36'
const http = axios.create({ headers: { 'User-Agent': UA } })

let cachedClientId = null
let cacheTime = 0

const host = (u) => {
  try { return new URL(u).host } catch { return '?' }
}

const snippet = (data) => {
  if (data == null) return ''
  let s = Buffer.isBuffer(data) ? data.toString('utf8') : typeof data === 'string' ? data : JSON.stringify(data)
  return s.replace(/\s+/g, ' ').slice(0, 150)
}

async function paso(nombre, fn, log) {
  const t0 = Date.now()
  try {
    const r = await fn()
    log(`✔ ${nombre} (${Date.now() - t0}ms)`)
    return r
  } catch (e) {
    const code = e.response?.status
    const body = snippet(e.response?.data)
    log(`✖ ${nombre}${code ? ` HTTP ${code}` : ''}: ${e.message}${body ? ` | ${body}` : ''}`)
    throw new Error(`${nombre}${code ? ` (HTTP ${code})` : ''}: ${e.message}`)
  }
}

async function getClientId(log) {
  if (cachedClientId && Date.now() - cacheTime < 3600000) {
    log(`ℹ client_id محفوظ مسبقاً: ${cachedClientId.slice(0, 4)}…`)
    return cachedClientId
  }

  const html = await http.get('https://soundcloud.com', { timeout: 10000 }).then(r => r.data)
  const scripts = [...html.matchAll(/src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+\.js)"/g)].map(m => m[1])
  log(`ℹ عدد السكربتات في soundcloud.com: ${scripts.length}`)

  for (const script of scripts.slice(-3)) {
    try {
      const js = await http.get(script).then(r => r.data)
      const match = js.match(/client_id:"([a-zA-Z0-9]+)"/)
      if (match) {
        cachedClientId = match[1]
        cacheTime = Date.now()
        log(`ℹ client_id جديد: ${cachedClientId.slice(0, 4)}…`)
        return cachedClientId
      }
    } catch {}
  }
  throw new Error('تعذر جلب client_id من SoundCloud')
}

function msToTime(ms) {
  const m = Math.floor(ms / 60000)
  const s = Math.floor((ms % 60000) / 1000).toString().padStart(2, '0')
  return `${m}:${s}`
}

const getBuf = (url) =>
  http.get(url, { responseType: 'arraybuffer', timeout: 30000 }).then(r => Buffer.from(r.data))

async function descargarHls(m3u8Url, log) {
  const playlist = await paso('بلاي ليست HLS', () => http.get(m3u8Url, { timeout: 15000 }).then(r => r.data), log)
  const base = new URL(m3u8Url)
  const lines = String(playlist).split('\n').map(l => l.trim()).filter(Boolean)

  const segmentos = lines.filter(l => !l.startsWith('#')).map(l => new URL(l, base).href)
  log(`ℹ بلاي ليست: ${segmentos.length} سيجمنت، المستضيف ${host(segmentos[0] || m3u8Url)}`)
  if (!segmentos.length) throw new Error('بلاي ليست HLS لا تحتوي سيجمنتات')

  const initUri = lines.find(l => l.startsWith('#EXT-X-MAP'))?.match(/URI="([^"]+)"/)?.[1]

  const partes = []
  if (initUri) partes.push(await paso('سيجمنت البداية', () => getBuf(new URL(initUri, base).href), log))

  for (let i = 0; i < segmentos.length; i += 6) {
    const lote = await paso(`سيجمنتات ${i + 1}-${Math.min(i + 6, segmentos.length)}`, () =>
      Promise.all(segmentos.slice(i, i + 6).map(getBuf)), log
    )
    partes.push(...lote)
  }

  return Buffer.concat(partes)
}

function aMp3(buffer) {
  return new Promise((resolve, reject) => {
    const ff = spawn('ffmpeg', ['-i', 'pipe:0', '-vn', '-c:a', 'libmp3lame', '-b:a', '128k', '-f', 'mp3', 'pipe:1'])
    const out = []
    ff.stdout.on('data', d => out.push(d))
    ff.on('error', reject)
    ff.on('close', code => (code === 0 && out.length ? resolve(Buffer.concat(out)) : reject(new Error('ffmpeg فشل'))))
    ff.stdin.on('error', () => {})
    ff.stdin.end(buffer)
  })
}

function mimeEnvio(mime = '') {
  if (mime.startsWith('audio/mpeg')) return 'audio/mpeg'
  if (mime.startsWith('audio/ogg')) return 'audio/ogg; codecs=opus'
  return 'audio/mp4'
}

async function bajarTranscoding(t, track, clientId, log) {
  const streamRes = await paso('رابط الستريم', () =>
    http.get(t.url, {
      params: { client_id: clientId, track_authorization: track.track_authorization },
      timeout: 10000
    }), log
  )

  const streamUrl = streamRes.data?.url
  if (!streamUrl) throw new Error('SoundCloud لم يرجع رابط الستريم')
  log(`ℹ مستضيف الستريم: ${host(streamUrl)}`)

  const buffer = t.format.protocol === 'hls'
    ? await descargarHls(streamUrl, log)
    : await paso('تحميل الصوت', () => getBuf(streamUrl), log)

  log(`ℹ تم التحميل: ${(buffer.length / 1024 / 1024).toFixed(2)} MB`)
  return { buffer, mime: t.format.mime_type }
}

export default {
  name: ['scdl', 'sc', 'ساوند_تحميل'],
  description: 'يحمّل أغنية من SoundCloud عبر الرابط',
  category: 'dl, تحميل',
  ownerOnly: false,

  async run({ sock, from, msg, text, usedPrefix, react, reply }) {
    const dbg = []
    const log = (m) => dbg.push(m)
    const enviarDebug = async () => {
      if (!DEBUG || !dbg.length) return
      await reply({ text: `🐞 *تقرير التشخيص*\n${dbg.join('\n')}`.slice(0, 3500) })
    }

    try {
      await react('⏳')

      if (!text) return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ضع رابط SoundCloud.\n` +
          `> •┊˹💡˼┊مثال ⇇ *〘${usedPrefix}scdl https://soundcloud.com/artist/song〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      if (!text.includes('soundcloud.com')) return await reply({
        text: 
          `*『͟͞ू⃪ ❌رابـط غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊الرابط يجب أن يكون من SoundCloud.\n` +
          `> •┊˹💡˼┊استخدم ⇇ *〘${usedPrefix}scsearch اسم〙* للبحث أولاً.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      const clientId = await paso('client_id', () => getClientId(log), log)

      const urlLimpia = text.trim().split('?')[0]
      log(`ℹ url: ${urlLimpia}`)

      const trackRes = await paso('جلب بيانات المقطع', () =>
        http.get('https://api-v2.soundcloud.com/resolve', {
          params: { url: urlLimpia, client_id: clientId },
          timeout: 10000
        }), log
      )

      const track = trackRes.data
      if (!track || track.kind !== 'track') throw new Error('لم أجد المقطع بهذا الرابط')
      log(`ℹ المقطع: ${track.title} | policy: ${track.policy || '?'} | access: ${track.access || '?'}`)
      log(`ℹ track_authorization: ${track.track_authorization ? 'موجود' : 'غير موجود'}`)

      const transcodings = track.media?.transcodings || []
      log(`ℹ transcodings: ${transcodings.map(t => `${t.format?.protocol}/${t.format?.mime_type}`).join(', ') || 'لا يوجد'}`)

      const esMp3 = t => t.format?.mime_type?.startsWith('audio/mpeg')
      const candidatos = [
        ...transcodings.filter(t => esMp3(t) && t.format?.protocol === 'progressive'),
        ...transcodings.filter(t => esMp3(t) && t.format?.protocol === 'hls'),
        ...transcodings.filter(t => !esMp3(t) && t.format?.protocol === 'hls')
      ]

      if (!candidatos.length) throw new Error('لا يوجد ستريم متاح')

      let audio = null
      let ultimoError = null
      for (const t of candidatos) {
        log(`▶ جاري تجربة ${t.format?.protocol} ${t.format?.mime_type}`)
        try {
          audio = await bajarTranscoding(t, track, clientId, log)
          break
        } catch (e) {
          ultimoError = e
          console.error(`scdl: فشل ${t.format?.protocol} ${t.format?.mime_type} ->`, e.message)
        }
      }
      if (!audio) throw ultimoError || new Error('لم أتمكن من تحميل أي ستريم')

      let audioBuffer = audio.buffer
      let mimetype = mimeEnvio(audio.mime)

      if (mimetype !== 'audio/mpeg') {
        try {
          audioBuffer = await aMp3(audioBuffer)
          mimetype = 'audio/mpeg'
          log('✔ تم التحويل إلى mp3 بواسطة ffmpeg')
        } catch (e) {
          log(`✖ ffmpeg: ${e.message} (إرسال بدون تحويل كـ ${mimetype})`)
        }
      }

      const thumb = track.artwork_url?.replace('large', 't500x500') || null

      const caption =
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🎵تـحـمـيـل سـاونـد كـلاود⏤͟ू⃪🎵』*\n` +
        `> •┊˹🎵˼┊العنوان ⇇ *〘${track.title}〙*\n` +
        `> •┊˹👤˼┊الفنان ⇇ *〘${track.user.username}〙*\n` +
        `> •┊˹⏱˼┊المدة ⇇ *〘${msToTime(track.duration)}〙*\n` +
        `> •┊˹▶️˼┊التشغيل ⇇ *〘${track.playback_count?.toLocaleString() || 'N/A'}〙*\n` +
        `> •┊˹❤️˼┊لايكات ⇇ *〘${track.likes_count?.toLocaleString() || 'N/A'}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      if (thumb) {
        await sock.sendMessage(from, {
          image: { url: thumb },
          caption
        }, { quoted: msg })
      }

      await sock.sendMessage(from, {
        audio: audioBuffer,
        mimetype,
        ptt: false
      }, { quoted: msg })

      log(`✔ تم الإرسال (${mimetype})`)
      await react('✅')
      await enviarDebug()

    } catch (error) {
      await react('❌')
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${error.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
      await enviarDebug()
      console.error('خطأ بـ scdl:', error)
    }
  }
}