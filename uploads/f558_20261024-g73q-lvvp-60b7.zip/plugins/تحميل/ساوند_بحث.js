import axios from 'axios'

let cachedClientId = null
let cacheTime = 0

async function getClientId() {
  if (cachedClientId && Date.now() - cacheTime < 3600000) return cachedClientId

  const html = await axios.get('https://soundcloud.com', {
    headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' },
    timeout: 10000
  }).then(r => r.data)

  const scripts = [...html.matchAll(/src="(https:\/\/a-v2\.sndcdn\.com\/assets\/[^"]+\.js)"/g)].map(m => m[1])

  for (const script of scripts.slice(-3)) {
    try {
      const js = await axios.get(script).then(r => r.data)
      const match = js.match(/client_id:"([a-zA-Z0-9]+)"/)
      if (match) {
        cachedClientId = match[1]
        cacheTime = Date.now()
        return cachedClientId
      }
    } catch {}
  }
  throw new Error('تعذر جلب client_id من SoundCloud')
}

function msToTime(ms) {
  const m = Math.floor(ms / 60000)
  const s = Math.floor((ms % 60000) / 1000).toString().padStart(2, '0')
  return `${m}:${s}`
}

export default {
  name: ['scsearch', 'بحث_ساوند'],
  description: 'يبحث عن أغاني بـ SoundCloud ويرجع الروابط',
  category: 'dl, تحميل',
  ownerOnly: false,

  async run({ text, usedPrefix, react, reply }) {
    try {
      await react('🔍')

      if (!text) return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊اكتب اسم الأغنية.\n` +
          `> •┊˹💡˼┊مثال ⇇ *〘${usedPrefix}scsearch bad bunny〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      const clientId = await getClientId()
      const r = await axios.get('https://api-v2.soundcloud.com/search/tracks', {
        params: { q: text, client_id: clientId, limit: 5 },
        timeout: 10000
      })

      const results = r.data.collection
      if (!results?.length) throw new Error('ما لقيت نتائج')

      let txt = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🎵نـتـائـج سـاونـد كـلاود⏤͟ू⃪🎵』*\n` +
        `> •┊˹🔎˼┊البحث ⇇ *〘${text}〙*\n\n`

      results.forEach((t, i) => {
        txt += `> •┊˹🎵˼┊ *${i + 1}. ${t.title}*\n`
        txt += `> ┊˹👤˼┊ الفنان: ${t.user.username}\n`
        txt += `> ┊˹⏱˼┊ المدة: ${msToTime(t.duration)}\n`
        txt += `> ┊˹🔗˼┊ ${t.permalink_url}\n\n`
      })

      txt += `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`
      txt += `> •┊˹💡˼┊للتحميل استخدم ⇇ *〘${usedPrefix}scdl <رابط>〙*\n\n`
      txt += `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n`
      txt += `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n`
      txt += `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n`
      txt += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await reply({ text: txt })
      await react('✅')

    } catch (error) {
      await react('❌')
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${error.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}