import { createDecipheriv } from "node:crypto";
import { Readable } from "node:stream";

const API = "https://g.api.mega.co.nz/cs";
const MAX_MB = 100;
const TIMEOUT = 20000;

const MIMES = {
  mp4: "video/mp4", mkv: "video/x-matroska", webm: "video/webm", mov: "video/quicktime",
  mp3: "audio/mpeg", m4a: "audio/mp4", ogg: "audio/ogg", wav: "audio/wav", flac: "audio/flac",
  jpg: "image/jpeg", jpeg: "image/jpeg", png: "image/png", webp: "image/webp", gif: "image/gif",
  html: "text/html", htm: "text/html", txt: "text/plain", pdf: "application/pdf",
  zip: "application/zip", rar: "application/vnd.rar", "7z": "application/x-7z-compressed",
  apk: "application/vnd.android.package-archive",
};

const ERRORES = {
  [-3]: "ميجا مشغول، جرب بعد لحظة.",
  [-4]: "ميجا قيّد طلباتك. انتظر قليلاً.",
  [-6]: "ميجا حظر IP السيرفر مؤقتاً. انتظر قليلاً أو جرب IP آخر.",
  [-19]: "اتصالات كثيرة بنفس الوقت بميجا. انتظر لحظة.",
  [-9]: "الملف غير موجود أو محذوف.",
  [-16]: "ميجا حظر الملف (مخالفة شروط الخدمة).",
  [-17]: "ميجا قيّد سرعة هذا السيرفر. جرب لاحقاً.",
  [-18]: "الملف غير متاح مؤقتاً. جرب لاحقاً.",
};

const extDe = (n) => (n.split(".").pop() || "").toLowerCase();

function parsear(text) {
  const nuevo = text.match(/mega\.(?:nz|io|co\.nz)\/file\/([\w-]+)#([\w-]+)/i);
  if (nuevo) return { id: nuevo[1], key: nuevo[2] };
  const viejo = text.match(/mega\.(?:nz|io|co\.nz)\/#!([\w-]+)!([\w-]+)/i);
  if (viejo) return { id: viejo[1], key: viejo[2] };
  return null;
}

function derivarClaves(keyB64) {
  const raw = Buffer.from(keyB64, "base64url");
  if (raw.length !== 32) throw new Error("مفتاح الرابط غير صحيح (ربما الرابط ناقص أو رابط مجلد؟).");
  const aes = Buffer.alloc(16);
  for (let i = 0; i < 16; i++) aes[i] = raw[i] ^ raw[i + 16];
  const iv = Buffer.concat([raw.subarray(16, 24), Buffer.alloc(8)]);
  return { aes, iv };
}

const TEMPORALES = new Set([-3, -4, -6, -19]);
const espera = (ms) => new Promise((r) => setTimeout(r, ms));

async function infoArchivo(id, intento = 1) {
  const res = await fetch(`${API}?id=${Date.now() % 1e9}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify([{ a: "g", g: 1, ssl: 1, p: id }]),
    signal: AbortSignal.timeout(TIMEOUT),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} بـ API ميجا`);

  const json = await res.json();
  const data = Array.isArray(json) ? json[0] : json;

  if (typeof data === "number") {
    if (TEMPORALES.has(data) && intento <= 3) {
      await espera(2000 * 2 ** (intento - 1));
      return infoArchivo(id, intento + 1);
    }
    throw new Error(ERRORES[data] || `ميجا رجع خطأ ${data}.`);
  }
  if (!data?.g) throw new Error("ميجا لم يرجع رابط تحميل.");
  return data;
}

function leerNombre(at, aesKey) {
  try {
    const d = createDecipheriv("aes-128-cbc", aesKey, Buffer.alloc(16));
    d.setAutoPadding(false);
    const txt = Buffer.concat([d.update(Buffer.from(at, "base64url")), d.final()])
      .toString("utf8")
      .replace(/\0+$/, "");
    if (!txt.startsWith("MEGA")) return null;
    return JSON.parse(txt.slice(4)).n || null;
  } catch {
    return null;
  }
}

export default {
  name: ["mega", "megadl", "ميجا"],
  description: "يحمّل ملفات من MEGA عبر الرابط (صوت، فيديو، zip، إلخ)",
  category: "dl, تحميل",
  groupOnly: false,

  async run({ sock, from, msg, text, usedPrefix, reply, react }) {
    try {
      if (!text) {
        return await reply({
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊ابعث رابط MEGA.\n` +
            `> •┊˹💡˼┊الاستخدام ⇇ *〘${usedPrefix || "."}mega <رابط>〙*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      if (/mega\.(nz|io|co\.nz)\/(#F!|folder\/)/i.test(text)) {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ❌مـلـفـات غـيـر مـدعـومـة⏤͟ू⃪❌』*\n` +
            `> •┊˹❌˼┊المجلدات غير مدعومة، ابعث رابط ملف.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      const enlace = parsear(text);
      if (!enlace) {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ❌رابـط غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
            `> •┊˹❌˼┊هذا لا يبدو رابط MEGA صحيح (لازم يحتوي المفتاح بعد #).\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      await react("⏳");

      const { aes, iv } = derivarClaves(enlace.key);
      const info = await infoArchivo(enlace.id);

      const nombre = (leerNombre(info.at, aes) || "archivo").replace(/[\\/:*?"<>|]+/g, "_");
      const bytes = Number(info.s) || 0;
      const mb = bytes / 1048576;

      if (mb > MAX_MB) {
        await react("✅");
        return await reply({
          text: 
            `*『͟͞ू⃪ ⚠️الـمـلـف كـبـيـر⏤͟ू⃪⚠️』*\n` +
            `> •┊˹📦˼┊الاسم ⇇ *〘${nombre}〙*\n` +
            `> •┊˹📦˼┊الحجم ⇇ *〘${mb.toFixed(1)} MB〙*\n` +
            `> •┊˹⚠️˼┊الحد الأقصى للإرسال ⇇ *〘${MAX_MB} MB〙*\n\n` +
            `> •┊˹🔗˼┊حمّله من الرابط الأصلي:\n${text.match(/https?:\/\/\S+/)?.[0] || ""}\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), TIMEOUT);
      let res;
      try {
        res = await fetch(info.g, { signal: ctrl.signal });
      } finally {
        clearTimeout(t);
      }
      if (res.status === 509) throw new Error(ERRORES[-17]);
      if (!res.ok) throw new Error(`HTTP ${res.status} بالتحميل`);

      const decipher = createDecipheriv("aes-128-ctr", aes, iv);
      const origen = Readable.fromWeb(res.body);
      origen.on("error", (e) => decipher.destroy(e));
      decipher.on("error", (e) => console.error("[mega:stream]", e.message));
      const stream = origen.pipe(decipher);

      const mimetype = MIMES[extDe(nombre)] || "application/octet-stream";
      
      const caption = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 📦تـم الـتـحـمـيـل⏤͟ू⃪📦』*\n` +
        `> •┊˹📄˼┊الاسم ⇇ *〘${nombre}〙*\n` +
        `> •┊˹📦˼┊الحجم ⇇ *〘${mb.toFixed(1)} MB〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      if (/^video\//.test(mimetype) && mb <= 64) {
        await sock.sendMessage(from, { video: { stream }, caption, mimetype }, { quoted: msg });
      } else if (/^audio\//.test(mimetype)) {
        await sock.sendMessage(from, { audio: { stream }, mimetype, fileName: nombre }, { quoted: msg });
      } else if (/^image\//.test(mimetype) && mb <= 16) {
        await sock.sendMessage(from, { image: { stream }, caption }, { quoted: msg });
      } else {
        await sock.sendMessage(
          from,
          { document: { stream }, mimetype, fileName: nombre, caption },
          { quoted: msg }
        );
      }

      await react("✅");
    } catch (e) {
      console.error("[mega]", e);
      await react("❌");
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  },
};