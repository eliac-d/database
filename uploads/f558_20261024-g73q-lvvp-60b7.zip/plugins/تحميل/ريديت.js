import { gotScraping } from 'got-scraping'
import { CookieJar } from 'tough-cookie'
import { Buffer } from 'node:buffer'

const BASE = 'https://redvid.io'
const REDDIT_REGEX = /reddit\.com\/|redd\.it\//i
const DOWNLOAD_MAX_RETRIES = 8
const RETRY_DELAY = 2000

const cookieJar = new CookieJar()

const http = gotScraping.extend({
  cookieJar,
  timeout: { request: 30000 },
  retry: { limit: 1 },
  throwHttpErrors: false,
  headerGeneratorOptions: {
    browsers: [{ name: 'chrome', minVersion: 120 }],
    devices: ['desktop'],
    operatingSystems: ['windows'],
    locales: ['ar', 'en-US']
  }
})

export default {
  name: ['reddit', 'redditdl', 'rddl', 'ريديت'],
  description: 'يحمّل فيديو، صوت أو صور من رابط Reddit',
  category: 'dl, تحميل',
  ownerOnly: false,

  async run({ sock, from, msg, args, react, reply }) {
    try {
      const url = args.find((a) => REDDIT_REGEX.test(a))
      const wantAudio = args.some((a) => {
        const low = a.toLowerCase()
        return low === 'mp3' || low === 'audio' || low === 'صوت'
      })

      if (!url) {
        return reply({
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊لازم تعطيني رابط Reddit صحيح.\n\n` +
            `> •┊˹🎬˼┊فيديو ⇇ *〘.reddit https://www.reddit.com/r/...〙*\n` +
            `> •┊˹🎵˼┊صوت ⇇ *〘.reddit https://www.reddit.com/r/... mp3〙*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      await react('🕒')

      const info = await fetchMedia(url)
      console.log('[reddit]', info.mediaType, '| video:', !!info.videoToken, '| audio:', !!info.audioToken, '| طلب صوت:', wantAudio)

      if (info.mediaType === 'image' && info.images.length) {
        for (const img of info.images.slice(0, 10)) {
          await sock.sendMessage(from, { image: { url: img } }, { quoted: msg })
        }
        await react('✔️')
        return
      }

      if (wantAudio && info.audioToken) {
        const buffer = await downloadWithRetry(info.audioToken)
        await sock.sendMessage(from, {
          audio: buffer,
          fileName: `${info.filename || 'reddit'}.mp3`,
          mimetype: 'audio/mpeg'
        }, { quoted: msg })
        await react('✔️')
        return
      }

      if (info.videoToken) {
        const buffer = await downloadWithRetry(info.videoToken)
        
        const caption = 
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 🎬تـحـمـيـل رديـت⏤͟ू⃪🎬』*\n` +
          `> •┊˹📝˼┊العنوان ⇇ *〘${info.title || 'بدون عنوان'}〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

        await sock.sendMessage(from, {
          video: buffer,
          fileName: `${info.filename || 'reddit'}.mp4`,
          mimetype: 'video/mp4',
          caption
        }, { quoted: msg })
        await react('✔️')
        return
      }

      if (info.audioToken) {
        const buffer = await downloadWithRetry(info.audioToken)
        await sock.sendMessage(from, {
          audio: buffer,
          fileName: `${info.filename || 'reddit'}.mp3`,
          mimetype: 'audio/mpeg'
        }, { quoted: msg })
        await react('✔️')
        return
      }

      throw new Error('ما لقيت محتوى قابل للتحميل')
    } catch (e) {
      console.error('[reddit]', e?.message || e)
      await react('❌')
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e?.message || 'فشل التحميل'}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}

async function fetchMedia(url) {
  const res = await http.post(`${BASE}/fetch`, {
    headers: {
      accept: '*/*',
      'content-type': 'application/json',
      origin: BASE,
      referer: `${BASE}/`
    },
    body: JSON.stringify({ url, lang: 'en' })
  })

  if (res.statusCode !== 200) throw new Error(`ما قدرت أعالج الرابط (HTTP ${res.statusCode})`)

  let data = null
  try { data = JSON.parse(String(res.body)) } catch {}
  if (!data?.success) throw new Error(data?.message || 'الرابط غير صحيح')

  const view = data.view || ''

  const tokens = [...view.matchAll(/href="https:\/\/redvid\.io\/download\?token=([^"]+)"/g)]
    .map(mm => decodeURIComponent(mm[1] || ''))

  const images = [...view.matchAll(/<img[^>]+src="([^"]+)"/g)]
    .map(mm => mm[1] || '')
    .filter(src => src.startsWith('http') && !src.includes('icon') && !src.includes('logo'))

  const titleMatch = view.match(/<h[12][^>]*>([^<]+)<\/h[12]>/)
  const title = titleMatch ? (titleMatch[1] || '').trim() : ''

  return {
    mediaType: data.media_type || 'video',
    videoToken: tokens[0] || '',
    audioToken: tokens[1] || '',
    images,
    title,
    filename: sanitize(title) || 'reddit'
  }
}

async function downloadWithRetry(token) {
  for (let i = 0; i < DOWNLOAD_MAX_RETRIES; i++) {
    const res = await http.get(`${BASE}/download?token=${encodeURIComponent(token)}`, {
      headers: { referer: `${BASE}/` },
      responseType: 'buffer'
    })

    if (res.statusCode === 200) {
      const buffer = Buffer.from(res.rawBody)
      if (buffer.length > 1024) return buffer
    }

    if (res.statusCode === 503 || res.statusCode === 202) {
      await sleep(RETRY_DELAY)
      continue
    }

    if (res.statusCode >= 400) throw new Error(`فشل التحميل (HTTP ${res.statusCode})`)
  }

  throw new Error('التحميل لم يكتمل في الوقت المحدد')
}

function sanitize(s) {
  return (s || '').replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '_').slice(0, 80).toLowerCase()
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms))
}