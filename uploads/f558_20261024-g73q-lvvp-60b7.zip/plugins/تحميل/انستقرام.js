import axios from "axios";

const API_KEY = "Duarte-zz12";

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const withRetry = async (fn, attempt = 1) => {
  try {
    return await fn();
  } catch (e) {
    if (e.response?.status === 429 && attempt <= 3) {
      await delay((e.response.headers["retry-after"] || 5) * 1000);
      return withRetry(fn, attempt + 1);
    }
    throw e;
  }
};

const fetchInstagram = (url) =>
  withRetry(async () => {
    const { data } = await axios.get("https://api.alyacore.xyz/dl/instagram", {
      params: { url, key: API_KEY },
    });
    return data;
  });

function inferirTipoReal(dlUrl) {
  try {
    const u = new URL(dlUrl);
    const token = u.searchParams.get("token");
    if (!token) return null;

    const payload = token.split(".")[1];
    if (!payload) return null;

    const json = JSON.parse(Buffer.from(payload, "base64").toString("utf-8"));
    const filename = json.filename || "";

    if (/\.(mp4|mov|webm|mkv)$/i.test(filename)) return "video";
    if (/\.(jpe?g|png|webp)$/i.test(filename)) return "image";
    return null;
  } catch {
    return null;
  }
}

export default {
  name: ["instagram", "ig", "igdl", "انستقرام"],
  description: "يحمّل فيديوهات/صور من انستقرام (ريلز، منشورات)",
  category: "dl, تحميل",
  groupOnly: false,

  async run({ sock, from, msg, text, usedPrefix, reply, react }) {
    try {
      // ── زخرفة رسالة الخطأ (عدم وجود رابط) ──
      if (!text) {
        return await reply({
          text: 
            `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
            `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊ابعث رابط انستقرام.\n` +
            `> •┊˹💡˼┊الاستخدام ⇇ *〘${usedPrefix || "."}ig <رابط>〙*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      // ── زخرفة رسالة الخطأ (رابط غير صحيح) ──
      if (!/instagram\.com/.test(text)) {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ❌خـطـأ⏤͟ू⃪❌』*\n` +
            `> •┊˹❌˼┊هذا ما يبدو رابط انستقرام صحيح.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      await react("⏳");

      const result = await fetchInstagram(text);

      // ── زخرفة رسالة الفشل ──
      if (!result.status || !result.data?.dl) {
        await react("❌");
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ❌فـشـل الـتـحـمـيـل⏤͟ू⃪❌』*\n` +
            `> •┊˹❌˼┊ما قدرت أحمّل هذا المحتوى.\n` +
            `> •┊˹💡˼┊ممكن يكون الحساب خاص أو الرابط غلط.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      const { data } = result;
      
      // ── زخرفة الكابشن (النص المرافق للفيديو/الصورة) ──
      const caption = 
        `*『͟͞ू⃪ 📥تـم الـتـحـمـيـل⏤͟ू⃪📥』*\n` +
        `> •┊˹🔗˼┊الرابط ⇇ *〘${text.slice(0, 50)}...〙*\n` +
        (data.title ? `> •┊˹📝˼┊الوصف ⇇ *〘${data.title}〙*\n` : '') +
        `\n*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      const tipoReal = inferirTipoReal(data.dl) || data.type;

      if (tipoReal === "video") {
        await sock.sendMessage(
          from,
          { video: { url: data.dl }, caption, mimetype: "video/mp4" },
          { quoted: msg }
        );
      } else {
        await sock.sendMessage(
          from,
          { image: { url: data.dl }, caption },
          { quoted: msg }
        );
      }

      await react("✅");
    } catch (e) {
      console.error("[instagram]", e);
      await react("❌");
      // ── زخرفة رسالة الخطأ البرمجي ──
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ بـالـتـحـمـيـل⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  },
};