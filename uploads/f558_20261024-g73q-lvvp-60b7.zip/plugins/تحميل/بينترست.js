import axios from "axios";
import { generateWAMessageFromContent, generateWAMessage, delay } from "@whiskeysockets/baileys";

async function sendAlbumMessage(sock, jid, medias, options = {}) {
  if (medias.length < 2) throw new RangeError("يحتاج على الأقل صورتين لعمل ألبوم")
  const caption = options.caption || ""
  const quoted  = options.quoted || null

  const album = generateWAMessageFromContent(
    jid,
    { messageContextInfo: {}, albumMessage: { expectedImageCount: medias.length } },
    quoted ? { quoted } : {}
  )

  await sock.relayMessage(album.key.remoteJid, album.message, { messageId: album.key.id })

  for (let i = 0; i < medias.length; i++) {
    const { type, data } = medias[i]
    const img = await generateWAMessage(
      album.key.remoteJid,
      { [type]: data, ...(i === 0 ? { caption } : {}) },
      { upload: sock.waUploadToServer }
    )
    img.message.messageContextInfo = {
      messageAssociation: { associationType: 1, parentMessageKey: album.key }
    }
    await sock.relayMessage(img.key.remoteJid, img.message, { messageId: img.key.id })
    await delay(500)
  }

  return album
}

export default {
  name: ["pinterest", "pin", "بينترست"],
  description: "يبحث عن صور بـ Pinterest",
  category: "dl, تحميل",
  ownerOnly: false,

  async run({ sock, from, msg, text, usedPrefix, react, reply }) {
    try {
      await react("⏳")

      if (!text) return await reply({
        text:
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لازم تكتب وش تبي تبحث عنه.\n` +
          `> •┊˹💡˼┊الاستخدام ⇇ *〘${usedPrefix}pinterest قطط〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      await reply({
        text:
          `*『͟͞ू⃪ 🔍جـاري الـبـحـث⏤͟ू⃪🔍』*\n` +
          `> •┊˹📝˼┊عن ⇇ *〘${text}〙*\n` +
          `> •┊˹⏳˼┊استنى لحظة...\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })

      const res = await axios.get(`https://api.alyacore.xyz/search/pinterest`, {
        params: { query: text, key: "Duarte-zz12" },
        timeout: 10000
      })

      const data = res.data

      if (!data.status || !Array.isArray(data.data) || data.data.length < 2) {
        await react("❌")
        return await reply({
          text:
            `*『͟͞ू⃪ ❌لا نـتـائـج⏤͟ू⃪❌』*\n` +
            `> •┊˹🔍˼┊ما لقيت صور لـ *〘${text}〙*.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      const total  = Math.min(data.data.length, 10)
      const images = data.data.slice(0, total).map(img => ({
        type: "image",
        data: { url: img.hd }
      }))

      const caption =
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 🖼️نـتـائـج بـيـنـتـرسـت⏤͟ू⃪🖼️』*\n` +
        `> •┊˹🔎˼┊البحث ⇇ *〘${text}〙*\n` +
        `> •┊˹🖼️˼┊الصور ⇇ *〘${total}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✯*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sendAlbumMessage(sock, from, images, { caption, quoted: msg })

      await react("✅")

    } catch (error) {
      await react("❌")
      await reply({
        text:
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${error.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
      console.error("خطأ بـ pinterest:", error)
    }
  }
}