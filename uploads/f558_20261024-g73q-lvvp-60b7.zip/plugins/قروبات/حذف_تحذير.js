import { db } from "../../database/db.js";

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ['delwarn', 'unwarn', 'quitarwarn', 'حذف_تحذير'],
  description: 'يحذف تحذير من عضو بالقروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, msg, groupMeta, reply }) {
    try {
      const participants = groupMeta?.participants || []

      const contextInfo = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo
      const mentioned = contextInfo?.mentionedJid || []

      let targetRaw = contextInfo?.participantAlt || contextInfo?.participant || mentioned[0]
      if (!targetRaw) {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊منشن أو رد على المستخدم عشان تحذف تحذيراً منه.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      const cleanTarget = targetRaw.split(':')[0]
      let targetJid = cleanJid(cleanTarget)
      if (cleanTarget.endsWith('@lid')) {
        const match = participants.find(p => p.lid === cleanTarget)
        if (match) targetJid = cleanJid(match.id)
      }

      const groupData = db.getGroup(from) || {}
      const currentWarns = groupData.warns || {}
      const userWarns = currentWarns[targetJid] || []

      if (userWarns.length === 0) {
        return await sock.sendMessage(from, {
          text: 
            `*『͟͞ू⃪ ⚠️لا تـوجـد تـحـذيـرات⏤͟ू⃪⚠️』*\n` +
            `> •┊˹👤˼┊المستخدم ⇇ @${targetJid.split('@')[0]}\n` +
            `> •┊˹❌˼┊ليس لديه تحذيرات نشطة في هذا القروب.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
          mentions: [targetJid]
        }, { quoted: msg })
      }

      userWarns.pop()
      currentWarns[targetJid] = userWarns
      db.setGroup(from, { ...groupData, warns: currentWarns })

      await sock.sendMessage(from, {
        text: 
          `*『͟͞ू⃪ ✅تـم حـذف الـتـحـذيـر⏤͟ू⃪✅』*\n` +
          `> •┊˹👤˼┊المستخدم ⇇ @${targetJid.split('@')[0]}\n` +
          `> •┊˹📊˼┊التحذيرات المتبقية ⇇ *〘${userWarns.length}/3〙*\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [targetJid]
      }, { quoted: msg })

    } catch (err) {
      console.error("خطأ بأمر delwarn:", err)
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ داخلي أثناء تنفيذ الأمر.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}