import { db } from "../../database/db.js";
import { claimOnce, getAllSockets } from "../../core/subbotManager.js";

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const numOf = (jid = "") => jid.split("@")[0].split(":")[0];

export default {
  name: ["bc", "difundir", "broadcast", "بث"],
  description: "يبعث رسالة لكل القروبات اللي فيها بوتات",
  category: "owner, المطور",
  ownerOnly: true,
  groupOnly: true,

  async run({ sock, from, msg, reply, text }) {
    if (!text) return reply({ 
      text: 
        `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
        `> •┊˹❌˼┊اكتب الرسالة.\n` +
        `> •┊˹💡˼┊مثال ⇇ *〘.bc هلا بالكل〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
    if (!claimOnce(`bc:${msg.key.id}`)) return;

    const sent = await reply({ 
      text: 
        `*『͟͞ू⃪ 📢جـاري الـبـث⏤͟ू⃪📢』*\n` +
        `> •┊˹⏳˼┊_جاري تجميع البوتات..._\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
    
    const edit = (t) => sock.sendMessage(from, { text: t, edit: sent.key });

    const bots = getAllSockets().filter((b) => b?.user);

    // 1) Todos los bots listan sus grupos a la vez
    const listas = await Promise.allSettled(
      bots.map(async (bot) => ({
        bot,
        grupos: Object.values(await bot.groupFetchAllParticipating()),
      }))
    );

    const grupos = new Map(); // gid -> Map(numeroBot -> socket)
    for (const r of listas) {
      if (r.status !== "fulfilled") continue;
      const { bot, grupos: gs } = r.value;
      for (const g of gs) {
        if (!grupos.has(g.id)) grupos.set(g.id, new Map());
        grupos.get(g.id).set(numOf(bot.user.id), bot);
      }
    }

    // 2) Reparto: primario si hay, si no el bot con menos carga
    const colas = new Map();
    let skip = 0;
    const orden = [...grupos].sort((a, b) => a[1].size - b[1].size);

    for (const [gid, botsEnGrupo] of orden) {
      if (gid === from) { skip++; continue; }

      const primary = db.getPrimary(gid);
      let emisor = null;

      if (primary) {
        emisor = botsEnGrupo.get(primary) ?? null;
      } else {
        let min = Infinity;
        for (const b of botsEnGrupo.values()) {
          const carga = colas.get(b)?.length ?? 0;
          if (carga < min) { min = carga; emisor = b; }
        }
      }

      if (!emisor) { skip++; continue; }
      if (!colas.has(emisor)) colas.set(emisor, []);
      colas.get(emisor).push(gid);
    }

    const total = [...colas.values()].reduce((a, q) => a + q.length, 0);
    let ok = 0, fail = 0, hechos = 0;

    await edit(
      `*『͟͞ू⃪ 📢جـاري الإرسـال⏤͟ू⃪📢』*\n` +
      `> •┊˹📊˼┊التقدم ⇇ *〘0/${total}〙*\n` +
      `> •┊˹🤖˼┊عدد البوتات ⇇ *〘${colas.size}〙*\n\n` +
      `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    );

    // 3) Todos los bots mandan al mismo tiempo
    await Promise.all(
      [...colas].map(async ([bot, cola]) => {
        for (const gid of cola) {
          try { await bot.sendMessage(gid, { text }); ok++; } catch { fail++; }
          hechos++;
          if (hechos % 25 === 0) {
            edit(
              `*『͟͞ू⃪ 📢جـاري الإرسـال⏤͟ू⃪📢』*\n` +
              `> •┊˹📊˼┊التقدم ⇇ *〘${hechos}/${total}〙*\n` +
              `> •┊˹🤖˼┊عدد البوتات ⇇ *〘${colas.size}〙*\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
            ).catch(() => {});
          }
          await sleep(2000 + Math.random() * 2000);
        }
      })
    );

    await edit(
      `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
      `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
      `*『͟͞ू⃪ ✅انـتـهـى الـبـث⏤͟ू⃪✅』*\n` +
      `> •┊˹✅˼┊تم الإرسال ⇇ *〘${ok}〙*\n` +
      `> •┊˹❌˼┊فشل ⇇ *〘${fail}〙*\n` +
      `> •┊˹⏭️˼┊تم تجاوزه ⇇ *〘${skip}〙*\n\n` +
      `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
      `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    );
  },
};