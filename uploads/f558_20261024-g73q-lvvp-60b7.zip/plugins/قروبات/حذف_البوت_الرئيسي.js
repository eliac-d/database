import { db } from '../../database/db.js'
import { claimOnce } from '../../core/subbotManager.js'

export default {
  name: ['delprimary', 'quitarprincipal', 'حذف_الرئيسي'],
  description: 'يحذف البوت الرئيسي من القروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ from, msg, react, reply }) {
    if (!claimOnce(msg.key.id)) return

    const primary = db.getPrimary(from)
    
    if (!primary) {
      return await reply({
        text:
          `*『͟͞ू⃪ ⚠️لا يـوجـد بـوت رئـيـسـي⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊هذا القروب لا يملك بوتاً رئيسياً محدداً.\n\n` +
          `> •┊˹💡˼┊استخدم *〘.setprimary〙* لتحديد واحد.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    db.delPrimary(from)

    await react('🗑️')
    
    await reply({
      text:
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ ✅تـم الـحـذف⏤͟ू⃪✅』*\n` +
        `> •┊˹🗑️˼┊تم حذف البوت الرئيسي بنجاح.\n` +
        `> •┊˹🤖˼┊كل البوتات والسب-بوتات سترد في هذا القروب الآن.\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
        `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
        `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })
  }
}