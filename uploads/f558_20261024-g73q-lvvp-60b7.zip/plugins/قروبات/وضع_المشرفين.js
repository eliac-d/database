import { db } from '../../database/db.js'

export default {
  name: ['modoadmin', 'وضع_المشرفين'],
  description: 'يفعّل أو يعطّل وضع المشرفين بس بالقروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, reply }) {
    const opcion = args[0]?.toLowerCase()

    if (opcion !== 'on' && opcion !== 'off') {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹💡˼┊استخدم:\n` +
          `> ┊˹✅˼┊*.modoadmin on*\n` +
          `> ┊˹❌˼┊*.modoadmin off*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const activar = opcion === 'on'
    db.setGroup(from, { adminMode: activar })

    await reply({
      text: activar
        ? `*『͟͞ू⃪ 🔒تـم الـتـفـعـيـل⏤͟ू⃪🔒』*\n` +
          `> •┊˹📌˼┊الحالة ⇇ *〘وضع المشرفين مفعل〙*\n` +
          `> •┊˹💬˼┊المشرفون، المالك، والمساعدون فقط يمكنهم استخدام الأوامر في هذا القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        : `*『͟͞ू⃪ 🔓تـم الإيـقـاف⏤͟ू⃪🔓』*\n` +
          `> •┊˹📌˼┊الحالة ⇇ *〘وضع المشرفين معطل〙*\n` +
          `> •┊˹💬˼┊جميع المستخدمين يمكنهم استخدام الأوامر من جديد.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    })
  }
}