import { db } from "../../database/db.js";

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ['warn', 'advertir', 'تحذير'],
  description: 'يحذر عضواً في المجموعة',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, msg, groupMeta, args, reply }) {
    try {
      const participants = groupMeta?.participants || []

      const contextInfo = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo
      const mentioned = contextInfo?.mentionedJid || []

      let targetRaw = contextInfo?.participantAlt || contextInfo?.participant || mentioned[0]
      
      if (!targetRaw) {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊اذكر أو رد على المستخدم الذي تريد تحذيره.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      const cleanTarget = targetRaw.split(':')[0]
      let targetJid = cleanJid(cleanTarget)
      if (cleanTarget.endsWith('@lid')) {
        const match = participants.find(p => p.lid === cleanTarget)
        if (match) targetJid = cleanJid(match.id)
      }

      const targetParticipant = participants.find(p => cleanJid(p.id) === targetJid)
      if (targetParticipant?.admin === 'admin' || targetParticipant?.admin === 'superadmin') {
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️مـشـرف⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊لا يمكنك تحذير مشرف آخر.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      const groupData = db.getGroup(from) || {}
      const currentWarns = groupData.warns || {}
      if (!currentWarns[targetJid]) currentWarns[targetJid] = []

      const adminName = msg.pushName || "المشرف"
      const razon = args.join(" ") || "لم يتم تحديد سبب."
      const targetNum = targetJid.split('@')[0]

      currentWarns[targetJid].push({
        razon,
        fecha: new Date().toLocaleDateString("ar-EG"),
        by: adminName,
        targetNum: targetNum
      })

      db.setGroup(from, { ...groupData, warns: currentWarns })

      const totalWarns = currentWarns[targetJid].length
      const willKick = totalWarns >= 3

      let texto = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ ⚠️تـم تـحـذيـر الـعـضـو⏤͟ू⃪⚠️』*\n` +
        `> •┊˹👤˼┊العضو ⇇ @${targetNum}\n` +
        `> •┊˹👮‍♂️˼┊بواسطة ⇇ *〘${adminName}〙*\n` +
        `> •┊˹📝˼┊السبب ⇇ *〘${razon}〙*\n` +
        `> •┊˹📊˼┊التحذيرات ⇇ *〘${totalWarns}/3〙*\n\n`

      if (willKick) {
        texto += `> •┊˹❗˼┊_هذا العضو وصل للحد الأقصى (3 تحذيرات) وسيتم طرده._\n\n`
      }

      texto += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sock.sendMessage(from, {
        text: texto,
        mentions: [targetJid]
      }, { quoted: msg })

      if (willKick) {
        try {
          const botJid = cleanJid(sock.user?.id || "")
          const botLid = sock.user?.lid ? cleanJid(sock.user.lid) : null
          const botParticipant = participants.find(p =>
            cleanJid(p.id) === botJid ||
            (botLid && cleanJid(p.id) === botLid) ||
            (p.lid && cleanJid(p.lid) === botJid) ||
            (p.lid && botLid && cleanJid(p.lid) === botLid)
          )
          const botIsAdmin = botParticipant?.admin === 'admin' || botParticipant?.admin === 'superadmin'

          if (!botIsAdmin) {
            await reply({ 
              text: 
                `*『͟͞ू⃪ ⚠️صـلاحـيـات⏤͟ू⃪⚠️』*\n` +
                `> •┊˹❌˼┊لم أستطع طرد @${targetNum} لأنني لست مشرفاً.\n\n` +
                `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
              mentions: [targetJid] 
            })
          } else {
            await sock.groupParticipantsUpdate(from, [targetJid], 'remove')
            currentWarns[targetJid] = []
            db.setGroup(from, { ...groupData, warns: currentWarns })
            await reply({ 
              text: 
                `*『͟͞ू⃪ 👢تـم الـطـرد⏤͟ू⃪👢』*\n` +
                `> •┊˹❌˼┊تم طرد @${targetNum} لتجاوزه 3 تحذيرات.\n\n` +
                `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
              mentions: [targetJid] 
            })
          }
        } catch (kickErr) {
          console.error("خطأ بالطرد بعد 3 تحذيرات:", kickErr)
          await reply({ 
            text: 
              `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
              `> •┊˹❌˼┊لم أستطع طرد @${targetNum} (تحقق من صلاحياتي).\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
            mentions: [targetJid] 
          })
        }
      }

    } catch (err) {
      console.error("خطأ في أمر warn:", err)
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ داخلي أثناء تنفيذ الأمر.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}