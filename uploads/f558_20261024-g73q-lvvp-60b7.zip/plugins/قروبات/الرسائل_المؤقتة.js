const DURATIONS = {
  off: 0,
  "24h": 86400,
  "7d": 604800,
  "90d": 7776000
};

export default {
  name: ["efimero", "temporal", "مؤقتة", "الرسائل_المؤقتة"],
  description: "يضبط مدة الرسائل المؤقتة بالقروب",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, args, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (!DURATIONS.hasOwnProperty(opcion)) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⏳تـنـبـيـه⏤͟ू⃪⏳』*\n` +
          `> •┊˹💡˼┊الاستخدام ⇇ *〘.efimero off/24h/7d/90d〙*\n` +
          `> •┊˹📝˼┊مثال ⇇ *〘.efimero 7d〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    try {
      await sock.groupToggleEphemeral(from, DURATIONS[opcion]);
      
      await reply({
        text: opcion === "off"
          ? `*『͟͞ू⃪ ✅تـم الإيـقـاف⏤͟ू⃪✅』*\n> •┊˹⏳˼┊تم إيقاف الرسائل المؤقتة.\n\n*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          : `*『͟͞ू⃪ ✅تـم الـتـفـعـيـل⏤͟ू⃪✅』*\n> •┊˹⏳˼┊تم تفعيل الرسائل المؤقتة ⇇ *〘${opcion}〙*\n\n*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أغيّر الإعداد:\n${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};