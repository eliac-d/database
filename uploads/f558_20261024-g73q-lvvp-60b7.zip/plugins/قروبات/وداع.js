import { db } from "../../database/db.js";

export default {
  name: ["bye", "وداع"],
  description: "يفعّل أو يعطّل رسالة الوداع للأعضاء اللي يطلعون",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, text, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (opcion === "on" || opcion === "off") {
      db.setGroup(from, { bye: opcion === "on" });
      return await reply({
        text: 
          `*『͟͞ू⃪ 🚪الـوداع⏤͟ू⃪🚪』*\n` +
          `> •┊˹${opcion === "on" ? '✅' : '❌'}˼┊الحالة ⇇ *〘${opcion === "on" ? "مفعل" : "معطل"}〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    if (opcion === "set") {
      const nuevoMsg = text.replace(/^set\s*/i, "").trim();
      if (!nuevoMsg) {
        return await reply({
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊اكتب رسالة الوداع بعد set.\n\n` +
            `> •┊˹💡˼┊متغيرات متاحة ⇇ @user، %grupo%\n` +
            `> •┊˹📝˼┊مثال ⇇ .bye set مع السلامة @user من %grupo%\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }
      db.setGroup(from, { byeMsg: nuevoMsg });
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ✅تـم الـتـحـديـث⏤͟ू⃪✅』*\n` +
          `> •┊˹📝˼┊تم تحديث رسالة الوداع بنجاح.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const estado = db.getGroup(from).bye ? "مفعّل ✅" : "معطّل ❌";
    return await reply({
      text: 
        `*『͟͞ू⃪ 🚪الـوداع⏤͟ू⃪🚪』*\n` +
        `> •┊˹📊˼┊الحالة ⇇ *〘${estado}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*『͟͞ू⃪ 💡الاسـتـخـدام⏤͟ू⃪💡』*\n` +
        `> •┊˹✅˼┊.bye on / off\n` +
        `> •┊˹📝˼┊.bye set <رسالة>\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};