import { db } from "../../database/db.js";

// ── دالة مساعدة لبناء الرسالة ──
function getStatus(val) {
  return val ? "✅ مفعل" : "❌ معطل";
}

export default {
  name: ["الاعدادات", "شوف", "settings", "panel"],
  description: "قائمة تحكم تفاعلية لإعدادات المجموعة",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, msg, react, reply, args, cmdName }) {
    const cmd = (cmdName || "").toLowerCase();
    
    // ═══════════════════════════════════════════════
    // 1️⃣ التعامل مع ضغطات الأزرار (عندما يضغط المستخدم زر)
    // ═══════════════════════════════════════════════
    if (cmd.startsWith("toggle_") || (args && args[0]?.startsWith("toggle_"))) {
      const action = cmd.startsWith("toggle_") ? cmd : args[0];
      const feature = action.replace("toggle_", ""); // مثلاً welcome, bye, antilink
      
      const groupData = db.getGroup(from) || {};
      const currentVal = groupData[feature] || false;
      
      // عكس الحالة (إذا مفعل يخليه معطل والعكس)
      db.setGroup(from, { [feature]: !currentVal });

      await react(!currentVal ? "✅" : "❌");
      
      // إرسال رسالة تأكيد سريعة
      await reply({ 
        text: `*『͟͞ू⃪ ⚙️تـم الـتـحـديـث⏤͟ू⃪⚙️』*\n> •┊˹📌˼┊الإعداد ⇇ *〘${feature}〙*\n> •┊˹🔄˼┊الحالة الجديدة ⇇ *〘${!currentVal ? "مفعل ✅" : "معطل ❌"}〙*` 
      });
      
      // إعادة إرسال القائمة الرئيسية بعد التحديث
      return await this.run({ sock, from, msg, react, reply, args: [] });
    }

    // ═══════════════════════════════════════════════
    // 2️⃣ عرض القائمة الرئيسية
    // ═══════════════════════════════════════════════
    await react("⚙️");
    const data = db.getGroup(from) || {};

    const text = 
      `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
      `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
      `*『͟͞ू⃪ ⚙️لـوحـة الـتـحـكـم⏤͟ू⃪⚙️』*\n` +
      `> •┊˹📊˼┊ترحيب ⇇ *〘${getStatus(data.welcome)}〙*\n` +
      `> •┊˹🚪˼┊وداع ⇇ *〘${getStatus(data.bye)}〙*\n` +
      `> •┊˹🔗˼┊مضاد الروابط ⇇ *〘${getStatus(data.antilink)}〙*\n` +
      `> •┊˹📵˼┊مضاد الحالات ⇇ *〘${getStatus(data.antistatus)}〙*\n` +
      `> •┊˹👤˼┊مضاد جهات الاتصال ⇇ *〘${getStatus(data.anticontact)}〙*\n` +
      `> •┊˹👮˼┊وضع المشرفين ⇇ *〘${getStatus(data.adminMode)}〙*\n\n` +
      `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
      `> ⚠️ _اضغط على الزر لتشغيل أو إيقاف الميزة فوراً._\n\n` +
      `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

    // ═══════════════════════════════════════════════
    // 3️⃣ الأزرار التفاعلية (تتغير حسب الحالة)
    // ═══════════════════════════════════════════════
    const buttons = [
      { text: `ترحيب: ${data.welcome ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_welcome" },
      { text: `وداع: ${data.bye ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_bye" },
      { text: `مضاد الروابط: ${data.antilink ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_antilink" },
      { text: `مضاد الحالات: ${data.antistatus ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_antistatus" },
      { text: `مضاد جهات الاتصال: ${data.anticontact ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_anticontact" },
      { text: `وضع المشرفين: ${data.adminMode ? "إيقاف ❌" : "تفعيل ✅"}`, id: ".toggle_adminMode" },
    ];

    try {
      if (typeof sock.sendButtonMessage === "function") {
        await sock.sendButtonMessage(from, text, buttons, {
          title: "لوحة التحكم",
          footer: "𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓",
          quoted: msg
        });
      } else {
        // Fallback: إذا كانت الأزرار غير مدعومة، نرسل الأوامر كأزرار نصية
        let fallbackText = text + `\n\n*الأوامر اليدوية:*\n`;
        buttons.forEach(b => fallbackText += `> ${b.id}\n`);
        await sock.sendMessage(from, { text: fallbackText }, { quoted: msg });
      }
    } catch (e) {
      console.error("خطأ بإرسال أزرار الإعدادات:", e);
      await reply({ text: "⚠️ فشل إرسال لوحة التحكم." });
    }
  }
};