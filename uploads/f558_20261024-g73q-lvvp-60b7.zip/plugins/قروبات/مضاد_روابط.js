import { db } from "../../database/db.js";

export default {
  name: ["antilink", "مضاد_الروابط"],
  description: "يفعّل أو يعطّل مضاد الروابط بالقروب",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (!["on", "off"].includes(opcion)) {
      const estado = db.getGroup(from).antilink ? "مفعّل ✅" : "معطّل ❌";
      return await reply({
        text: 
          `*『͟͞ू⃪ 🔗مـضـاد الـروابـط⏤͟ू⃪🔗』*\n` +
          `> •┊˹📊˼┊الحالة ⇇ *〘${estado}〙*\n\n` +
          `> •┊˹💡˼┊الاستخدام:\n` +
          `> ┊˹✅˼┊.antilink on\n` +
          `> ┊˹❌˼┊.antilink off\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    db.setGroup(from, { antilink: opcion === "on" });

    return await reply({
      text: 
        `*『͟͞ू⃪ 🔗مـضـاد الـروابـط⏤͟ू⃪🔗』*\n` +
        `> •┊˹${opcion === "on" ? '✅' : '❌'}˼┊الحالة ⇇ *〘${opcion === "on" ? "مفعل" : "معطل"}〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};