import { db } from "../../database/db.js";

export default {
  name: ["antistatus", "مضاد_حالات"],
  description: "يحذف المحتوى المعاد توجيهه (حالات متشاركة) تلقائيًا بالقروب",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (!["on", "off"].includes(opcion)) {
      const estado = db.getGroup(from).antistatus ? "مفعّل ✅" : "معطّل ❌";
      return await reply({
        text:
          `*『͟͞ू⃪ 📵مـضـاد الـحـالات⏤͟ू⃪📵』*\n` +
          `> •┊˹📊˼┊الحالة ⇇ *〘${estado}〙*\n\n` +
          `> •┊˹💡˼┊الاستخدام:\n` +
          `> ┊˹✅˼┊.antistatus on\n` +
          `> ┊˹❌˼┊.antistatus off\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*『͟͞ू⃪ ⚠️مـلاحـظـة⏤͟ू⃪⚠️』*\n` +
          `> •┊˹📝˼┊واتساب لا يميز الحالة المتشاركة عن أي رسالة معاد توجيهها بشكل قاطع.\n` +
          `> •┊˹🗑️˼┊هذا الأمر يحذف أي محتوى معاد توجيهه (غير مرتبط برد على رسالة).\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    db.setGroup(from, { antistatus: opcion === "on" });

    return await reply({
      text: 
        `*『͟͞ू⃪ 📵مـضـاد الـحـالات⏤͟ू⃪📵』*\n` +
        `> •┊˹${opcion === "on" ? '✅' : '❌'}˼┊الحالة ⇇ *〘${opcion === "on" ? "مفعل" : "معطل"}〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};