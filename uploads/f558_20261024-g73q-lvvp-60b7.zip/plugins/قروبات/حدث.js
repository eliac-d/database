const TIMEZONES = {
  cuba: "America/Havana",
  colombia: "America/Bogota",
  mexico: "America/Mexico_City",
  argentina: "America/Argentina/Buenos_Aires",
  chile: "America/Santiago",
  peru: "America/Lima",
  venezuela: "America/Caracas",
  ecuador: "America/Guayaquil",
  bolivia: "America/La_Paz",
  paraguay: "America/Asuncion",
  uruguay: "America/Montevideo",
  panama: "America/Panama",
  "costa rica": "America/Costa_Rica",
  guatemala: "America/Guatemala",
  honduras: "America/Tegucigalpa",
  "el salvador": "America/El_Salvador",
  nicaragua: "America/Managua",
  "republica dominicana": "America/Santo_Domingo",
  españa: "Europe/Madrid",
  usa: "America/New_York",
  "estados unidos": "America/New_York",
  السعودية: "Asia/Riyadh",
  مصر: "Africa/Cairo",
  الإمارات: "Asia/Dubai",
  الأردن: "Asia/Amman",
  العراق: "Asia/Baghdad",
  الكويت: "Asia/Kuwait",
  قطر: "Asia/Qatar",
  البحرين: "Asia/Bahrain",
  عمان: "Asia/Muscat",
  اليمن: "Asia/Aden",
  سوريا: "Asia/Damascus",
  لبنان: "Asia/Beirut",
  فلسطين: "Asia/Gaza",
  المغرب: "Africa/Casablanca",
  الجزائر: "Africa/Algiers",
  تونس: "Africa/Tunis",
  ليبيا: "Africa/Tripoli",
  السودان: "Africa/Khartoum",
  تركيا: "Europe/Istanbul"
};

function getTimeZoneOffsetMinutes(date, timeZone) {
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hour12: false,
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", second: "2-digit"
  });
  const parts = dtf.formatToParts(date);
  const map = {};
  for (const p of parts) map[p.type] = p.value;
  const asUTC = Date.UTC(
    map.year, map.month - 1, map.day,
    map.hour === "24" ? 0 : map.hour, map.minute, map.second
  );
  return (asUTC - date.getTime()) / 60000;
}

function localTimeToUtc(year, month, day, hour, minute, timeZone) {
  const utcGuess = Date.UTC(year, month - 1, day, hour, minute);
  const offsetMinutes = getTimeZoneOffsetMinutes(new Date(utcGuess), timeZone);
  return new Date(utcGuess - offsetMinutes * 60000);
}

export default {
  name: ["evento", "حدث"],
  description: "يسوي حدث بالقروب مع تأكيد حضور",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, text, reply }) {
    if (!text) {
      return await reply({
        text: 
          `*『͟͞ू⃪ 📅تـنـبـيـه⏤͟ू⃪📅』*\n` +
          `> •┊˹💡˼┊الاستخدام ⇇ *〘.evento اسم | وصف | DD/MM/YYYY HH:MM | دولة〙*\n\n` +
          `> •┊˹📝˼┊مثال ⇇ .evento اجتماع | لقاء أسبوعي | 20/08/2026 19:00 | السعودية\n\n` +
          `> •┊˹🌍˼┊الدول المدعومة ⇇\n${Object.keys(TIMEZONES).join("، ")}\n\n` +
          `> •┊˹⚠️˼┊_تقدر تحط منطقة زمنية IANA مباشرة (مثال: Asia/Riyadh)._\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const [name, description, dateStr, tzArg] = text.split("|").map((s) => s.trim());

    if (!name || !dateStr) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️نـاقـص بـيـانـات⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊استخدم ⇇ *〘.evento اسم | وصف | DD/MM/YYYY HH:MM | دولة〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const match = dateStr.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})\s+(\d{1,2}):(\d{2})/);
    if (!match) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️صـيـغـة الـتـاريـخ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊صيغة التاريخ غير صحيحة.\n` +
          `> •┊˹💡˼┊استخدم ⇇ *〘DD/MM/YYYY HH:MM〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const timeZone = tzArg
      ? TIMEZONES[tzArg.toLowerCase()] || tzArg
      : "Asia/Riyadh";

    try {
      new Intl.DateTimeFormat("en-US", { timeZone }).format(new Date());
    } catch {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️مـنـطـقـة زمـنـيـة غـيـر مـعـروفـة⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما أعرف هذه المنطقة الزمنية: "${tzArg}"\n\n` +
          `> •┊˹🌍˼┊الدول المدعومة ⇇\n${Object.keys(TIMEZONES).join("، ")}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const [, day, month, year, hour, minute] = match.map(Number);
    const startDate = localTimeToUtc(year, month, day, hour, minute, timeZone);

    if (isNaN(startDate.getTime()) || startDate.getTime() < Date.now()) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـاريـخ غـيـر صـحـيـح⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊التاريخ غير صحيح أو قد فات.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    try {
      await sock.sendMessage(from, {
        event: {
          name,
          description: description || "",
          startDate,
          extraGuestsAllowed: true
        }
      });
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أسوي الحدث: ${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};