import { db } from '../../database/db.js'
import { activeBots, claimOnce } from '../../core/subbotManager.js'

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ['setprimary', 'botprincipal', 'تعيين_الرئيسي'],
  description: 'يحدد بوتاً ليكون هو الأساسي في المجموعة',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ from, msg, react, reply, resolveLid }) {
    if (!claimOnce(msg.key.id)) return

    const parseNum = (jid) => jid ? jid.split('@')[0] : null
    const primary = db.getPrimary(from)

    const ownMentions = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || []

    const quoted = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo
    const quotedMentions = quoted?.mentionedJid || []
    const targetRaw = ownMentions[0]
      ? cleanJid(ownMentions[0])
      : (quotedMentions[0] ? cleanJid(quotedMentions[0]) : (quoted?.participant ? cleanJid(quoted.participant) : null))

    let quotedSender = null
    if (targetRaw) {
      const resolved = await resolveLid(targetRaw)
      quotedSender = parseNum(cleanJid(resolved))
    }

    const botsActivos = [...activeBots.entries()].filter(([, bot]) => bot.status === 'online')

    if (!quotedSender) {
      let texto = 
        `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
        `> •┊˹❓˼┊أي بوت تريد تعيينه كرئيسي؟\n\n`
      
      for (const [, bot] of botsActivos) {
        const num = parseNum(cleanJid(bot.jid)) || 'غير متاح'
        texto += `> •┊˹🤖˼┊*${bot.label || 'سب-بوت'}* ⇇ @${num}\n`
      }
      texto += `\n> •┊˹💡˼┊اذكر البوت (@رقمه) ونفذ الأمر *.setprimary* مرة أخرى.\n\n`
      texto += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      const mentionJids = botsActivos.map(([, bot]) => cleanJid(bot.jid)).filter(Boolean)
      return await reply({ text: texto, mentions: mentionJids })
    }

    const esBotValido = botsActivos.some(([, bot]) => parseNum(cleanJid(bot.jid)) === quotedSender)

    if (!esBotValido) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ❌غـيـر صـالـح⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊هذا الرقم ليس بوتاً نشطاً في هذه الجلسة.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const whoNum = quotedSender
    const whoJid = cleanJid(`${whoNum}@s.whatsapp.net`)

    if (primary === whoNum) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️مـسـبـقـاً⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊@${whoNum} هو بالفعل البوت الرئيسي لهذه المجموعة.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [whoJid] 
      })
    }

    db.setPrimary(from, whoNum)

    await react('✅')
    
    await reply({
      text:
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 👑تـم الـتـعـيـيـن⏤͟ू⃪👑』*\n` +
        `> •┊˹🤖˼┊البوت ⇇ @${whoNum}\n` +
        `> •┊˹📌˼┊الحالة ⇇ *〘أصبح البوت الرئيسي〙*\n\n` +
        `> •┊˹⚠️˼┊_البوتات الأخرى لن ترد في هذه المجموعة._\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
      mentions: [whoJid]
    })
  }
}