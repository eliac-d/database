export default {
  name: ['join', 'unirse', 'انضمام'],
  description: 'يجعل البوت ينضم لقروب عبر رابط',
  category: 'grupos, مجموعات',
  ownerOnly: true,

  async run({ sock, text, usedPrefix, react, reply }) {
    await react('⏳')

    if (!text) {
      return await reply({
        text:
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ضع رابط القروب.\n` +
          `> •┊˹💡˼┊مثال ⇇ *〘${usedPrefix}join https://chat.whatsapp.com/XXXXXX〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const match = text.trim().match(/chat\.whatsapp\.com\/([A-Za-z0-9]{20,24})/)

    if (!match) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ❌رابـط غـيـر صـحـيـح⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊لازم يكون بهذا الشكل:\n` +
          `> ┊˹🔗˼┊*https://chat.whatsapp.com/XXXXXX*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const code = match[1]

    try {
      await sock.groupAcceptInvite(code)
      await react('✅')
      
      await reply({
        text:
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ ✅تـم الانـضـمـام⏤͟ू⃪✅』*\n` +
          `> •┊˹🤖˼┊انضم البوت للقروب بنجاح.\n` +
          `> •┊˹🔗˼┊الرابط ⇇ ${text.trim()}\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
          `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
          `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    } catch (e) {
      await react('❌')
      console.log(e)
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أنضم: ${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}