function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ['demote', 'خفض', 'سحب_الاشراف'],
  description: 'يحذف صلاحية الإشراف من عضو بالقروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  botAdmin: true,
  adminOnly: true,

  async run({ sock, from, msg, groupMeta, clearGroupCache, reply, senderNum, sender }) {
    const participants = groupMeta?.participants || []

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo
    const mentioned = contextInfo?.mentionedJid || []

    let targetRaw = contextInfo?.participantAlt || contextInfo?.participant || mentioned[0]
    if (!targetRaw) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊منشن أو رد على المستخدم عشان تحذف إشرافه.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const cleanTarget = targetRaw.split(':')[0]
    let targetJid = cleanJid(cleanTarget)
    if (cleanTarget.endsWith('@lid')) {
      const match = participants.find(p => p.lid === cleanTarget)
      if (match) targetJid = cleanJid(match.id)
    }

    const targetParticipant = participants.find(p => cleanJid(p.id) === targetJid)

    if (targetParticipant?.admin === 'superadmin') {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـنـشـئ الـقـروب⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊ما تقدر تحذف إشراف صاحب القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
    if (targetParticipant?.admin !== 'admin') {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️لـيـس مـشـرف⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊هذا المستخدم ليس مشرفاً.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    try {
      await sock.groupParticipantsUpdate(from, [targetJid], "demote")
      clearGroupCache()

      const targetNum = targetJid.split('@')[0]
      
      const textoDemote = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 📉تـم سـحـب الإشـراف⏤͟ू⃪📉』*\n` +
        `> •┊˹👤˼┊العضو ⇇ @${targetNum}\n` +
        `> •┊˹📌˼┊الحالة ⇇ *〘تم سحب الإشراف منه〙*\n` +
        `> •┊˹✍️˼┊بواسطة ⇇ @${senderNum}\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sock.sendMessage(from, {
        text: textoDemote,
        contextInfo: { mentionedJid: [targetJid, sender] }
      }, { quoted: msg })
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أسحب الإشراف: ${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}