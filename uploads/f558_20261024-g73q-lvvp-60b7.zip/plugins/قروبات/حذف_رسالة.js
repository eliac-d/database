import { jidNormalizedUser } from "@whiskeysockets/baileys";

export default {
  name: ["del", "delete", "eliminar", "حذف"],
  description: "يحذف رسالة بالرد عليها",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,
  botAdmin: true,

  async run({ sock, from, msg, reply }) {
    const quoted = msg.message?.extendedTextMessage?.contextInfo;

    if (!quoted?.stanzaId) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹✖️˼┊رد على الرسالة التي تريد حذفها.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    try {
      await sock.sendMessage(from, {
        delete: {
          remoteJid: from,
          id: quoted.stanzaId,
          participant: jidNormalizedUser(quoted.participant),
          fromMe: false
        }
      });
    } catch (e) {
      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أحذف الرسالة:\n${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};