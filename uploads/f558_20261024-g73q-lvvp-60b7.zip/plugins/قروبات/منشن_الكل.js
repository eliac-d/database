function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ["tagall", "todos", "منشن", "mentionall", "منشن_الكل"],
  description: "منشن جميع أعضاء المجموعة",
  category: "grupos, مجموعات",
  adminOnly: true,
  groupOnly: true,

  async run({ sock, from, msg, text = "", args = [], reply, react }) {
    try {
      const mensaje = text.trim() || args.join(" ").trim();

      if (!mensaje) {
        return reply({
          text:
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹💡˼┊الاستخدام الصحيح:\n` +
            `> ┊˹📝˼┊*.tagall رسالتك هنا*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        });
      }

      await react("💥");

      const metadata = await sock.groupMetadata(from);

      const participants = metadata.participants
        .map((p) => cleanJid(p.id))
        .filter(Boolean);

      const report = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 💥مـنـشـن عـام⏤͟ू⃪💥』*\n` +
        `> •┊˹📝˼┊الرسالة ⇇ *〘${mensaje}〙*\n` +
        `> •┊˹👥˼┊عدد الأعضاء ⇇ *〘${participants.length}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `${participants.map((jid) => `> •┊˹👤˼┊@${jid.split("@")[0]}`).join("\n")}\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      await sock.sendMessage(
        from,
        {
          text: report,
          mentions: participants,
        },
        { quoted: msg }
      );

      await react("✅");
    } catch (e) {
      console.error(e);
      await react("❌");
      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ أثناء تنفيذ الأمر.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
      });
    }
  },
};