import { db } from "../../database/db.js";

export default {
  name: ["welcome", "ترحيب"],
  description: "يفعّل أو يعطّل رسالة الترحيب بالأعضاء الجدد",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, text, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (opcion === "on" || opcion === "off") {
      db.setGroup(from, { welcome: opcion === "on" });
      return await reply({
        text: 
          `*『͟͞ू⃪ 👋الـتـرحـيـب⏤͟ू⃪👋』*\n` +
          `> •┊˹${opcion === "on" ? '✅' : '❌'}˼┊حالة الترحيب ⇇ *〘${opcion === "on" ? "مفعل" : "معطل"}〙*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    if (opcion === "set") {
      const nuevoMsg = text.replace(/^set\s*/i, "").trim();
      if (!nuevoMsg) {
        return await reply({
          text: 
            `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊اكتب رسالة الترحيب بعد set.\n\n` +
            `> •┊˹💡˼┊متغيرات متاحة ⇇ @user، %grupo%، %total%\n` +
            `> •┊˹📝˼┊مثال ⇇ .welcome set هلا @user بقروب %grupo%! انت العضو رقم %total%\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }
      db.setGroup(from, { welcomeMsg: nuevoMsg });
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ✅تـم الـتـحـديـث⏤͟ू⃪✅』*\n` +
          `> •┊˹📝˼┊تم تحديث رسالة الترحيب بنجاح.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const estado = db.getGroup(from).welcome ? "مفعّل ✅" : "معطّل ❌";
    return await reply({
      text: 
        `*『͟͞ू⃪ 👋الـتـرحـيـب⏤͟ू⃪👋』*\n` +
        `> •┊˹📊˼┊الحالة ⇇ *〘${estado}〙*\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*『͟͞ू⃪ 💡الاسـتـخـدام⏤͟ू⃪💡』*\n` +
        `> •┊˹✅˼┊.welcome on / off\n` +
        `> •┊˹📝˼┊.welcome set <رسالة>\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};