export default {
  name: ["revokelink", "revocarlink", "resetlink", "تغيير_الرابط"],
  description: "يلغي رابط القروب الحالي وينشئ رابط جديد",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, reply }) {
    try {
      const code = await sock.groupRevokeInvite(from);
      const link = `https://chat.whatsapp.com/${code}`;

      await reply({
        text: 
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 🔄تـم تـغـيـيـر الـرابـط⏤͟ू⃪🔄』*\n` +
          `> •┊˹⚠️˼┊الرابط السابق لم يعد يعمل.\n` +
          `> •┊˹🔗˼┊الرابط الجديد ⇇ ${link}\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
          `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
          `*╯✯≼══━━﹂🌺﹁━━══≽✽*\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });

    } catch (e) {
      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊لم أتمكن من تغيير رابط القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};