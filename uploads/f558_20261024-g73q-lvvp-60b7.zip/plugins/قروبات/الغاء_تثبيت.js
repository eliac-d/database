import { jidNormalizedUser } from "@whiskeysockets/baileys";

export default {
  name: ["desfijar", "الغاء_التثبيت"],
  description: "يلغي تثبيت رسالة بالرد عليها",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, msg, reply, resolveLid }) {
    const quoted = msg.message?.extendedTextMessage?.contextInfo;

    if (!quoted?.stanzaId) {
      return await reply({
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹📌˼┊رد على الرسالة التي تريد إلغاء تثبيتها.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    const isFromMe = !quoted.participant || quoted.participant === sock.user?.id;
    let participant = quoted.participant;

    if (!isFromMe && participant) {
      participant = await resolveLid(participant);
    }

    const pinKey = {
      remoteJid: from,
      id: quoted.stanzaId,
      participant: isFromMe ? undefined : participant,
      fromMe: isFromMe
    };

    try {
      await sock.sendMessage(from, {
        pin: pinKey,
        type: 2
      });

      await reply({ 
        text: 
          `*『͟͞ू⃪ ✅تـم الإلـغـاء⏤͟ू⃪✅』*\n` +
          `> •┊˹📌˼┊تم إلغاء تثبيت الرسالة بنجاح.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت ألغي التثبيت:\n${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};