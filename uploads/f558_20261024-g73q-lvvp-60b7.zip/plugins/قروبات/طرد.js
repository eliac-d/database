import config from '../../config.js'

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");
  if (atIndex === -1) return jid.split(":")[0];
  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);
  return `${userPart}@${domainPart}`;
}

export default {
  name: ['kick', 'expulsar', 'طرد'],
  description: 'يطرد عضو من القروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  botAdmin: true,
  adminOnly: true,

  async run({ sock, from, msg, groupMeta, clearGroupCache, reply, senderNum, sender }) {
    const participants = groupMeta?.participants || []

    const contextInfo = msg.message?.extendedTextMessage?.contextInfo || msg.message?.imageMessage?.contextInfo || msg.message?.videoMessage?.contextInfo
    const mentioned = contextInfo?.mentionedJid || []

    let targetRaw = contextInfo?.participantAlt || contextInfo?.participant || mentioned[0]
    
    if (!targetRaw) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊منشن أو رد على المستخدم الذي تريد طرده.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const cleanTarget = targetRaw.split(':')[0]

    let targetJid = cleanJid(cleanTarget)
    if (cleanTarget.endsWith('@lid')) {
      const match = participants.find(p => p.lid === cleanTarget)
      if (match) targetJid = cleanJid(match.id)
    }

    const botJid = cleanJid(sock.user?.id)
    if (targetJid === botJid) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـسـتـحـيـل⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊ما تقدر تطردني أنا.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const targetNumber = targetJid.split('@')[0]
    const owners = [...(config.ownerNumber || []), ...(config.coOwners || [])]
    if (owners.includes(targetNumber)) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـالـك الـبـوت⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊ما أقدر أطرد مالك البوت.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const targetParticipant = participants.find(p => cleanJid(p.id) === targetJid)
    if (targetParticipant?.admin === 'superadmin') {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌صـاحـب الـقـروب⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊ما أقدر أطرد صاحب القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
    
    if (targetParticipant?.admin === 'admin') {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ❌مـشـرف⏤͟ू⃪❌』*\n` +
          `> •┊˹❌˼┊ما أقدر أطرد مشرفاً.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    try {
      await sock.groupParticipantsUpdate(from, [targetJid], "remove")
      clearGroupCache()

      const targetNum = targetJid.split('@')[0]
      
      const textoKick = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 👢تـم الـطـرد⏤͟ू⃪👢』*\n` +
        `> •┊˹👤˼┊العضو ⇇ @${targetNum}\n` +
        `> •┊˹📌˼┊الحالة ⇇ *〘تم طرده من القروب〙*\n` +
        `> •┊˹✍️˼┊بواسطة ⇇ @${senderNum}\n\n` +
        `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`

      await sock.sendMessage(from, {
        text: textoKick,
        contextInfo: { mentionedJid: [targetJid, sender] }
      }, { quoted: msg })
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أطرد العضو: ${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}