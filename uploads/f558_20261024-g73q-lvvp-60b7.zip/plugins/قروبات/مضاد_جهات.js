import { db } from "../../database/db.js";

export default {
  name: ["anticontact", "مضاد_جهات"],
  description: "يحذف أي جهة اتصال (vCard) تنرسل للقروب تلقائيًا",
  category: "grupos, مجموعات",
  groupOnly: true,
  adminOnly: true,

  async run({ from, args, reply }) {
    const opcion = args[0]?.toLowerCase();

    if (!["on", "off"].includes(opcion)) {
      const estado = db.getGroup(from).anticontact ? "مفعّل ✅" : "معطّل ❌";
      return await reply({
        text: 
          `*『͟͞ू⃪ 👤مـضـاد جـهـات الاتـصـال⏤͟ू⃪👤』*\n` +
          `> •┊˹📊˼┊الحالة ⇇ *〘${estado}〙*\n\n` +
          `> •┊˹💡˼┊الاستخدام:\n` +
          `> ┊˹✅˼┊.anticontact on\n` +
          `> ┊˹❌˼┊.anticontact off\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }

    db.setGroup(from, { anticontact: opcion === "on" });

    return await reply({
      text: 
        `*『͟͞ू⃪ 👤مـضـاد جـهـات الاتـصـال⏤͟ू⃪👤』*\n` +
        `> •┊˹${opcion === "on" ? '✅' : '❌'}˼┊الحالة ⇇ *〘${opcion === "on" ? "مفعل" : "معطل"}〙*\n\n` +
        `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
    });
  }
};