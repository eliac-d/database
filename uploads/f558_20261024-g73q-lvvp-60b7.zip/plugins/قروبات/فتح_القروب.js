import { jidNormalizedUser, isLidUser } from '@whiskeysockets/baileys'

const norm = (j) => (j ? jidNormalizedUser(j) : '')

const identities = (...jids) => {
  const pn = []
  const lid = []
  for (const j of jids.map(norm).filter(Boolean)) (isLidUser(j) ? lid : pn).push(j)
  return { pn, lid }
}

const findParticipant = (participants, { pn, lid }) =>
  (pn.length &&
    participants.find((p) => p.phoneNumber && pn.includes(norm(p.phoneNumber)))) ||
  (lid.length && participants.find((p) => lid.includes(norm(p.id)))) ||
  participants.find((p) => pn.includes(norm(p.id))) ||
  null

const isAdmin = (p) => p?.admin === 'admin' || p?.admin === 'superadmin'

export default {
  name: ['abrir', 'فتح', 'فتح_القروب'],
  description: 'يفتح الدردشة في القروب لجميع الأعضاء',
  category: 'grupos, مجموعات',
  groupOnly: true,

  async run({ sock, from, msg, reply }) {
    const { participants = [] } = await sock.groupMetadata(from)

    const sender = findParticipant(
      participants,
      identities(msg.key.participant, msg.key.participantAlt, msg.participant)
    )
    if (!isAdmin(sender)) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️صـلاحـيـات غـيـر كـافـيـة⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊فقط مشرفو المجموعة يمكنهم استخدام هذا الأمر.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    const bot = findParticipant(participants, identities(sock.user?.id, sock.user?.lid))
    if (!isAdmin(bot)) {
      return await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️الـبـوت لـيـس مـشـرفـاً⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊البوت يحتاج أن يكون مشرفاً لفتح القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }

    try {
      await sock.groupSettingUpdate(from, 'not_announcement')
      await reply({
        text: 
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 🔓تـم فـتـح الـقـروب⏤͟ू⃪🔓』*\n` +
          `> •┊˹✅˼┊القروب أصبح مفتوحاً.\n` +
          `> •┊˹💬˼┊الآن جميع الأعضاء يمكنهم إرسال الرسائل.\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    } catch (e) {
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ أثناء فتح القروب: ${e.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
    }
  }
}