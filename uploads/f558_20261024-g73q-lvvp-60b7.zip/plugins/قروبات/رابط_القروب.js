export default {
  name: ["linkgc", "gclink", "لينك", "رابط_القروب"],
  description: "يجيب رابط القروب",
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, reply }) {
    try {
      const code = await sock.groupInviteCode(from);
      const link = `https://chat.whatsapp.com/${code}`;

      await reply({
        text: 
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 🔗رابـط الـقـروب⏤͟ू⃪🔗』*\n` +
          `> •┊˹📌˼┊الرابط ⇇ ${link}\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });

    } catch (e) {
      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊ما قدرت أجيب رابط القروب.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};