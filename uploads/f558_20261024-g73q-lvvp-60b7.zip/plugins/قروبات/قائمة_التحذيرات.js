import { db } from "../../database/db.js";

function cleanJid(jid = "") {
  if (!jid) return "";
  const atIndex = jid.lastIndexOf("@");

  if (atIndex === -1) return jid.split(":")[0];

  const userPart = jid.slice(0, atIndex).split(":")[0];
  const domainPart = jid.slice(atIndex + 1);

  return `${userPart}@${domainPart}`;
}

export default {
  name: ['listwarn', 'listawarn', 'warns', 'التحذيرات'],
  description: 'يعرض قائمة التحذيرات بالقروب',
  category: 'grupos, مجموعات',
  groupOnly: true,
  adminOnly: true,

  async run({ sock, from, msg, reply }) {
    try {
      const groupData = db.getGroup(from) || {};
      const currentWarns = groupData.warns || {};

      const users = Object.entries(currentWarns)
        .filter(([_, warns]) => Array.isArray(warns) && warns.length > 0);

      if (users.length === 0) {
        return await reply({
          text: 
            `*『͟͞ू⃪ 📋قـائـمـة الـتـحـذيـرات⏤͟ू⃪📋』*\n` +
            `> •┊˹✅˼┊لا يوجد مستخدمون لديهم تحذيرات نشطة في هذا القروب.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        });
      }

      let texto = 
        `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
        `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
        `*『͟͞ू⃪ 📋قـائـمـة الـتـحـذيـرات⏤͟ू⃪📋』*\n\n`;

      const mentions = [];

      users.forEach(([jid, warns], index) => {
        const cleanJidUser = cleanJid(jid);
        const number = warns[0]?.targetNum || cleanJidUser.split('@')[0];

        mentions.push(cleanJidUser);

        texto += `> •┊˹👤˼┊ *${index + 1}. @${number}*\n`;
        texto += `> •┊˹📊˼┊التحذيرات ⇇ *〘${warns.length}/3〙*\n`;

        warns.forEach((warn, warnIndex) => {
          texto += `\n> ┊˹⚠️˼┊ *تحذير #${warnIndex + 1}*\n`;
          texto += `> ┊˹📝˼┊السبب ⇇ *〘${warn.razon || "لم يحدد"}〙*\n`;
          texto += `> ┊˹📅˼┊التاريخ ⇇ *〘${warn.fecha || "غير معروف"}〙*\n`;
          texto += `> ┊˹👮‍♂️˼┊بواسطة ⇇ *〘${warn.by || "غير معروف"}〙*\n`;
        });

        texto += `\n*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n`;
      });

      texto += `> •┊˹👥˼┊مستخدمين محذرين ⇇ *〘${users.length}〙*\n\n`;
      texto += `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`;

      await sock.sendMessage(
        from,
        {
          text: texto,
          mentions
        },
        { quoted: msg }
      );

    } catch (err) {
      console.error("خطأ بأمر listwarn:", err);

      await reply({
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊حدث خطأ داخلي أثناء تنفيذ الأمر.\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      });
    }
  }
};