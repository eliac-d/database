import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["reload", "اعادة_جلسة"],
  description: "يعيد جلسة هذا البوت (إعادة اتصال سريعة، ~1-2 ثانية)",
  category: "owner",
  ownerOnly: true,

  async run({ sock, reply, react, botLabel }) {
    await react("🔄");
    await reply({
      text: decorBox('🔄 إعـادة الـجـلـسـة', [
        decorLine('🤖', 'الـبـوت', botLabel),
        decorLine('⏳', 'الـحـالـة', 'جاري إعادة الجلسة، أرجع بعد لحظة...')
      ])
    });

    try {
      const { clearSocketFiles } = await import("../../core/connection.js");
      if (sock.sessionDir) {
        await clearSocketFiles(sock.sessionDir);
      }
    } catch (e) {
      console.error("[reload] Error limpiando sesión:", e.message);
    }

    setTimeout(() => {
      try {
        sock.end(new Error("Reload manual solicitado"));
      } catch (e) {
        console.error("[reload] Error cerrando socket:", e.message);
      }
    }, 500);
  },
};