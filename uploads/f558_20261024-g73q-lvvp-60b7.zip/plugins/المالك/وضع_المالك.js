import config from "../../config.js";
import { db } from "../../database/db.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["self", "وضع_خاص"],
  description: 'يشغّل أو يطفئ وضع Self بالقروب باستخدام "on" أو "off"',
  category: "owner, المطور",
  groupOnly: true,
  ownerOnly: true,

  async run({ from, args, react, reply }) {
    const accion = args[0]?.toLowerCase();

    if (accion === "on") {
      db.setGroup(from, { selfMode: true });
      await react("🔒");
      return await reply({
        text: decorBox('🔒 وضـع Self', [
          decorLine('🔒', 'الـحـالـة', 'اتفعل بهذا القروب'),
          decorLine('🤖', 'الـسـلـوك', `${config.botName} بيرد بس على نفسه والمالكين`)
        ])
      });
    }

    if (accion === "off") {
      db.setGroup(from, { selfMode: false });
      await react("🔓");
      return await reply({
        text: decorBox('🔓 وضـع Self', [
          decorLine('🔓', 'الـحـالـة', 'اتعطل، رجع البوت يرد على الكل')
        ])
      });
    }

    await react("❓");
    await reply({
      text: decorBox('💡 الاسـتـخـدام', [
        decorLine('✅', 'تـشـغـيـل', '.self on'),
        decorLine('❌', 'إيـقـاف', '.self off')
      ])
    });
  }
};