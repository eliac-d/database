import { decorBox, decorLine } from "../../core/decor.js";

export default { 
  name: ["restart", "rest", "اعادة_تشغيل"],
  description: "يعيد تشغيل البوت", 
category : "owner",
  ownerOnly: true,
  async run({ conn, m, reply }) {
    await reply(decorBox('📍 إعـادة الـتـشـغـيـل', [
      decorLine('📍', 'الـحـالـة', 'جاري إعادة تشغيل البوت...')
    ]))
    setTimeout(() => { process.exit(1) }, 1000)
  }
}
