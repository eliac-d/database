import { execSync } from "child_process";
import { loadPlugins } from "../../core/pluginLoader.js";
import { decorBox, decorLine } from "../../core/decor.js";

export default {
  name: ["update", "actualizar", "gitpull", "تحديث"],
  description: "يفرض التحديث من GitHub ويعيد تحميل الإضافات",
  category: 'owner',
  ownerOnly: true,

  async run({ reply, react }) {
    try {
      await react("🔄");

      execSync("git fetch --all");

      const localSha = execSync("git rev-parse HEAD").toString().trim();
      const remoteSha = execSync("git rev-parse origin/main").toString().trim();

      if (localSha === remoteSha) {
        await react("✅");
        return await reply({
          text: decorBox('✅ تـحـديـث', [
            decorLine('✅', 'الـحـالـة', 'كل شيء محدث، ما فيه تغييرات جديدة')
          ])
        });
      }

      // 📋 Lista real de archivos modificados ANTES de aplicar el reset
      const archivosCambiados = execSync(`git diff --stat ${localSha} ${remoteSha}`).toString().trim();

      // 📝 Lista de commits nuevos que se van a aplicar
      const commitsNuevos = execSync(`git log ${localSha}..${remoteSha} --oneline`).toString().trim();

      execSync("git reset --hard origin/main");

      await loadPlugins();

      let textoUpdate = `✅ *تم التحديث القسري بنجاح*\n\n`;
      textoUpdate += `📦 *تحديثات جديدة:*\n\`\`\`${commitsNuevos || "(ما فيه تفاصيل)"}\`\`\`\n\n`;
      textoUpdate += `📋 *ملفات اتغيرت:*\n\`\`\`${archivosCambiados || "(ما فيه تغييرات بالملفات)"}\`\`\`\n\n`;
      textoUpdate += `🔄 _تم تحميل الإضافات بالذاكرة بدون مشاكل._`;

      await react("✅");
      await reply({ text: textoUpdate });

    } catch (err) {
      await react("❌");
      await reply({
        text: decorBox('❌ خـطـأ بـالـتـحـديـث', [
          decorLine('⚠️', 'الـسـبـب', err.message)
        ]) + (err.stderr ? `\n\`\`\`${err.stderr.toString()}\`\`\`` : '')
      });
    }
  },
};