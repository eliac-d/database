import { db } from '../../database/db.js'
import config from '../../config.js'

const MAX = 999_999_999_999

// المطورين (المالك الأساسي والشركاء) من الإعدادات
const OWNERS = [...(config.ownerNumber || []), ...(config.coOwners || [])].map(String)

function cleanJid(jid = '') {
  if (!jid) return ''
  const atIndex = jid.lastIndexOf('@')
  if (atIndex === -1) return jid.split(':')[0]
  const userPart = jid.slice(0, atIndex).split(':')[0]
  const domainPart = jid.slice(atIndex + 1)
  return `${userPart}@${domainPart}`
}

export default {
  name: ['chetar', 'غش_اقتصاد', 'اعطاء_فلوس'],
  description: 'إعطاء فلوس (فراغمات) لمستخدم معين (للمطورين فقط)',
  category: 'owner, المطور',
  ownerOnly: true,

  async run({ sock, from, sender, args, msg, groupMeta, resolveLid, reply, react }) {
    // ── التحقق من الشخص الذي ينفذ الأمر ──
    let realSender = sender
    if (realSender.endsWith('@lid')) {
      const found = groupMeta?.participants?.find((p) => p.id === realSender || p.lid === realSender)
      realSender = found?.id || (await resolveLid(realSender))
    }
    const senderNum = cleanJid(realSender).split('@')[0]
    const botNum = cleanJid(sock.user?.id || '').split('@')[0]

    // البوت لا يمكنه استخدام هذا الأمر (لتفادي إعطاء نفسه فلوس)
    if (msg.key?.fromMe || senderNum === botNum) {
      await react('🚫')
      return reply({ text: '⚠︎ البوت لا يمكنه استخدام هذا الأمر.' })
    }

    // فقط المطورين من القائمة يمكنهم الاستخدام
    if (!OWNERS.includes(senderNum)) {
      await react('🚫')
      return reply({ text: '⚠︎ هذا الأمر مخصص للمطورين فقط (Owner).' })
    }

    const contextInfo = msg?.message?.extendedTextMessage?.contextInfo

    // الهدف: الشخص المذكور (المنشن) > الرسالة المقتبسة > أنت
    let targetJid = contextInfo?.mentionedJid?.[0] || contextInfo?.participant || realSender

    // حل مشكلة الـ LID
    if (targetJid.endsWith('@lid') || isNaN(targetJid.split('@')[0])) {
      const found = groupMeta?.participants?.find((p) => p.id === targetJid || p.lid === targetJid)
      if (found?.id) targetJid = found.id
    }
    if (targetJid.endsWith('@lid')) {
      targetJid = await resolveLid(targetJid)
    }

    const target = cleanJid(targetJid)

    const campo = args.some((a) => a.toLowerCase() === 'banco') ? 'banco' : 'bolsillo'
    const num = args.find((a) => /^\d+$/.test(a))
    const cantidad = Math.min(Number(num) || MAX, MAX)

    try {
      const eco = db.getEco(target)
      db.setEco(target, { [campo]: Math.min(eco[campo] + cantidad, MAX) })
      const after = db.getEco(target)

      const nombreCampo = campo === 'banco' ? 'البنك 🏦' : 'المحفظة 👜'

      await react('💰')
      await sock.sendMessage(from, {
        text:
          `*بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ ◜*\n` +
          `*┇◞{إِنَّمَا ٱلتَّوۡبَةُ عَلَى ٱللَّهِ...}◜*\n\n` +
          `*『͟͞ू⃪ 💰تـم الـتـحـويـل⏤͟ू⃪💰』*\n` +
          `> •┊˹👤˼┊المستلم ⇇ *〘@${target.split('@')[0]}〙*\n` +
          `> •┊˹💵˼┊المبلغ ⇇ *〘${cantidad.toLocaleString('ar-EG')}〙*\n` +
          `> •┊˹📍˼┊إلى ⇇ *〘${nombreCampo}〙*\n\n` +
          `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
          `*『͟͞ू⃪ 💳الـرصـيـد الـحـالـي⏤͟ू⃪💳』*\n` +
          `> •┊˹👜˼┊المحفظة ⇇ *〘${after.bolsillo.toLocaleString('ar-EG')}〙*\n` +
          `> •┊˹🏦˼┊البنك ⇇ *〘${after.banco.toLocaleString('ar-EG')}〙*\n\n` +
          `*╮═══『┃ ملاحظـة ◜┃』═══╭*\n` +
          `*┇إذا واجهت مشكلة في البوت استخدم ⇠『 .ابلاغ 』*\n` +
          `*╯✯≼══━━﹂🌺﹁━━══≽✯*\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`,
        mentions: [target]
      }, { quoted: msg })
    } catch (e) {
      console.error('Error chetar:', e)
      await react('❌')
      await reply({ text: '⚠︎ لم نتمكن من إعطاء المال.' })
    }
  }
}