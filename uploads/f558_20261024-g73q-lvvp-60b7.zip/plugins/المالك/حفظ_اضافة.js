import { db } from '../../database/db.js'
import fs from 'fs'
import path from 'path'

// أرقام المطورين المعتمدين
const OWNER_NUMBERS = ['963969829657', '967735541558']

export default {
  name: ['saveplugin', 'حفظ_بلجن', 'مسح_بلجن', 'كشف_بلجن'],
  description: 'إدارة ملفات الإضافات (حفظ، مسح، عرض) للمطورين فقط.',
  category: 'owner, المطور',
  ownerOnly: true,

  async run({ sock, from, msg, senderNum, args, usedPrefix, react, reply, cmdName }) {
    try {
      const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net'
      const isOwner = OWNER_NUMBERS.includes(senderNum) || db.hasRole(senderNum, 'owner') || db.hasRole(senderNum, 'coowner')
      const isSelf = senderNum === botJid

      // ⛔ التحقق من الصلاحيات
      if (!isOwner && !isSelf) {
        await react('❌')
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ⚠️صـلاحـيـات غـيـر كـافـيـة⏤͟ू⃪⚠️』*\n` +
            `> •┊˹❌˼┊هذا الأمر مخصص للمطور فقط.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      const baseDir = process.cwd()
      const pluginsDir = path.join(baseDir, 'plugins')
      const action = (cmdName || '').toLowerCase()

      // ═══════════════════════════════════════════════
      // 1️⃣ حفظ الإضافة (saveplugin)
      // ═══════════════════════════════════════════════
      if (action === 'saveplugin' || action === 'حفظ_بلجن') {
        const quotedMsg = msg.message?.extendedTextMessage?.contextInfo?.quotedMessage
        if (!quotedMsg) {
          await react('❌')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
              `> •┊˹❌˼┊لازم ترد على الرسالة التي تحتوي على كود الإضافة.\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        const codigo = quotedMsg.conversation || quotedMsg.extendedTextMessage?.text
        if (!codigo) {
          await react('❌')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
              `> •┊˹❌˼┊الرسالة التي رددت عليها لا تحتوي على نص صحيح.\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        if (!args[0]) {
          await react('💡')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ 💡الاسـتـخـدام⏤͟ू⃪💡』*\n` +
              `> •┊˹📝˼┊رد على الكود واستخدم: *〘${usedPrefix}saveplugin [مجلد]/[اسم].js〙*\n\n` +
              `> •┊˹📌˼┊أمثلة:\n` +
              `> ┊˹📂˼┊${usedPrefix}saveplugin owner/test.js\n` +
              `> ┊˹📂˼┊${usedPrefix}saveplugin myplugin.js\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        await react('🕒')

        let inputPath = args[0].replace(/\.\.\//g, '')
        if (!inputPath.endsWith('.js')) inputPath += '.js'

        const targetPath = path.join(pluginsDir, inputPath)
        const targetDir = path.dirname(targetPath)

        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true })
        }

        fs.writeFileSync(targetPath, codigo, 'utf8')
        await react('✅')
        
        return await reply({
          text: 
            `*『͟͞ू⃪ ✅تـم الـحـفـظ⏤͟ू⃪✅』*\n` +
            `> •┊˹📂˼┼المجلد ⇇ *〘plugins/${path.relative(pluginsDir, targetDir) || 'الجذر'}〙*\n` +
            `> •┊˹📄˼┼الملف ⇇ *〘${path.basename(targetPath)}〙*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      // ═══════════════════════════════════════════════
      // 2️⃣ مسح الإضافة (مسح_بلجن)
      // ═══════════════════════════════════════════════
      if (action === 'مسح_بلجن') {
        if (!args[0]) {
          await react('💡')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
              `> •┊˹📝˼┊اكتب اسم الملف المراد مسحه.\n` +
              `> ┊˹📌˼┊مثال: *〘${usedPrefix}مسح_بلجن owner/test.js〙*\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        let inputPath = args[0].replace(/\.\.\//g, '')
        if (!inputPath.endsWith('.js')) inputPath += '.js'
        const targetPath = path.join(pluginsDir, inputPath)

        if (!fs.existsSync(targetPath)) {
          await react('❌')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ❌غـيـر مـوجـود⏤͟ू⃪❌』*\n` +
              `> •┊˹📄˼┊الملف ⇇ *〘${inputPath}〙* غير موجود.\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        fs.unlinkSync(targetPath)
        await react('🗑️')
        return await reply({ 
          text: 
            `*『͟͞ू⃪ ✅تـم الـمـسـح⏤͟ू⃪✅』*\n` +
            `> •┊˹🗑️˼┊تم مسح الملف ⇇ *〘${inputPath}〙* بنجاح.\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        })
      }

      // ═══════════════════════════════════════════════
      // 3️⃣ كشف الإضافة (كشف_بلجن)
      // ═══════════════════════════════════════════════
      if (action === 'كشف_بلجن') {
        if (!args[0]) {
          await react('💡')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ⚠️تـنـبـيـه⏤͟ू⃪⚠️』*\n` +
              `> •┊˹📝˼┊اكتب اسم الملف المراد عرض كوده.\n` +
              `> ┊˹📌˼┊مثال: *〘${usedPrefix}كشف_بلجن owner/test.js〙*\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        let inputPath = args[0].replace(/\.\.\//g, '')
        if (!inputPath.endsWith('.js')) inputPath += '.js'
        const targetPath = path.join(pluginsDir, inputPath)

        if (!fs.existsSync(targetPath)) {
          await react('❌')
          return await reply({ 
            text: 
              `*『͟͞ू⃪ ❌غـيـر مـوجـود⏤͟ू⃪❌』*\n` +
              `> •┊˹📄˼┊الملف ⇇ *〘${inputPath}〙* غير موجود.\n\n` +
              `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
          })
        }

        const codigo = fs.readFileSync(targetPath, 'utf8')
        await react('📄')
        
        // إرسال الكود كملف نصي لتجنب قطع الرسائل الطويلة
        return await sock.sendMessage(from, {
          document: Buffer.from(codigo, 'utf8'),
          fileName: path.basename(targetPath),
          mimetype: 'text/javascript',
          caption: 
            `*『͟͞ू⃪ 📄كـود الإضـافـة⏤͟ू⃪📄』*\n` +
            `> •┊˹📂˼┊المسار ⇇ *〘${inputPath}〙*\n` +
            `> •┊˹📦˼┊الحجم ⇇ *〘${(codigo.length / 1024).toFixed(2)} KB〙*\n\n` +
            `*⌬──══─┈•⤣🌺⤤•┈─══──⌬*\n\n` +
            `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
        }, { quoted: msg })
      }

    } catch (error) {
      await react('❌')
      await reply({ 
        text: 
          `*『͟͞ू⃪ ⚠️خـطـأ⏤͟ू⃪⚠️』*\n` +
          `> •┊˹❌˼┊${error.message}\n\n` +
          `*𝐀𝐘𝐀𝐍𝐎𝐊𝐎𝐉𝐈 𝐁𝐎𝐓 | سونغ*`
      })
      console.error(error)
    }
  }
}